from __future__ import annotations

from math import isclose
from typing import Any


RUBRIC_VERSION = "2.0-section-atomic"

DIMENSION_MAXIMA = {
    "front_screen": 15.0,
    "question_closure": 15.0,
    "model_expression": 15.0,
    "results": 15.0,
    "validation_conclusion": 10.0,
    "figures_tables": 10.0,
    "language": 10.0,
    "consistency_citations": 5.0,
    "latex_compliance": 5.0,
}

SECTION_RUBRIC = {
    "title_abstract_keywords": {"maximum": 15.0, "readiness_floor": 14.0},
    "problem_analysis": {"maximum": 6.0, "readiness_floor": 5.0},
    "foundations": {"maximum": 10.0, "readiness_floor": 9.0},
    "per_question_modeling": {"maximum": 17.0, "readiness_floor": 15.0},
    "results_interpretation": {"maximum": 15.0, "readiness_floor": 14.0},
    "validation_evaluation_conclusion": {
        "maximum": 10.0,
        "readiness_floor": 9.0,
    },
    "figures_tables": {"maximum": 10.0, "readiness_floor": 9.0},
    "language_coherence": {"maximum": 9.0, "readiness_floor": 8.0},
    "citations_consistency": {"maximum": 3.0, "readiness_floor": 2.5},
    "latex_compliance_support": {"maximum": 5.0, "readiness_floor": 4.0},
}


def criterion(
    criterion_id: str,
    section: str,
    maximum: float,
    dimensions: dict[str, float],
) -> dict[str, Any]:
    return {
        "id": criterion_id,
        "section": section,
        "maximum": maximum,
        "dimensions": dimensions,
    }


CRITERIA = [
    criterion("fs_title", "title_abstract_keywords", 2.0, {"front_screen": 2.0}),
    criterion("fs_mainline", "title_abstract_keywords", 2.0, {"front_screen": 2.0}),
    criterion("fs_question_methods", "title_abstract_keywords", 3.0, {"front_screen": 3.0}),
    criterion("fs_question_answers", "title_abstract_keywords", 5.0, {"front_screen": 5.0}),
    criterion("fs_validation_keywords", "title_abstract_keywords", 3.0, {"front_screen": 3.0}),
    criterion("pa_task_io", "problem_analysis", 2.0, {"question_closure": 2.0}),
    criterion("pa_difficulty", "problem_analysis", 1.0, {"question_closure": 1.0}),
    criterion(
        "pa_method_route",
        "problem_analysis",
        1.5,
        {"model_expression": 1.0, "question_closure": 0.5},
    ),
    criterion("pa_question_linkage", "problem_analysis", 0.5, {"question_closure": 0.5}),
    criterion("pa_concision_transition", "problem_analysis", 1.0, {"language": 1.0}),
    criterion("fd_assumptions_scope", "foundations", 2.0, {"model_expression": 2.0}),
    criterion("fd_symbols_units", "foundations", 2.0, {"model_expression": 2.0}),
    criterion("fd_preprocessing", "foundations", 1.5, {"model_expression": 1.5}),
    criterion(
        "fd_common_model",
        "foundations",
        2.5,
        {"model_expression": 1.5, "question_closure": 1.0},
    ),
    criterion(
        "fd_condition_consistency",
        "foundations",
        2.0,
        {"consistency_citations": 2.0},
    ),
    criterion("qm_model_choice", "per_question_modeling", 2.0, {"model_expression": 2.0}),
    criterion("qm_formulation", "per_question_modeling", 3.0, {"model_expression": 3.0}),
    criterion(
        "qm_formula_explanation",
        "per_question_modeling",
        2.0,
        {"model_expression": 2.0},
    ),
    criterion("qm_solver_reproducibility", "per_question_modeling", 3.0, {"question_closure": 3.0}),
    criterion("qm_six_part_chain", "per_question_modeling", 4.0, {"question_closure": 4.0}),
    criterion("qm_answer_linkage", "per_question_modeling", 3.0, {"question_closure": 3.0}),
    criterion("rs_completeness", "results_interpretation", 4.0, {"results": 4.0}),
    criterion("rs_source_precision", "results_interpretation", 3.0, {"results": 3.0}),
    criterion("rs_quantitative_explanation", "results_interpretation", 4.0, {"results": 4.0}),
    criterion("rs_practical_answer", "results_interpretation", 4.0, {"results": 4.0}),
    criterion(
        "vc_numerical_boundary_checks",
        "validation_evaluation_conclusion",
        2.5,
        {"validation_conclusion": 2.5},
    ),
    criterion(
        "vc_sensitivity_robustness",
        "validation_evaluation_conclusion",
        3.0,
        {"validation_conclusion": 3.0},
    ),
    criterion(
        "vc_model_specific_evaluation",
        "validation_evaluation_conclusion",
        2.0,
        {"validation_conclusion": 2.0},
    ),
    criterion(
        "vc_conclusion_correspondence",
        "validation_evaluation_conclusion",
        2.5,
        {"validation_conclusion": 2.5},
    ),
    criterion("ft_evidence_value", "figures_tables", 2.5, {"figures_tables": 2.5}),
    criterion("ft_caption_units", "figures_tables", 2.5, {"figures_tables": 2.5}),
    criterion("ft_reference_explanation", "figures_tables", 3.0, {"figures_tables": 3.0}),
    criterion("ft_readability_placement", "figures_tables", 2.0, {"figures_tables": 2.0}),
    criterion("lg_paragraph_cohesion", "language_coherence", 2.5, {"language": 2.5}),
    criterion("lg_terminology_accuracy", "language_coherence", 2.0, {"language": 2.0}),
    criterion("lg_concision_density", "language_coherence", 2.5, {"language": 2.5}),
    criterion("lg_natural_calibrated", "language_coherence", 2.0, {"language": 2.0}),
    criterion(
        "cc_citation_authenticity",
        "citations_consistency",
        1.5,
        {"consistency_citations": 1.5},
    ),
    criterion(
        "cc_cross_source_consistency",
        "citations_consistency",
        1.5,
        {"consistency_citations": 1.5},
    ),
    criterion("lc_compile_integrity", "latex_compliance_support", 1.0, {"latex_compliance": 1.0}),
    criterion("lc_rules_anonymity", "latex_compliance_support", 1.5, {"latex_compliance": 1.5}),
    criterion("lc_visual_layout", "latex_compliance_support", 1.0, {"latex_compliance": 1.0}),
    criterion("lc_support_ai", "latex_compliance_support", 1.5, {"latex_compliance": 1.5}),
]

CRITERIA_BY_ID = {item["id"]: item for item in CRITERIA}


def readiness_floor(dimension_id: str) -> float:
    maximum = DIMENSION_MAXIMA[dimension_id]
    if maximum == 15:
        return 13.0
    if maximum == 10:
        return 9.0
    return 4.0


def new_quality_assessment() -> dict[str, Any]:
    return {
        "rubric_version": RUBRIC_VERSION,
        "review": {
            "reviewer": "",
            "reviewed_at": "",
            "paper_version": "",
        },
        "high_risk_open": [],
        "criteria": [
            {
                "id": item["id"],
                "score": None,
                "evidence": [],
                "finding": "",
                "action": "",
            }
            for item in CRITERIA
        ],
    }


def validate_rubric_definition() -> None:
    section_totals = {section_id: 0.0 for section_id in SECTION_RUBRIC}
    dimension_totals = {dimension_id: 0.0 for dimension_id in DIMENSION_MAXIMA}
    seen: set[str] = set()
    for item in CRITERIA:
        criterion_id = item["id"]
        if criterion_id in seen:
            raise ValueError(f"duplicate rubric criterion: {criterion_id}")
        seen.add(criterion_id)
        section_id = item["section"]
        if section_id not in SECTION_RUBRIC:
            raise ValueError(f"unknown rubric section: {section_id}")
        allocated = sum(item["dimensions"].values())
        if not isclose(allocated, item["maximum"], abs_tol=1e-9):
            raise ValueError(f"dimension allocation mismatch: {criterion_id}")
        section_totals[section_id] += item["maximum"]
        for dimension_id, value in item["dimensions"].items():
            if dimension_id not in DIMENSION_MAXIMA:
                raise ValueError(f"unknown rubric dimension: {dimension_id}")
            dimension_totals[dimension_id] += value
    for section_id, config in SECTION_RUBRIC.items():
        if not isclose(section_totals[section_id], config["maximum"], abs_tol=1e-9):
            raise ValueError(f"section maximum mismatch: {section_id}")
    for dimension_id, maximum in DIMENSION_MAXIMA.items():
        if not isclose(dimension_totals[dimension_id], maximum, abs_tol=1e-9):
            raise ValueError(f"dimension maximum mismatch: {dimension_id}")
    if not isclose(sum(section_totals.values()), 100.0, abs_tol=1e-9):
        raise ValueError("rubric total must equal 100")


validate_rubric_definition()
