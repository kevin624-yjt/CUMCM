from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


TEXT_EXTENSIONS = {
    ".bib",
    ".csv",
    ".json",
    ".md",
    ".py",
    ".r",
    ".tex",
    ".txt",
    ".yaml",
    ".yml",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_inside(root: Path, relative_path: str) -> Path:
    candidate = (root / relative_path).resolve()
    root_resolved = root.resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise ValueError(f"path escapes project root: {relative_path}") from exc
    return candidate


def read_text_best_effort(path: Path) -> str:
    for encoding in ("utf-8", "utf-8-sig", "gb18030"):
        try:
            return path.read_text(encoding=encoding)
        except (UnicodeDecodeError, OSError):
            continue
    return ""


def iter_text_files(root: Path, excluded_parts: Iterable[str] = ()) -> Iterable[Path]:
    excluded = set(excluded_parts)
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in TEXT_EXTENSIONS:
            continue
        if any(part in excluded for part in path.parts):
            continue
        yield path


def latex_escape(value: Any) -> str:
    text = str(value)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in text)


def normalize_question_ids(raw: str) -> list[str]:
    values = [item.strip().upper() for item in raw.split(",") if item.strip()]
    if not values:
        raise ValueError("at least one question ID is required")
    if len(values) != len(set(values)):
        raise ValueError("question IDs must be unique")
    for value in values:
        if not re.fullmatch(r"[A-Z][A-Z0-9_-]*", value):
            raise ValueError(f"invalid question ID: {value}")
    return values


def approval_ok(approvals: dict[str, Any], key: str) -> tuple[bool, str]:
    item = approvals.get("checks", {}).get(key, {})
    approved = item.get("approved") is True
    reviewer = str(item.get("reviewer", "")).strip()
    checked_at = str(item.get("checked_at", "")).strip()
    evidence = item.get("evidence", [])
    complete = approved and reviewer and checked_at and isinstance(evidence, list) and bool(evidence)
    if complete:
        return True, f"{reviewer} at {checked_at}: {evidence}"
    return False, f"manual approval '{key}' is missing reviewer/time/evidence"


def gate(gate_id: str, name: str, passed: bool, evidence: Iterable[str]) -> dict[str, Any]:
    return {
        "id": gate_id,
        "name": name,
        "status": "PASS" if passed else "FAIL",
        "evidence": list(evidence),
    }


def unique(items: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(item for item in items if item))

