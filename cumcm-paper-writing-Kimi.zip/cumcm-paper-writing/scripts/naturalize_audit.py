from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

from common import (
    load_json,
    now_iso,
    read_text_best_effort,
    resolve_inside,
    sha256_file,
    write_json,
)


CLAIM_PATTERN = re.compile(
    r"\\Claim(?:Value|Unit|Answer|Scope)\{[^{}]+\}"
)
NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z\\])[-+]?(?:\d+(?:\.\d+)?|\.\d+)"
    r"(?:[eE][-+]?\d+)?%?"
)
UNIT_PATTERN = re.compile(
    r"(?<![A-Za-z])(?:"
    r"m/s|km/h|m\^2|m\^3|"
    r"nm|[μµ]m|um|mm|cm|km|m|"
    r"ms|s|min|h|"
    r"Hz|kHz|MHz|GHz|"
    r"Pa|kPa|MPa|GPa|"
    r"kg|mg|g|mol|"
    r"K|℃|°C|°|rad|"
    r"dB|mV|V|mA|A|kW|W|J|N|"
    r"%|‰"
    r")(?![A-Za-z])"
)
LABEL_PATTERN = re.compile(r"\\label\{[^{}]+\}")
REFERENCE_PATTERN = re.compile(
    r"\\(?:ref|eqref|pageref|autoref|cref|Cref)\{[^{}]+\}"
)
CITATION_PATTERN = re.compile(r"\\cite\w*\{[^{}]+\}")
STRUCTURE_PATTERN = re.compile(
    r"\\(?:title|section|subsection|subsubsection|paragraph|"
    r"input|include|includegraphics|caption|bibliography|bibliographystyle)"
    r"\*?(?:\[[^\]]*\])?\{[^{}]*\}"
)
ENVIRONMENT_PATTERN = re.compile(r"\\(?:begin|end)\{[^{}]+\}")
MATH_PATTERN = re.compile(
    r"\\begin\{(?P<env>equation|align|gather|multline|math|displaymath)"
    r"\*?\}.*?\\end\{(?P=env)\*?\}|"
    r"\\\[.*?\\\]|\\\(.*?\\\)|"
    r"\$\$.*?\$\$|(?<!\\)\$(?!\$).*?(?<!\\)\$",
    flags=re.DOTALL,
)
NONPROSE_ENV_PATTERN = re.compile(
    r"\\begin\{(?P<env>figure|table|tabular|longtable|thebibliography|"
    r"lstlisting|verbatim|algorithm|tikzpicture)\*?\}.*?"
    r"\\end\{(?P=env)\*?\}",
    flags=re.DOTALL,
)

TIER_THRESHOLDS = {
    "light": {
        "sentence_cv": 0.18,
        "paragraph_cv": 0.20,
        "connector_density": 14.0,
        "generic_density": 8.0,
        "repeat_opening": 4,
        "em_dash_density": 4.0,
        "bold_density": 1.5,
        "inline_header_limit": 12,
    },
    "medium": {
        "sentence_cv": 0.25,
        "paragraph_cv": 0.28,
        "connector_density": 10.0,
        "generic_density": 6.0,
        "repeat_opening": 3,
        "em_dash_density": 3.0,
        "bold_density": 1.0,
        "inline_header_limit": 8,
    },
    "heavy": {
        "sentence_cv": 0.32,
        "paragraph_cv": 0.35,
        "connector_density": 7.0,
        "generic_density": 4.0,
        "repeat_opening": 3,
        "em_dash_density": 2.0,
        "bold_density": 0.6,
        "inline_header_limit": 5,
    },
}

BLOCKER_PATTERNS = [
    (
        "D5",
        "chat_residue",
        r"作为(?:一个)?(?:AI|人工智能|语言模型)",
        "删除对话身份残留，直接陈述论文内容。",
        "论文正文不得保留生成过程中的角色说明。",
    ),
    (
        "D5",
        "chat_residue",
        r"希望(?:这|以上).{0,12}(?:对您|能).{0,8}(?:帮助|有帮助)",
        "删除面向聊天对象的收尾语。",
        "竞赛论文应面向评阅者陈述证据，而不是继续聊天。",
    ),
    (
        "D5",
        "chat_residue",
        r"如果您(?:需要|还有|希望)",
        "删除对话式追加服务语。",
        "终稿不得出现助手式交互残留。",
    ),
    (
        "D5",
        "assistant_meta_residue",
        r"以下(?:是|为)(?:修改|改写|润色|整理)后(?:的)?(?:内容|版本|文本)",
        "删除生成或改写过程说明，直接保留论文正文。",
        "终稿只呈现论文内容，不呈现助手的交付话术。",
    ),
    (
        "D5",
        "knowledge_cutoff_residue",
        r"(?:截至(?:我|本助手)(?:的)?知识截止(?:日期)?|"
        r"(?:我|本助手)(?:无法|不能)(?:访问|浏览|联网获取).{0,16}"
        r"(?:最新|实时|当前))",
        "删除模型知识或联网能力声明；需要时改写为有证据的数据时点和适用范围。",
        "聊天系统的能力免责声明不能替代论文的数据边界。",
    ),
    (
        "D5",
        "sycophantic_residue",
        r"(?:这是一个(?:很|非常)?(?:好|棒|有趣|重要)(?:的)?问题|"
        r"您的(?:问题|观点|分析).{0,12}(?:很好|很有见地|非常准确))",
        "删除面向用户的评价，直接陈述任务、证据或判断。",
        "讨好式回应属于对话残留，不属于竞赛论证。",
    ),
    (
        "D5",
        "markdown_residue",
        r"(?:```|^#{1,6}\s+|(?<!\\)\*\*[^*\n]{1,80}\*\*)",
        "改为合法 LaTeX 命令或删除交付格式残留。",
        "TeX 正文不得混入 Markdown 标题、代码围栏或粗体标记。",
    ),
    (
        "D5",
        "emoji_residue",
        r"[\U0001F300-\U0001FAFF]",
        "删除表情符号，并用正式技术语言表达必要信息。",
        "表情符号不属于国赛论文正文语体。",
    ),
    (
        "D5",
        "detector_claim",
        r"AI\s*率\s*[:：]?\s*\d+(?:\.\d+)?\s*%",
        "删除自造的 AI 百分比；只保留可复核的本地风格诊断。",
        "本模块不测量、预测或伪造任何平台的 AI 率。",
    ),
    (
        "D5",
        "detector_claim",
        r"(?:保证|确保|承诺).{0,20}(?:知网|维普|AIGC|AI\s*检测)"
        r".{0,16}(?:通过|低于|为零|0\s*%)",
        "删除检测器通过承诺，改为说明已执行的完整性和风格检查。",
        "未知检测器的内部算法不能由本地规则可靠推断。",
    ),
    (
        "D5",
        "detector_claim",
        r"(?:知网|维普|AIGC).{0,12}(?:包过|必过|零风险)",
        "删除检测器规避承诺。",
        "学术编辑只能报告可观察的文本问题和已执行检查。",
    ),
]

RAW_BLOCKER_PATTERNS = [
    (
        "D5",
        "tool_or_citation_residue",
        r"(?:oaicite|turn\d+(?:search|fetch|open|view|click)\d*|"
        r"contentReference\[[^\]\n]+\]|\[\^[^\]\n]{1,30}\^\]|"
        r"<\|(?:assistant|tool|analysis|final)[^>]*\|>|</?tool_call>)",
        "删除工具调用或临时引用标记，并使用真实、可解析的 LaTeX 引用。",
        "生成工具的内部标记进入正文会造成引用失真或发布污染。",
    ),
]

ADVISORY_PATTERNS = [
    (
        "D2",
        "template_opening",
        r"(?:近年来|当今社会|随着.{0,20}(?:快速|迅速|不断)?发展)",
        "从题目对象、数据特征或具体建模难点起笔。",
        "泛背景开头占据篇幅，却没有推进当前问题。",
    ),
    (
        "D2",
        "throat_clearing",
        r"(?:综上所述|总而言之|总的来说|由此可见|"
        r"值得(?:注意|指出)的是|需要(?:注意|指出|说明)的是|"
        r"不难(?:发现|看出)|显而易见|众所周知|毋庸置疑)",
        "删除提示壳，直接写结论及其证据或适用条件。",
        "高频提示壳会让段落像按模板拼接。",
    ),
    (
        "D2",
        "forced_parallelism",
        r"不仅.{0,40}(?:而且|还)",
        "保留真正的并列关系；若只是强调，拆成直接陈述。",
        "否定式排比过密会掩盖主次关系。",
    ),
    (
        "D2",
        "forced_parallelism",
        r"一方面.{0,50}另一方面",
        "确认两方面确实对称；否则按因果或主次关系重写。",
        "机械二分常把不对称证据包装成对称结构。",
    ),
    (
        "D2",
        "negative_parallelism",
        r"(?:不是|并非|不只是|不仅仅是).{0,45}(?:而是|更是|还是)",
        "确认否定与转折确实区分了两个命题；若只用于强调，改为直接判断。",
        "否定式排比容易把普通结论包装成口号。",
    ),
    (
        "D2",
        "triadic_structure",
        r"(?:一是|首先).{0,80}(?:二是|其次).{0,80}(?:三是|再次|最后)",
        "按真实步骤或证据数量组织，三项结构有技术必要时可说明后保留。",
        "连续三段式只触发复核，不代表三步算法本身有问题。",
    ),
    (
        "D3",
        "empty_significance",
        r"(?:具有|具备)(?:十分|非常|重要|重大|广泛|较高|良好)*"
        r"(?:现实意义|理论意义|应用价值|应用前景|参考价值)",
        "写明具体适用对象、决策用途或可复用条件。",
        "价值判断需要由论文中的结果和边界支撑。",
    ),
    (
        "D3",
        "empty_support",
        r"(?:提供(?:了)?(?:有力|坚实|重要)?支撑|"
        r"奠定(?:了)?(?:坚实|良好)?基础|"
        r"发挥(?:了)?(?:重要|关键|核心)作用)",
        "指出它具体支持哪一项约束、判断或后续求解。",
        "空泛作用句没有建立可追踪的 claim 关系。",
    ),
    (
        "D3",
        "inflated_framing",
        r"(?:(?:作为|成为).{0,24}(?:体现|证明|见证|象征)|"
        r"(?:彰显|凸显).{0,12}(?:价值|意义|优势|作用))",
        "改写为模型、结果或约束直接支持的具体判断。",
        "象征性或拔高式框架会扩大论文实际证据所能支持的范围。",
    ),
    (
        "D3",
        "formulaic_outlook",
        r"(?:(?:尽管|虽然).{0,30}(?:挑战|不足|局限).{0,30}"
        r"(?:但|然而).{0,30}(?:未来|进一步)|"
        r"未来(?:研究|工作)(?:将|可)(?:进一步|继续|重点))",
        "写明具体局限、影响对象和可执行的推广条件；没有依据时删除展望。",
        "提纲式挑战与展望不能替代模型边界分析。",
    ),
    (
        "D3",
        "vague_scope",
        r"(?:从.{1,18}到.{1,18}(?:各个|多个|所有)(?:方面|层面|环节)|"
        r"(?:全方位|多层次|多维度)(?:地|的)?(?:展示|揭示|刻画|分析))",
        "列出实际覆盖的变量、环节或尺度，避免用宽泛范围代替对象定义。",
        "虚假范围会让覆盖面看似完整，却无法对应具体证据。",
    ),
    (
        "D5",
        "vague_attribution",
        r"(?:有|相关|大量|众多)?研究(?:结果)?表明|"
        r"专家认为|学者普遍认为|业内人士认为|普遍认为",
        "给出真实引用及其支持内容，或删除模糊权威。",
        "模糊归因不能替代文献证据。",
    ),
    (
        "D5",
        "vague_comparative",
        r"(?:显著|大幅|明显)(?:提高|提升|降低|减少|改善)|"
        r"(?:更加|更为)(?:准确|稳定|可靠|合理)|"
        r"(?:较好地|较为理想|很大程度上)",
        "补充比较基线、指标和数值；证据不足时降低措辞强度。",
        "比较词必须绑定基线、指标和适用范围。",
    ),
    (
        "D5",
        "promotional_wording",
        r"(?:卓越|强大|开创性|革命性|颠覆性|前所未有|"
        r"令人瞩目|完美|极其精准|高度智能)",
        "改成可核验的性能、限制或观察结果。",
        "宣传性形容词不属于竞赛技术论证。",
    ),
    (
        "D5",
        "trend_buzzword",
        r"(?:(?:赋能|助力|焕发).{0,16}(?:发展|创新|转型|升级)|"
        r"开启.{0,12}(?:新篇章|新纪元))",
        "删除趋势口号，改写为当前模型能够支持的用途或边界。",
        "流行语不能替代结果解释。",
    ),
    (
        "D5",
        "excessive_hedging",
        r"(?:可能.{0,6}(?:或许|似乎|大概|也许)|"
        r"(?:或许|似乎|大概|也许).{0,6}可能|"
        r"在一定程度上.{0,8}(?:可能|或许|似乎))",
        "根据证据强度保留一个必要限定，并明确条件或不确定性来源。",
        "多个模糊限定叠加会隐藏结论边界。",
    ),
    (
        "D3",
        "generic_optimism",
        r"(?:(?:发展|应用|推广)?前景(?:十分|非常|较为)?广阔|"
        r"未来可期|必将(?:产生|发挥|成为)|具有无限可能)",
        "用正文已证明的适用对象、条件或推广限制收束结论。",
        "通用乐观结尾没有增加可复核信息。",
    ),
    (
        "D4",
        "connector",
        r"(?:首先|其次|再次|最后|此外|另外|进而|因此|然而|同时)[，,]",
        "只保留承担真实逻辑关系的连接词，其余改由主语和信息顺序承接。",
        "连接词密集会让段落节奏和逻辑层级机械化。",
    ),
    (
        "D5",
        "chat_opening",
        r"(?:当然|好的|下面(?:我|将)|以下是)[，,:：]",
        "删除聊天式起手，直接进入论文陈述。",
        "助手式开场会暴露生成过程而不承载学术信息。",
    ),
]


def strip_tex_comments(text: str) -> str:
    return "\n".join(
        re.split(r"(?<!\\)%", line, maxsplit=1)[0] for line in text.splitlines()
    )


def manuscript_paths(project: Path) -> list[Path]:
    paths: list[Path] = []
    main = project / "main.tex"
    if main.is_file():
        paths.append(main)
    sections = project / "sections"
    if sections.is_dir():
        paths.extend(sorted(sections.rglob("*.tex")))
    claims = project / "generated" / "claims.tex"
    if claims.is_file():
        paths.append(claims)
    return paths


def style_paths(project: Path) -> list[Path]:
    sections = project / "sections"
    if not sections.is_dir():
        return []
    excluded = {"appendix.tex", "questions.tex", "references.tex"}
    return [
        path
        for path in sorted(sections.rglob("*.tex"))
        if path.name not in excluded
    ]


def relative(project: Path, path: Path) -> str:
    return path.relative_to(project).as_posix()


def canonical_digest(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def collect_pattern_entries(
    project: Path, paths: Iterable[Path], pattern: re.Pattern[str]
) -> list[str]:
    entries: list[str] = []
    for path in paths:
        text = strip_tex_comments(read_text_best_effort(path))
        source = relative(project, path)
        entries.extend(f"{source}|{match.group(0)}" for match in pattern.finditer(text))
    return sorted(entries)


def collect_math_entries(project: Path, paths: Iterable[Path]) -> list[str]:
    entries: list[str] = []
    for path in paths:
        text = strip_tex_comments(read_text_best_effort(path))
        source = relative(project, path)
        for match in MATH_PATTERN.finditer(text):
            block = match.group(0).replace("\r\n", "\n")
            entries.append(
                f"{source}|sha256={hashlib.sha256(block.encode('utf-8')).hexdigest()}"
                f"|chars={len(block)}"
            )
    return sorted(entries)


def critical_file_hashes(project: Path) -> dict[str, str]:
    candidates = [
        "paper_contract.json",
        "claim_registry.json",
        "paper_claim_matrix.csv",
        "generated/claims.tex",
        "references.bib",
    ]
    registry_path = project / "claim_registry.json"
    if registry_path.is_file():
        registry = load_json(registry_path)
        for evidence in registry.get("evidence", []):
            evidence_path = str(evidence.get("path", "")).strip()
            if evidence_path:
                candidates.append(evidence_path)

    hashes: dict[str, str] = {}
    for item in sorted(set(candidates)):
        try:
            path = resolve_inside(project, item)
        except ValueError:
            hashes[item] = "INVALID_PATH"
            continue
        hashes[item] = sha256_file(path) if path.is_file() else "MISSING"
    return hashes


def build_protected_state(project: Path) -> dict[str, Any]:
    paths = manuscript_paths(project)
    buckets = {
        "claim_macros": collect_pattern_entries(project, paths, CLAIM_PATTERN),
        "numeric_tokens": collect_pattern_entries(project, paths, NUMBER_PATTERN),
        "unit_tokens": collect_pattern_entries(project, paths, UNIT_PATTERN),
        "labels": collect_pattern_entries(project, paths, LABEL_PATTERN),
        "cross_references": collect_pattern_entries(
            project, paths, REFERENCE_PATTERN
        ),
        "citations": collect_pattern_entries(project, paths, CITATION_PATTERN),
        "structure_commands": collect_pattern_entries(
            project, paths, STRUCTURE_PATTERN
        ),
        "environment_commands": collect_pattern_entries(
            project, paths, ENVIRONMENT_PATTERN
        ),
        "math_blocks": collect_math_entries(project, paths),
    }
    return {
        "critical_file_hashes": critical_file_hashes(project),
        "buckets": buckets,
    }


def state_digest(state: dict[str, Any]) -> str:
    return canonical_digest(state)


def counter_delta(before: list[str], after: list[str]) -> dict[str, Any]:
    before_counter = Counter(before)
    after_counter = Counter(after)
    removed = list((before_counter - after_counter).elements())
    added = list((after_counter - before_counter).elements())
    return {
        "status": "PASS" if not removed and not added else "FAIL",
        "before_count": len(before),
        "after_count": len(after),
        "removed_count": len(removed),
        "added_count": len(added),
        "removed": removed[:50],
        "added": added[:50],
        "truncated": len(removed) > 50 or len(added) > 50,
    }


def compare_protected_states(
    baseline: dict[str, Any], current: dict[str, Any]
) -> dict[str, Any]:
    categories: dict[str, Any] = {}
    baseline_files = baseline.get("critical_file_hashes", {})
    current_files = current.get("critical_file_hashes", {})
    file_keys = sorted(set(baseline_files) | set(current_files))
    file_changes = [
        {
            "path": key,
            "before": baseline_files.get(key),
            "after": current_files.get(key),
        }
        for key in file_keys
        if baseline_files.get(key) != current_files.get(key)
    ]
    categories["critical_file_hashes"] = {
        "status": "PASS" if not file_changes else "FAIL",
        "changes": file_changes,
    }

    baseline_buckets = baseline.get("buckets", {})
    current_buckets = current.get("buckets", {})
    for key in sorted(set(baseline_buckets) | set(current_buckets)):
        categories[key] = counter_delta(
            list(baseline_buckets.get(key, [])),
            list(current_buckets.get(key, [])),
        )

    failed = [
        key for key, value in categories.items() if value.get("status") != "PASS"
    ]
    return {
        "status": "PASS" if not failed else "FAIL",
        "failed_categories": failed,
        "categories": categories,
    }


def mask_match(match: re.Match[str]) -> str:
    return "".join("\n" if char == "\n" else " " for char in match.group(0))


def prose_view(text: str) -> str:
    clean = strip_tex_comments(text)
    clean = MATH_PATTERN.sub(mask_match, clean)
    clean = NONPROSE_ENV_PATTERN.sub(mask_match, clean)
    clean = CLAIM_PATTERN.sub(" ", clean)
    clean = REFERENCE_PATTERN.sub(" ", clean)
    clean = CITATION_PATTERN.sub(" ", clean)
    clean = LABEL_PATTERN.sub(" ", clean)
    clean = STRUCTURE_PATTERN.sub(" ", clean)
    clean = re.sub(
        r"\\(?:begin|end)\{[^{}]+\}(?:\[[^\]]*\])?", " ", clean
    )
    clean = re.sub(r"\\[A-Za-z@]+\*?(?:\[[^\]]*\])?", " ", clean)
    clean = clean.replace("{", " ").replace("}", " ")
    clean = re.sub(r"[&_~^]", " ", clean)
    return clean


def prose_characters(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text))


def sentence_lengths(text: str) -> list[int]:
    sentences = re.split(r"[。！？!?；;]+", text)
    return [
        prose_characters(sentence)
        for sentence in sentences
        if prose_characters(sentence) >= 6
    ]


def coefficient_of_variation(values: list[int]) -> float | None:
    if len(values) < 2:
        return None
    mean = statistics.fmean(values)
    if mean == 0:
        return None
    return statistics.pstdev(values) / mean


def sentence_opening(sentence: str, length: int = 6) -> str:
    normalized = "".join(
        re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", sentence)
    )
    return normalized[:length]


def make_finding(
    finding_id: str,
    source: str,
    line: int,
    dimension: str,
    category: str,
    severity: str,
    phrase: str,
    context: str,
    suggestion: str,
    teaching_note: str,
) -> dict[str, Any]:
    return {
        "id": finding_id,
        "source": source,
        "line": line,
        "dimension": dimension,
        "category": category,
        "severity": severity,
        "phrase": phrase,
        "context": context,
        "suggestion": suggestion,
        "teaching_note": teaching_note,
    }


def scan_style(project: Path, tier: str) -> dict[str, Any]:
    thresholds = TIER_THRESHOLDS[tier]
    findings: list[dict[str, Any]] = []
    prose_parts: list[str] = []
    raw_parts: list[str] = []
    finding_index = 1

    compiled_blockers = [
        (dimension, category, re.compile(pattern), suggestion, note)
        for dimension, category, pattern, suggestion, note in BLOCKER_PATTERNS
    ]
    compiled_raw_blockers = [
        (dimension, category, re.compile(pattern), suggestion, note)
        for dimension, category, pattern, suggestion, note in RAW_BLOCKER_PATTERNS
    ]
    compiled_advisories = [
        (dimension, category, re.compile(pattern), suggestion, note)
        for dimension, category, pattern, suggestion, note in ADVISORY_PATTERNS
    ]

    for path in style_paths(project):
        raw = read_text_best_effort(path)
        visible = prose_view(raw)
        raw_clean = strip_tex_comments(raw)
        raw_parts.append(raw_clean)
        prose_parts.append(visible)
        source = relative(project, path)
        for line_number, line in enumerate(raw_clean.splitlines(), start=1):
            compact = re.sub(r"\s+", " ", line).strip()
            if not compact:
                continue
            for (
                dimension,
                category,
                pattern,
                suggestion,
                note,
            ) in compiled_raw_blockers:
                for match in pattern.finditer(compact):
                    findings.append(
                        make_finding(
                            f"NAT-{finding_index:04d}",
                            source,
                            line_number,
                            dimension,
                            category,
                            "BLOCKER",
                            match.group(0),
                            compact[:220],
                            suggestion,
                            note,
                        )
                    )
                    finding_index += 1
        for line_number, line in enumerate(visible.splitlines(), start=1):
            compact = re.sub(r"\s+", " ", line).strip()
            if not compact:
                continue
            for (
                dimension,
                category,
                pattern,
                suggestion,
                note,
            ) in compiled_blockers:
                for match in pattern.finditer(compact):
                    findings.append(
                        make_finding(
                            f"NAT-{finding_index:04d}",
                            source,
                            line_number,
                            dimension,
                            category,
                            "BLOCKER",
                            match.group(0),
                            compact[:220],
                            suggestion,
                            note,
                        )
                    )
                    finding_index += 1
            for (
                dimension,
                category,
                pattern,
                suggestion,
                note,
            ) in compiled_advisories:
                for match in pattern.finditer(compact):
                    findings.append(
                        make_finding(
                            f"NAT-{finding_index:04d}",
                            source,
                            line_number,
                            dimension,
                            category,
                            "REVIEW",
                            match.group(0),
                            compact[:220],
                            suggestion,
                            note,
                        )
                    )
                    finding_index += 1

    combined_prose = "\n\n".join(prose_parts)
    combined_raw = "\n".join(raw_parts)
    characters = prose_characters(combined_prose)
    sentences = [
        item.strip()
        for item in re.split(r"[。！？!?；;]+", combined_prose)
        if prose_characters(item) >= 6
    ]
    lengths = [prose_characters(item) for item in sentences]
    sentence_cv = coefficient_of_variation(lengths)

    paragraphs = [
        re.sub(r"\s+", " ", item).strip()
        for item in re.split(r"\n\s*\n", combined_prose)
        if prose_characters(item) >= 20
    ]
    paragraph_lengths = [prose_characters(item) for item in paragraphs]
    paragraph_cv = coefficient_of_variation(paragraph_lengths)
    openings = Counter(
        sentence_opening(sentence)
        for sentence in sentences
        if len(sentence_opening(sentence)) >= 4
    )
    repeated_openings = {
        opening: count
        for opening, count in openings.items()
        if count >= thresholds["repeat_opening"]
    }

    connector_hits = sum(
        len(re.findall(pattern, combined_prose))
        for dimension, category, pattern, _, _ in ADVISORY_PATTERNS
        if category == "connector"
    )
    generic_categories = {
        "template_opening",
        "throat_clearing",
        "empty_significance",
        "empty_support",
        "inflated_framing",
        "formulaic_outlook",
        "vague_scope",
        "vague_attribution",
        "vague_comparative",
        "promotional_wording",
        "trend_buzzword",
        "generic_optimism",
        "chat_opening",
    }
    generic_hits = sum(
        1
        for finding in findings
        if finding["category"] in generic_categories
        and finding["severity"] == "REVIEW"
    )
    connector_density = connector_hits * 1000 / max(characters, 1)
    generic_density = generic_hits * 1000 / max(characters, 1)
    em_dash_hits = len(re.findall(r"—{1,2}", combined_prose))
    em_dash_density = em_dash_hits * 1000 / max(characters, 1)
    bold_hits = len(re.findall(r"\\textbf\s*\{", combined_raw))
    bold_density = bold_hits * 1000 / max(characters, 1)
    inline_header_hits = len(
        re.findall(
            r"\\item\s*(?:\\textbf\s*\{|\\bfseries\b)", combined_raw
        )
    )
    evidence_anchors = (
        len(CLAIM_PATTERN.findall(combined_raw))
        + len(REFERENCE_PATTERN.findall(combined_raw))
        + len(CITATION_PATTERN.findall(combined_raw))
        + len(NUMBER_PATTERN.findall(combined_raw))
    )
    evidence_anchor_density = evidence_anchors * 1000 / max(characters, 1)

    if len(lengths) >= 8 and sentence_cv is not None:
        if sentence_cv < thresholds["sentence_cv"]:
            findings.append(
                make_finding(
                    f"NAT-{finding_index:04d}",
                    "<document>",
                    0,
                    "D1",
                    "uniform_sentence_length",
                    "REVIEW",
                    f"sentence_length_cv={sentence_cv:.3f}",
                    f"{len(lengths)} sentences were measured",
                    "在不拆散公式解释和证据链的前提下，交替使用短结论句与较长推理句。",
                    "句长几乎一致会使技术叙述呈现机械节拍。",
                )
            )
            finding_index += 1

    if len(paragraph_lengths) >= 5 and paragraph_cv is not None:
        if paragraph_cv < thresholds["paragraph_cv"]:
            findings.append(
                make_finding(
                    f"NAT-{finding_index:04d}",
                    "<document>",
                    0,
                    "D2",
                    "uniform_paragraph_length",
                    "REVIEW",
                    f"paragraph_length_cv={paragraph_cv:.3f}",
                    f"{len(paragraph_lengths)} paragraphs were measured",
                    "按论证任务决定段落长度，不为整齐而机械等长。",
                    "段落长度过于均匀常意味着结构按模板切分，而非按信息单元切分。",
                )
            )
            finding_index += 1

    for opening, count in sorted(
        repeated_openings.items(), key=lambda item: (-item[1], item[0])
    ):
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D2",
                "repeated_sentence_opening",
                "REVIEW",
                opening,
                f"the same normalized opening occurs {count} times",
                "保留术语一致性，但让句子从对象、条件、证据或结论等不同信息位起笔。",
                "重复段首会把独立论证压成统一句模。",
            )
        )
        finding_index += 1

    if connector_density > thresholds["connector_density"]:
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D4",
                "connector_density",
                "REVIEW",
                f"{connector_density:.2f}/1000_chars",
                f"connector_hits={connector_hits}, prose_characters={characters}",
                "逐个检查连接词是否承担因果、转折或递进；删除仅用于维持语气的连接词。",
                "逻辑应主要由信息顺序和指代关系承载，而不是由连接词堆叠。",
            )
        )
        finding_index += 1

    if generic_density > thresholds["generic_density"]:
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D3",
                "generic_phrase_density",
                "REVIEW",
                f"{generic_density:.2f}/1000_chars",
                f"generic_hits={generic_hits}, prose_characters={characters}",
                "优先删除无证据套话；不能由批准 claim 支撑的强化词不得换成新数字。",
                "提高信息密度的正确方法是删除空话，不是补造指标。",
            )
        )
        finding_index += 1

    if em_dash_density > thresholds["em_dash_density"]:
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D4",
                "em_dash_density",
                "REVIEW",
                f"{em_dash_density:.2f}/1000_chars",
                f"em_dash_hits={em_dash_hits}, prose_characters={characters}",
                "逐处确认破折号是否承担必要插入或转折；可由逗号、分号或独立句表达时改写。",
                "破折号不是禁用符号，只有文档级密度超过当前编辑档位时才提示复核。",
            )
        )
        finding_index += 1

    if bold_density > thresholds["bold_density"]:
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D2",
                "bold_density",
                "REVIEW",
                f"{bold_density:.2f}/1000_chars",
                f"textbf_hits={bold_hits}, prose_characters={characters}",
                "仅保留有版式契约或阅读导航作用的粗体，其余交由标题层级和句子信息位承担。",
                "粗体不是禁用命令；提示只用于防止正文被标语式强调切碎。",
            )
        )
        finding_index += 1

    if inline_header_hits > thresholds["inline_header_limit"]:
        findings.append(
            make_finding(
                f"NAT-{finding_index:04d}",
                "<document>",
                0,
                "D2",
                "inline_header_list_density",
                "REVIEW",
                str(inline_header_hits),
                (
                    "list items beginning with textbf/bfseries; "
                    f"tier limit={thresholds['inline_header_limit']}"
                ),
                "把承担连续论证的项目改为段落；真正并列的定义、条件或步骤可保留列表。",
                "内联粗体列表只做文档级复核，不能机械改写算法步骤或约束清单。",
            )
        )
        finding_index += 1

    findings.sort(
        key=lambda item: (
            item["severity"] != "BLOCKER",
            item["source"],
            item["line"],
            item["id"],
        )
    )
    blockers = [item for item in findings if item["severity"] == "BLOCKER"]
    reviews = [item for item in findings if item["severity"] == "REVIEW"]
    dimension_counts = {
        dimension: sum(1 for item in findings if item["dimension"] == dimension)
        for dimension in ("D1", "D2", "D3", "D4", "D5")
    }
    return {
        "status": (
            "BLOCKED"
            if blockers
            else ("REVIEW_REQUIRED" if reviews else "CLEAN")
        ),
        "ruleset_version": "cumcm-humanizer-2.0",
        "tier": tier,
        "scope": [relative(project, path) for path in style_paths(project)],
        "metrics": {
            "prose_characters": characters,
            "sentences": len(lengths),
            "sentence_length_mean": (
                round(statistics.fmean(lengths), 3) if lengths else None
            ),
            "sentence_length_cv": (
                round(sentence_cv, 4) if sentence_cv is not None else None
            ),
            "paragraphs": len(paragraph_lengths),
            "paragraph_length_cv": (
                round(paragraph_cv, 4) if paragraph_cv is not None else None
            ),
            "connector_hits": connector_hits,
            "connector_density_per_1000_chars": round(connector_density, 3),
            "generic_phrase_hits": generic_hits,
            "generic_phrase_density_per_1000_chars": round(generic_density, 3),
            "em_dash_hits": em_dash_hits,
            "em_dash_density_per_1000_chars": round(em_dash_density, 3),
            "textbf_hits": bold_hits,
            "textbf_density_per_1000_chars": round(bold_density, 3),
            "inline_header_list_hits": inline_header_hits,
            "evidence_anchors": evidence_anchors,
            "evidence_anchor_density_per_1000_chars": round(
                evidence_anchor_density, 3
            ),
            "dimension_findings": dimension_counts,
        },
        "blocking_count": len(blockers),
        "review_count": len(reviews),
        "findings": findings,
        "interpretation": (
            "D1-D5 are local editing diagnostics, not an AI probability, "
            "detector score, or platform-pass prediction."
        ),
    }


def write_matrix(path: Path, findings: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "row_id",
        "source",
        "line",
        "pattern",
        "dimension",
        "severity",
        "applied_change",
        "expected_effect",
        "teaching_note",
        "status",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for finding in findings:
            writer.writerow(
                {
                    "row_id": finding["id"],
                    "source": finding["source"],
                    "line": finding["line"],
                    "pattern": (
                        f"{finding['category']}: {finding['phrase']} | "
                        f"{finding['context']}"
                    ),
                    "dimension": finding["dimension"],
                    "severity": finding["severity"],
                    "applied_change": "",
                    "expected_effect": finding["suggestion"],
                    "teaching_note": finding["teaching_note"],
                    "status": "open",
                }
            )


def load_naturalization_config(project: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    contract_path = project / "paper_contract.json"
    if not contract_path.is_file():
        raise FileNotFoundError("paper_contract.json is missing")
    contract = load_json(contract_path)
    config = contract.get("naturalization", {})
    if not isinstance(config, dict):
        raise ValueError("paper_contract.json naturalization must be an object")
    return contract, config


def output_paths(project: Path, config: dict[str, Any]) -> tuple[Path, Path, Path]:
    guard = resolve_inside(
        project,
        str(config.get("protected_snapshot", "reports/naturalization_guard.json")),
    )
    report = resolve_inside(
        project,
        str(config.get("verification_report", "reports/naturalization_report.json")),
    )
    matrix = resolve_inside(
        project,
        str(config.get("review_matrix", "reports/naturalization_matrix.csv")),
    )
    return guard, report, matrix


def build_report(
    mode: str,
    tier: str,
    round_number: int,
    max_rounds: int,
    guard_path: Path,
    project: Path,
    integrity: dict[str, Any],
    style: dict[str, Any],
    current_digest: str,
    guard_digest: str | None,
) -> dict[str, Any]:
    status = (
        "PASS"
        if integrity.get("status") in {"PASS", "SKIPPED"}
        and style.get("blocking_count", 0) == 0
        else "BLOCKED"
    )
    return {
        "schema_version": "1.0",
        "generated_at": now_iso(),
        "mode": mode,
        "status": status,
        "purpose": "CUMCM terminal academic-prose naturalization",
        "tier": tier,
        "round": round_number,
        "max_rounds": max_rounds,
        "no_detector_promise": True,
        "detector_percentage": None,
        "protected_integrity": {
            **integrity,
            "guard_path": relative(project, guard_path),
            "guard_digest": guard_digest,
            "verified_state_digest": current_digest,
        },
        "style_scan": style,
        "release_note": (
            "A PASS means protected manuscript content is unchanged and no "
            "forbidden chat, tool/citation/format residue, or detector claim "
            "remains. Advisory style findings still require documented semantic "
            "review; PASS is not a detector guarantee."
        ),
    }


def require_manuscript_gate(project: Path) -> None:
    report_path = project / "reports" / "manuscript_gate_report.json"
    if not report_path.is_file():
        raise ValueError(
            "run validate_project.py --phase manuscript before taking the snapshot"
        )
    report = load_json(report_path)
    if report.get("status") != "GATE_PASS":
        raise ValueError(
            "manuscript gate is not GATE_PASS; naturalization must not start"
        )


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Audit terminal CUMCM prose naturalization while protecting evidence, "
            "LaTeX, formulas, numbers, units, references, and answer macros."
        )
    )
    parser.add_argument("project_dir", type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--snapshot", action="store_true")
    mode.add_argument("--verify", action="store_true")
    mode.add_argument("--scan", action="store_true")
    parser.add_argument("--tier", choices=("light", "medium", "heavy"))
    parser.add_argument("--round", type=int, default=1)
    parser.add_argument(
        "--force",
        action="store_true",
        help="Replace an existing baseline snapshot after explicit review.",
    )
    args = parser.parse_args()

    project = args.project_dir.resolve()
    try:
        _, config = load_naturalization_config(project)
        tier = args.tier or str(config.get("tier", "medium"))
        if tier not in TIER_THRESHOLDS:
            raise ValueError(f"invalid naturalization tier: {tier}")
        max_rounds = int(config.get("max_rounds", 3))
        if max_rounds < 1 or max_rounds > 3:
            raise ValueError("naturalization.max_rounds must be between 1 and 3")
        if args.round < 0 or args.round > max_rounds:
            raise ValueError(
                f"--round must be between 0 and configured max_rounds={max_rounds}"
            )
        guard_path, report_path, matrix_path = output_paths(project, config)
        current_state = build_protected_state(project)
        current_digest = state_digest(current_state)
        style = scan_style(project, tier)

        if args.snapshot:
            require_manuscript_gate(project)
            if guard_path.exists() and not args.force:
                raise ValueError(
                    f"snapshot already exists: {guard_path}; use --force only "
                    "after explicitly reviewing the new baseline"
                )
            guard = {
                "schema_version": "1.0",
                "created_at": now_iso(),
                "purpose": "pre-naturalization protected manuscript baseline",
                "protected_state_digest": current_digest,
                "protected_state": current_state,
            }
            write_json(guard_path, guard)
            guard_digest = sha256_file(guard_path)
            integrity = {
                "status": "PASS",
                "failed_categories": [],
                "categories": {},
                "baseline_created": True,
            }
            mode_name = "snapshot"
            round_number = 0
        elif args.verify:
            if not guard_path.is_file():
                raise ValueError(
                    f"protected snapshot is missing: {guard_path}; run --snapshot first"
                )
            guard = load_json(guard_path)
            baseline = guard.get("protected_state")
            if not isinstance(baseline, dict):
                raise ValueError("naturalization guard has no protected_state object")
            baseline_digest = str(guard.get("protected_state_digest", ""))
            if baseline_digest != state_digest(baseline):
                raise ValueError("naturalization guard digest is internally inconsistent")
            integrity = compare_protected_states(baseline, current_state)
            guard_digest = sha256_file(guard_path)
            mode_name = "verify"
            round_number = args.round
        else:
            integrity = {
                "status": "SKIPPED",
                "failed_categories": [],
                "categories": {},
                "reason": "style-only scan; no protected comparison was requested",
            }
            guard_digest = sha256_file(guard_path) if guard_path.is_file() else None
            mode_name = "scan"
            round_number = args.round

        report = build_report(
            mode_name,
            tier,
            round_number,
            max_rounds,
            guard_path,
            project,
            integrity,
            style,
            current_digest,
            guard_digest,
        )
        write_json(report_path, report)
        write_matrix(matrix_path, style.get("findings", []))
    except (FileNotFoundError, ValueError, json.JSONDecodeError) as exc:
        print(f"naturalization audit error: {exc}", file=sys.stderr)
        return 2

    print(
        f"naturalization {mode_name}: {report['status']}; "
        f"integrity={integrity.get('status')}; "
        f"style={style.get('status')}; report={report_path}"
    )
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
