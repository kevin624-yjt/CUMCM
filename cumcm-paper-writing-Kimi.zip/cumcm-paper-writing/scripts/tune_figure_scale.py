from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from common import load_json, write_json


FIGURE_PATTERN = re.compile(
    r"\\begin\{figure\*?\}(?:\[[^\]]*\])?"
    r".*?"
    r"\\end\{figure\*?\}",
    flags=re.DOTALL,
)
IMAGE_PATTERN = re.compile(
    r"\\includegraphics(?:\[([^\]]*)\])?\{([^}]+)\}"
)


def number_from_contract(contract: dict, key: str, default: float) -> float:
    try:
        return float(contract.get("layout_contract", {}).get(key, default))
    except (TypeError, ValueError):
        return default


def replace_option(options: str, key: str, value: str) -> str:
    pattern = re.compile(rf"(?:^|,)\s*{re.escape(key)}\s*=\s*[^,]+")
    replacement = f"{key}={value}"
    if pattern.search(options):
        return pattern.sub(
            lambda match: ("," if match.group(0).lstrip().startswith(",") else "")
            + replacement,
            options,
            count=1,
        ).strip(", ")
    return ", ".join(part for part in (replacement, options.strip()) if part)


def current_width(options: str, default: float) -> float:
    match = re.search(r"width\s*=\s*(0?\.\d+)\\textwidth", options)
    return float(match.group(1)) if match else default


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Safely reduce one LaTeX figure while preserving readability."
    )
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--label", required=True, help="LaTeX label, for example fig:raw")
    parser.add_argument(
        "--width",
        type=float,
        default=None,
        help="Target width as a fraction of text width; omit to reduce by one step.",
    )
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    project = args.project_dir.resolve()
    contract_path = project / "paper_contract.json"
    contract = load_json(contract_path) if contract_path.is_file() else {}
    minimum = number_from_contract(contract, "figure_width_min", 0.78)
    maximum = number_from_contract(contract, "figure_width_max", 0.96)
    default = number_from_contract(contract, "figure_width_default", 0.90)
    step = number_from_contract(contract, "figure_scale_step", 0.04)
    max_height = number_from_contract(
        contract, "tall_figure_max_height_ratio", 0.60
    )

    label_token = rf"\label{{{args.label}}}"
    matches: list[tuple[Path, re.Match[str]]] = []
    for path in sorted((project / "sections").rglob("*.tex")):
        text = path.read_text(encoding="utf-8")
        for match in FIGURE_PATTERN.finditer(text):
            if label_token in match.group(0):
                matches.append((path, match))
    if len(matches) != 1:
        print(
            f"Expected exactly one figure with label {args.label!r}; found {len(matches)}",
            file=sys.stderr,
        )
        return 2

    path, figure_match = matches[0]
    figure_text = figure_match.group(0)
    images = list(IMAGE_PATTERN.finditer(figure_text))
    if len(images) != 1:
        print(
            "Automatic scaling only supports a single image per figure; "
            "split multi-image figures explicitly.",
            file=sys.stderr,
        )
        return 2

    image_match = images[0]
    options = image_match.group(1) or ""
    before = current_width(options, default)
    target = args.width if args.width is not None else before - step
    target = round(target, 2)
    if not minimum <= target <= maximum:
        print(
            f"Requested width {target:.2f} is outside "
            f"{minimum:.2f}..{maximum:.2f}; split the figure instead.",
            file=sys.stderr,
        )
        return 2

    updated_options = replace_option(options, "width", f"{target:.2f}\\textwidth")
    updated_options = replace_option(
        updated_options, "height", f"{max_height:.2f}\\textheight"
    )
    if not re.search(r"(?:^|,)\s*keepaspectratio(?:,|$)", updated_options):
        updated_options = updated_options.rstrip(", ") + ", keepaspectratio"
    replacement = rf"\includegraphics[{updated_options}]{{{image_match.group(2)}}}"
    updated_figure = (
        figure_text[: image_match.start()]
        + replacement
        + figure_text[image_match.end() :]
    )
    updated_text = (
        path.read_text(encoding="utf-8")[: figure_match.start()]
        + updated_figure
        + path.read_text(encoding="utf-8")[figure_match.end() :]
    )

    report = {
        "status": "APPLIED" if args.apply else "DRY_RUN",
        "label": args.label,
        "source": path.relative_to(project).as_posix(),
        "image": image_match.group(2),
        "width_before": before,
        "width_after": target,
        "minimum_width": minimum,
        "maximum_width": maximum,
        "max_height_ratio": max_height,
        "next_step": (
            "recompile and inspect suspicious_blank_body_pages"
            if args.apply
            else "rerun with --apply, then compile"
        ),
    }
    if args.apply:
        path.write_text(updated_text, encoding="utf-8", newline="\n")
    write_json(project / "reports" / "figure_scale_report.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
