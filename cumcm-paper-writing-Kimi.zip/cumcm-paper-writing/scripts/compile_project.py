from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from common import load_json, now_iso, read_text_best_effort, write_json


def find_tectonic(explicit: str | None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    if os.environ.get("TECTONIC_PATH"):
        candidates.append(Path(os.environ["TECTONIC_PATH"]))
    discovered = shutil.which("tectonic")
    if discovered:
        candidates.append(Path(discovered))
    cache = Path.home() / ".codex" / "plugins" / "cache" / "openai-bundled" / "latex"
    if cache.is_dir():
        candidates.extend(sorted(cache.glob("*/bin/tectonic.exe"), reverse=True))
        candidates.extend(sorted(cache.glob("*/bin/tectonic"), reverse=True))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None


def run_command(command: list[str], cwd: Path, timeout: int) -> subprocess.CompletedProcess:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def compile_tex(
    source: Path,
    output_dir: Path,
    engine: str,
    tectonic: Path | None,
    timeout: int,
) -> tuple[bool, str, Path | None, list[str]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    commands: list[list[str]] = []
    if engine == "tectonic":
        if tectonic is None:
            return False, "Tectonic not found", None, []
        commands = [
            [
                str(tectonic),
                source.name,
                "--outdir",
                str(output_dir),
                "--keep-logs",
                "--keep-intermediates",
                "--reruns",
                "2",
            ]
        ]
    elif engine == "latexmk":
        latexmk = shutil.which("latexmk")
        if not latexmk:
            return False, "latexmk not found", None, []
        commands = [
            [
                latexmk,
                "-xelatex",
                "-interaction=nonstopmode",
                "-halt-on-error",
                f"-outdir={output_dir}",
                source.name,
            ]
        ]
    elif engine == "xelatex":
        xelatex = shutil.which("xelatex")
        if not xelatex:
            return False, "xelatex not found", None, []
        command = [
            xelatex,
            "-interaction=nonstopmode",
            "-halt-on-error",
            f"-output-directory={output_dir}",
            source.name,
        ]
        commands = [command, command, command]
    else:
        return False, f"unsupported engine: {engine}", None, []

    logs: list[str] = []
    for command in commands:
        process = run_command(command, source.parent, timeout)
        logs.append(process.stdout)
        if process.returncode != 0:
            return False, "\n".join(logs), None, command
    pdf = output_dir / f"{source.stem}.pdf"
    return pdf.is_file(), "\n".join(logs), pdf if pdf.is_file() else None, commands[-1]


def inspect_pdf(
    pdf_path: Path,
    log_text: str,
    render_dir: Path,
    tail_whitespace_threshold: float = 0.25,
) -> dict[str, Any]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        return {
            "compile_success": False,
            "severe_log_issues": [f"pypdf is required for inspection: {exc}"],
        }

    reader = PdfReader(str(pdf_path))
    page_texts: list[str] = []
    page_sizes: list[dict[str, float]] = []
    for page in reader.pages:
        page_texts.append(page.extract_text() or "")
        box = page.mediabox
        page_sizes.append(
            {
                "width_pt": round(float(box.width), 2),
                "height_pt": round(float(box.height), 2),
            }
        )

    appendix_page: int | None = None
    for index, text in enumerate(page_texts[1:], start=1):
        normalized = re.sub(r"\s+", "", text)
        if (
            "CUMCM-APPENDIX-START" in normalized
            or "附录：支撑材料文件清单" in normalized
        ):
            appendix_page = index + 1
            break
    body_pages = appendix_page - 2 if appendix_page is not None else None

    severe_patterns = {
        "undefined control sequence": r"Undefined control sequence",
        "fatal error": r"(?:Fatal error|Emergency stop)",
        "LaTeX error": r"! LaTeX Error",
        "undefined references": r"There were undefined references",
        "undefined citations": r"Citation .+ undefined",
        "overfull box": r"Overfull \\[hv]box",
    }
    severe = [
        name for name, pattern in severe_patterns.items() if re.search(pattern, log_text)
    ]
    if appendix_page is None:
        severe.append("appendix start marker not found; body pages cannot be counted")
    a4_outliers = [
        index + 1
        for index, size in enumerate(page_sizes)
        if abs(size["width_pt"] - 595.28) > 3
        or abs(size["height_pt"] - 841.89) > 3
    ]
    if a4_outliers:
        severe.append(f"non-A4 page boxes: {a4_outliers}")

    rendered_pages = 0
    render_error = ""
    page_layout_metrics: list[dict[str, Any]] = []
    suspicious_blank_body_pages: list[int] = []
    try:
        import pypdfium2 as pdfium

        render_dir.mkdir(parents=True, exist_ok=True)
        document = pdfium.PdfDocument(str(pdf_path))
        for index in range(len(document)):
            page = document[index]
            image = page.render(scale=1.5).to_pil()
            image.save(render_dir / f"page-{index + 1:03d}.png")
            rendered_pages += 1

            grayscale = image.convert("L")
            width, height = grayscale.size
            body_box = (
                int(width * 0.07),
                int(height * 0.07),
                int(width * 0.93),
                int(height * 0.89),
            )
            body = grayscale.crop(body_box)
            ink = body.point(lambda value: 255 if value < 245 else 0)
            ink_box = ink.getbbox()
            if ink_box is None:
                tail_ratio = 1.0
                content_height_ratio = 0.0
            else:
                tail_ratio = (body.height - ink_box[3]) / body.height
                content_height_ratio = (ink_box[3] - ink_box[1]) / body.height
            page_number = index + 1
            is_body_page = (
                appendix_page is not None
                and 2 <= page_number < appendix_page
            )
            suspicious = (
                is_body_page
                and tail_ratio > tail_whitespace_threshold
                and content_height_ratio >= 0.08
            )
            if suspicious:
                suspicious_blank_body_pages.append(page_number)
            page_layout_metrics.append(
                {
                    "page": page_number,
                    "tail_whitespace_ratio": round(tail_ratio, 3),
                    "content_height_ratio": round(content_height_ratio, 3),
                    "suspicious_large_bottom_whitespace": suspicious,
                }
            )
    except Exception as exc:  # Rendering is diagnostic; retain the compile report.
        render_error = f"{type(exc).__name__}: {exc}"
        severe.append(f"page rendering failed: {render_error}")

    if suspicious_blank_body_pages:
        severe.append(
            "large bottom whitespace on body page(s): "
            + ", ".join(str(page) for page in suspicious_blank_body_pages)
        )

    empty_text_pages = [
        index + 1 for index, text in enumerate(page_texts) if len(text.strip()) < 8
    ]
    return {
        "compile_success": True,
        "generated_at": now_iso(),
        "pdf_path": str(pdf_path),
        "file_size_bytes": pdf_path.stat().st_size,
        "total_pages": len(reader.pages),
        "abstract_pages": 1,
        "appendix_page": appendix_page,
        "body_pages": body_pages,
        "first_page_text": page_texts[0][:6000] if page_texts else "",
        "extractable_characters": sum(len(text.strip()) for text in page_texts),
        "empty_text_pages": empty_text_pages,
        "page_sizes": page_sizes,
        "rendered_pages": rendered_pages,
        "render_dir": str(render_dir),
        "render_error": render_error,
        "layout_tail_whitespace_threshold": tail_whitespace_threshold,
        "page_layout_metrics": page_layout_metrics,
        "suspicious_blank_body_pages": suspicious_blank_body_pages,
        "severe_log_issues": severe,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Compile and inspect a CUMCM LaTeX project."
    )
    parser.add_argument("project_dir", type=Path)
    parser.add_argument(
        "--engine", choices=("auto", "tectonic", "latexmk", "xelatex"), default="auto"
    )
    parser.add_argument("--tectonic", default=None)
    parser.add_argument("--timeout", type=int, default=240)
    parser.add_argument(
        "--skip-ai-detail",
        action="store_true",
        help="Do not compile support/ai-usage-detail.tex.",
    )
    parser.add_argument(
        "--skip-support-build",
        action="store_true",
        help="Compile a draft without rebuilding the support archive and appendix list.",
    )
    parser.add_argument(
        "--run-support-checks",
        action="store_true",
        help="Execute manifest run commands while rebuilding support materials.",
    )
    args = parser.parse_args()

    project = args.project_dir.resolve()
    source = project / "main.tex"
    if not source.is_file():
        print(f"Missing {source}", file=sys.stderr)
        return 2

    render_script = Path(__file__).with_name("render_claims.py")
    rendered = run_command([sys.executable, str(render_script), str(project)], project, 60)
    if rendered.returncode != 0:
        print(rendered.stdout, file=sys.stderr)
        return 2

    tectonic = find_tectonic(args.tectonic)
    engine = args.engine
    if engine == "auto":
        if tectonic is not None:
            engine = "tectonic"
        elif shutil.which("latexmk"):
            engine = "latexmk"
        else:
            engine = "xelatex"

    build_dir = project / "build"
    success, log_text, built_pdf, command = compile_tex(
        source, build_dir, engine, tectonic, args.timeout
    )
    log_path = build_dir / "compile.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(log_text, encoding="utf-8", newline="\n")
    if not success or built_pdf is None:
        report = {
            "compile_success": False,
            "generated_at": now_iso(),
            "engine": engine,
            "command": command,
            "log_path": str(log_path),
            "severe_log_issues": ["LaTeX compilation failed"],
        }
        write_json(project / "reports" / "pdf_inspection.json", report)
        print(f"LaTeX compilation failed; see {log_path}", file=sys.stderr)
        return 2

    paper_pdf = project / "paper.pdf"
    shutil.copy2(built_pdf, paper_pdf)

    contract = load_json(project / "paper_contract.json")
    ai_report: dict[str, Any] = {"required": False}
    if contract.get("ai_use", {}).get("used") is True and not args.skip_ai_detail:
        ai_report["required"] = True
        ai_source = project / "support" / "ai-usage-detail.tex"
        if ai_source.is_file():
            ai_build_dir = project / "build" / "ai-detail"
            ai_success, ai_log, ai_pdf, ai_command = compile_tex(
                ai_source, ai_build_dir, engine, tectonic, args.timeout
            )
            (ai_build_dir / "compile.log").write_text(
                ai_log, encoding="utf-8", newline="\n"
            )
            if ai_success and ai_pdf is not None:
                target = project / str(contract["ai_use"]["detail_file"])
                target.parent.mkdir(parents=True, exist_ok=True)
                if ai_pdf.resolve() != target.resolve():
                    shutil.copy2(ai_pdf, target)
                ai_report.update(
                    {
                        "success": True,
                        "pdf_path": str(target),
                        "command": ai_command,
                    }
                )
            else:
                ai_report.update(
                    {
                        "success": False,
                        "error": "AI detail LaTeX compilation failed",
                        "command": ai_command,
                    }
                )
        else:
            ai_report.update(
                {"success": False, "error": f"missing AI detail source: {ai_source}"}
            )

    support_report: dict[str, Any] = {"required": not args.skip_support_build}
    if not args.skip_support_build:
        support_script = Path(__file__).with_name("build_support_package.py")
        support_command = [sys.executable, str(support_script), str(project)]
        if args.run_support_checks:
            support_command.append("--run-checks")
        support_process = run_command(support_command, project, args.timeout)
        support_report.update(
            {
                "success": support_process.returncode == 0,
                "command": support_command,
                "output": support_process.stdout[-4000:],
            }
        )

        # Recompile after the support builder generates the appendix file list.
        final_success, final_log, final_pdf, final_command = compile_tex(
            source, build_dir, engine, tectonic, args.timeout
        )
        log_text = log_text + "\n\n===== FINAL PASS AFTER SUPPORT BUILD =====\n" + final_log
        log_path.write_text(log_text, encoding="utf-8", newline="\n")
        if not final_success or final_pdf is None:
            report = {
                "compile_success": False,
                "generated_at": now_iso(),
                "engine": engine,
                "command": final_command,
                "log_path": str(log_path),
                "support_package": support_report,
                "severe_log_issues": [
                    "final LaTeX compilation after support build failed"
                ],
            }
            write_json(project / "reports" / "pdf_inspection.json", report)
            print(f"Final LaTeX compilation failed; see {log_path}", file=sys.stderr)
            return 2
        built_pdf = final_pdf
        command = final_command
        shutil.copy2(built_pdf, paper_pdf)

    layout_contract = contract.get("layout_contract", {})
    try:
        tail_whitespace_threshold = float(
            layout_contract.get("max_body_tail_whitespace_ratio", 0.25)
        )
    except (TypeError, ValueError):
        tail_whitespace_threshold = 0.25
    inspection = inspect_pdf(
        paper_pdf,
        log_text,
        build_dir / "rendered",
        tail_whitespace_threshold=tail_whitespace_threshold,
    )
    inspection.update(
        {
            "engine": engine,
            "compiler_path": str(tectonic) if engine == "tectonic" else engine,
            "command": command,
            "log_path": str(log_path),
            "ai_detail": ai_report,
            "support_package": support_report,
        }
    )
    if ai_report.get("required") and ai_report.get("success") is not True:
        inspection.setdefault("severe_log_issues", []).append(
            "AI usage detail PDF was not compiled"
        )
    if support_report.get("required") and support_report.get("success") is not True:
        inspection.setdefault("severe_log_issues", []).append(
            "support package build failed"
        )
    report_path = project / "reports" / "pdf_inspection.json"
    write_json(report_path, inspection)
    print(
        f"Compiled {paper_pdf}; pages={inspection.get('total_pages')}, "
        f"body_pages={inspection.get('body_pages')}, rendered={inspection.get('rendered_pages')}"
    )
    if inspection.get("severe_log_issues"):
        print("Inspection blockers: " + "; ".join(inspection["severe_log_issues"]))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
