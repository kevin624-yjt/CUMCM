from __future__ import annotations

import argparse
import csv
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from common import latex_escape, load_json, unique


def format_value(value: Any, precision: Any) -> str:
    if value is None:
        return "[MISSING]"
    if isinstance(value, bool):
        return str(value)
    try:
        digits = int(precision)
        number = Decimal(str(value))
        return f"{number:.{digits}f}"
    except (InvalidOperation, TypeError, ValueError):
        return str(value)


def macro_definition(claim_id: str, field: str, value: Any) -> str:
    escaped = latex_escape(value)
    return rf"\expandafter\def\csname claim@{claim_id}@{field}\endcsname{{{escaped}}}"


def write_matrix(project: Path, claims: list[dict]) -> None:
    fields = [
        "question_id",
        "task",
        "model_name",
        "core_relation",
        "solver",
        "result_ids",
        "validation_ids",
        "figure_table_ids",
        "answer_sentence",
        "status",
    ]
    with (project / "paper_claim_matrix.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for claim in claims:
            solver = claim.get("solver", {})
            result = claim.get("result", {})
            writer.writerow(
                {
                    "question_id": claim.get("question_id", ""),
                    "task": claim.get("task", ""),
                    "model_name": claim.get("model_name", ""),
                    "core_relation": " | ".join(claim.get("core_relations", [])),
                    "solver": " | ".join(
                        unique(
                            [
                                str(solver.get("method", "")),
                                str(solver.get("parameters", "")),
                                str(solver.get("termination", "")),
                            ]
                        )
                    ),
                    "result_ids": " | ".join(result.get("source_ids", [])),
                    "validation_ids": " | ".join(claim.get("validation_ids", [])),
                    "figure_table_ids": " | ".join(
                        claim.get("figure_table_ids", [])
                    ),
                    "answer_sentence": claim.get("answer_sentence", ""),
                    "status": "complete" if claim.get("approved") else "incomplete",
                }
            )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Render approved claims into a generated LaTeX macro file."
    )
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()

    project = args.project_dir.resolve()
    registry = load_json(project / "claim_registry.json")
    contract = load_json(project / "paper_contract.json")
    claims = registry.get("claims", [])
    lines = [
        "% Generated from claim_registry.json. Do not edit by hand.",
        "% Deterministic output: identical registry and contract produce identical TeX.",
    ]
    title = str(contract.get("title", "")).strip() or "[MISSING:TITLE]"
    ai_enabled = 1 if contract.get("ai_use", {}).get("used") is True else 0
    lines.extend(
        [
            rf"\newcommand{{\PaperTitle}}{{{latex_escape(title)}}}",
            rf"\newcommand{{\AIUseEnabled}}{{{ai_enabled}}}",
        ]
    )
    missing = 0
    for claim in claims:
        claim_id = str(claim.get("claim_id", "")).strip()
        if not claim_id:
            continue
        approved = claim.get("approved") is True
        result = claim.get("result", {})
        if approved:
            value = format_value(result.get("value"), result.get("precision", 3))
            unit = result.get("unit", "")
            answer = claim.get("answer_sentence", "")
            scope = claim.get("scope", "")
        else:
            missing += 1
            value = f"[UNAPPROVED:{claim_id}]"
            unit = ""
            answer = f"[UNAPPROVED:{claim_id}]"
            scope = ""
        lines.extend(
            [
                macro_definition(claim_id, "value", value),
                macro_definition(claim_id, "unit", unit),
                macro_definition(claim_id, "answer", answer),
                macro_definition(claim_id, "scope", scope),
            ]
        )

    output = project / "generated" / "claims.tex"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    write_matrix(project, claims)
    print(f"Rendered {len(claims)} claims to {output}")
    if missing:
        print(f"Warning: {missing} claim(s) are unapproved and rendered as blockers.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
