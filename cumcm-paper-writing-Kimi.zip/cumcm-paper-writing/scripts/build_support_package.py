from __future__ import annotations

import argparse
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

from common import (
    latex_escape,
    load_json,
    now_iso,
    read_text_best_effort,
    resolve_inside,
    sha256_file,
    unique,
    write_json,
)


def scan_sensitive(path: Path, terms: list[str]) -> list[str]:
    hits: list[str] = []
    path_text = str(path)
    for term in terms:
        if term and term in path_text:
            hits.append(f"{path}: sensitive term in path: {term}")
    if path.suffix.lower() in {
        ".bib",
        ".csv",
        ".json",
        ".md",
        ".py",
        ".r",
        ".tex",
        ".txt",
        ".yaml",
        ".yml",
    }:
        text = read_text_best_effort(path)
        for term in terms:
            if term and term in text:
                hits.append(f"{path}: sensitive term in content: {term}")
    return hits


def run_execution_check(
    project: Path, item: dict[str, Any], timeout: int
) -> tuple[bool, str]:
    command = item.get("run_command")
    if not isinstance(command, list) or not command or not all(
        isinstance(part, str) and part for part in command
    ):
        return False, "run_command must be a non-empty argv list"
    try:
        process = subprocess.run(
            command,
            cwd=project,
            text=True,
            encoding="utf-8",
            errors="replace",
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"{type(exc).__name__}: {exc}"
    output = process.stdout[-2000:]
    return process.returncode == 0, f"returncode={process.returncode}; output={output}"


def write_appendix_list(project: Path, files: list[dict[str, Any]]) -> Path:
    lines = [
        "% Generated from support_manifest.json. Do not edit by hand.",
        r"\begin{longtable}{p{0.34\textwidth}p{0.52\textwidth}}",
        r"\toprule",
        r"文件 & 作用 \\",
        r"\midrule",
        r"\endhead",
    ]
    for item in files:
        lines.append(
            f"{latex_escape(item['path'])} & {latex_escape(item.get('role', ''))} \\\\"
        )
    if not files:
        lines.append(r"无 & 本论文没有支撑材料。\\")
    lines.extend([r"\bottomrule", r"\end{longtable}"])
    output = project / "generated" / "support-list.tex"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build and verify a CUMCM support-material archive."
    )
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--run-checks", action="store_true")
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    project = args.project_dir.resolve()
    manifest_path = project / "support_manifest.json"
    contract_path = project / "paper_contract.json"
    if not manifest_path.is_file() or not contract_path.is_file():
        print("support_manifest.json and paper_contract.json are required", file=sys.stderr)
        return 2
    manifest = load_json(manifest_path)
    contract = load_json(contract_path)
    files = manifest.get("files", [])
    if not isinstance(files, list):
        print("support_manifest.json files must be a list", file=sys.stderr)
        return 2
    excluded_files = manifest.get("excluded_files", [])
    if not isinstance(excluded_files, list):
        print("support_manifest.json excluded_files must be a list", file=sys.stderr)
        return 2

    errors: list[str] = []
    warnings: list[str] = []
    resolved: list[tuple[dict[str, Any], Path]] = []
    seen_paths: set[str] = set()
    excluded_paths: set[str] = set()
    executable_count = 0
    terms = [
        str(term).strip()
        for term in contract.get("anonymity_terms", [])
        if str(term).strip()
    ]
    terms.extend(["学校名称", "队伍名称", "参赛队号", "指导教师姓名"])
    terms = unique(terms)

    for item in excluded_files:
        if not isinstance(item, dict):
            errors.append("excluded_files entries must be objects")
            continue
        relative = str(item.get("path", "")).replace("\\", "/").strip()
        reason = str(item.get("reason", "")).strip()
        if not relative or not reason:
            errors.append("excluded file needs path and reason")
            continue
        try:
            resolve_inside(project, relative)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        excluded_paths.add(relative)

    for item in files:
        relative = str(item.get("path", "")).replace("\\", "/").strip()
        if not relative:
            errors.append("manifest item without path")
            continue
        if relative in seen_paths:
            errors.append(f"duplicate manifest path: {relative}")
            continue
        seen_paths.add(relative)
        try:
            path = resolve_inside(project, relative)
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if item.get("required", True) and not path.is_file():
            errors.append(f"required support file missing: {relative}")
            continue
        if not path.is_file():
            warnings.append(f"optional support file missing: {relative}")
            continue
        item["sha256"] = sha256_file(path)
        item["size_bytes"] = path.stat().st_size
        resolved.append((item, path))
        errors.extend(scan_sensitive(path, terms))
        if path.suffix.lower() in {
            ".bib",
            ".csv",
            ".json",
            ".md",
            ".py",
            ".r",
            ".tex",
            ".txt",
            ".yaml",
            ".yml",
        }:
            text = read_text_best_effort(path)
            if "[MISSING:" in text or "<<MISSING" in text or "TODO" in text:
                errors.append(f"unresolved placeholder in support file: {relative}")
        if item.get("executable") is True:
            executable_count += 1
            if args.run_checks:
                passed, detail = run_execution_check(project, item, args.timeout)
                item["execution_check"] = {
                    "status": "PASS" if passed else "FAIL",
                    "checked_at": now_iso(),
                    "detail": detail,
                }
                if not passed:
                    errors.append(f"execution check failed: {relative}: {detail}")
            elif item.get("execution_check", {}).get("status") != "PASS":
                warnings.append(f"execution not checked in this build: {relative}")

    programs_used = contract.get("programs_used") is True
    if programs_used and executable_count == 0:
        errors.append("paper_contract says programs_used=true but no executable file exists")
    if not programs_used and executable_count:
        errors.append("executable files exist but paper_contract says programs_used=false")
    if not files and manifest.get("no_support_materials") is not True:
        errors.append("support manifest is empty without no_support_materials=true")

    ai = contract.get("ai_use", {})
    if ai.get("used") is True:
        detail_file = str(ai.get("detail_file", "")).replace("\\", "/")
        if detail_file not in seen_paths:
            errors.append(f"AI detail PDF is not listed in support manifest: {detail_file}")
        try:
            detail_path = resolve_inside(project, detail_file)
            if not detail_path.is_file():
                errors.append(f"AI detail PDF is missing: {detail_file}")
        except ValueError as exc:
            errors.append(str(exc))

    candidate_roots = ("code", "data", "figures", "results", "support")
    ignored_suffixes = {".aux", ".log", ".synctex", ".xdv"}
    ignored_names = {".gitkeep"}
    unlisted: list[str] = []
    for root_name in candidate_roots:
        root = project / root_name
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(project).as_posix()
            if path.name in ignored_names or path.suffix.lower() in ignored_suffixes:
                continue
            if relative not in seen_paths and relative not in excluded_paths:
                unlisted.append(relative)
    if unlisted:
        errors.extend(
            f"support-relevant file is neither manifested nor excluded: {path}"
            for path in sorted(unlisted)
        )

    write_json(manifest_path, manifest)
    appendix_path = write_appendix_list(project, files)

    archive_path = project / "build" / "support-materials.zip"
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    if archive_path.exists():
        archive_path.unlink()
    metadata_files = [
        manifest_path,
        project / "claim_registry.json",
        project / "paper_claim_matrix.csv",
    ]
    for path in metadata_files:
        if path.is_file():
            errors.extend(scan_sensitive(path, terms))
    try:
        with zipfile.ZipFile(
            archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for item, path in resolved:
                archive.write(path, arcname=str(item["path"]).replace("\\", "/"))
            for path in metadata_files:
                if path.is_file():
                    archive.write(path, arcname=path.name)
    except OSError as exc:
        errors.append(f"archive creation failed: {exc}")

    archive_size = archive_path.stat().st_size if archive_path.is_file() else None
    if isinstance(archive_size, int) and archive_size > 20 * 1024 * 1024:
        errors.append(f"support archive exceeds 20 MB: {archive_size} bytes")
    status = "PASS" if not errors else "BLOCKED"
    report = {
        "schema_version": "1.0",
        "generated_at": now_iso(),
        "status": status,
        "archive_path": str(archive_path),
        "archive_size_bytes": archive_size,
        "manifest_file_count": len(files),
        "included_file_count": len(resolved),
        "executable_file_count": executable_count,
        "execution_checks_run": args.run_checks,
        "appendix_list": str(appendix_path),
        "errors": errors,
        "warnings": warnings,
    }
    report_path = project / "reports" / "support_build_report.json"
    write_json(report_path, report)
    print(
        f"support package: {status}; files={len(resolved)}, "
        f"size={archive_size}, report={report_path}"
    )
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
