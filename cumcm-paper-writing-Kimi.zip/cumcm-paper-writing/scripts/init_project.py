from __future__ import annotations

import argparse
import csv
import shutil
import sys
from pathlib import Path

from common import normalize_question_ids, now_iso, write_json
from rubric import new_quality_assessment


def build_question_claim(question_id: str) -> dict:
    claim_id = f"{question_id}-MAIN"
    return {
        "claim_id": claim_id,
        "claim_type": "answer",
        "question_id": question_id,
        "task": "",
        "model_name": "",
        "model_choice_reason": "",
        "variables": [],
        "assumptions": [],
        "core_relations": [],
        "solver": {
            "method": "",
            "parameters": "",
            "termination": "",
        },
        "result": {
            "value": None,
            "unit": "",
            "precision": 3,
            "source_ids": [],
            "derivation": None,
        },
        "validation_ids": [],
        "figure_table_ids": [],
        "answer_sentence": "",
        "scope": "",
        "allowed_sections": ["abstract", question_id, "conclusion"],
        "approved": False,
    }


def write_claim_matrix(project: Path, claims: list[dict]) -> None:
    fields = [
        "question_id",
        "task",
        "model_name",
        "core_relation",
        "solver",
        "result_ids",
        "validation_ids",
        "figure_table_ids",
        "answer_sentence",
        "status",
    ]
    with (project / "paper_claim_matrix.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for claim in claims:
            writer.writerow(
                {
                    "question_id": claim["question_id"],
                    "task": claim["task"],
                    "model_name": claim["model_name"],
                    "core_relation": "",
                    "solver": "",
                    "result_ids": "",
                    "validation_ids": "",
                    "figure_table_ids": "",
                    "answer_sentence": "",
                    "status": "incomplete",
                }
            )


def write_questions(project: Path, question_ids: list[str]) -> None:
    questions_dir = project / "sections" / "question-parts"
    questions_dir.mkdir(parents=True, exist_ok=True)
    for existing in questions_dir.glob("*.tex"):
        existing.unlink()
    includes: list[str] = []
    for index, question_id in enumerate(question_ids, start=1):
        filename = question_id.lower().replace("_", "-") + ".tex"
        includes.append(rf"\input{{sections/question-parts/{filename[:-4]}}}")
        content = rf"""\section{{问题 {index}}}
\label{{sec:{question_id.lower()}}}

\subsection{{本问目标}}
% 写清输入、输出、难点和与前问关系。

\subsection{{建模选择}}
% 先给选择理由，再给模型名称；比较明显替代方案。

\subsection{{数学表达}}
% 定义变量、目标、约束、核心关系和适用条件。

\subsection{{求解方法}}
% 记录真实算法步骤、参数、终止条件和输出。

\subsection{{结果与解释}}
% 使用 \ClaimValue{{{question_id}-MAIN}} 和 \ClaimUnit{{{question_id}-MAIN}}。

\subsection{{本问回答与检验}}
\ClaimAnswer{{{question_id}-MAIN}}
% 紧接具体检验、范围和结果。
"""
        (questions_dir / filename).write_text(content, encoding="utf-8", newline="\n")
    (project / "sections" / "questions.tex").write_text(
        "\n".join(includes) + "\n", encoding="utf-8", newline="\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Initialize a CUMCM paper project.")
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--questions", default="Q1,Q2,Q3,Q4")
    parser.add_argument("--target-pages", type=int, default=29)
    args = parser.parse_args()

    question_ids = normalize_question_ids(args.questions)
    if not 28 <= args.target_pages <= 30:
        parser.error("--target-pages must be between 28 and 30")

    project = args.project_dir.resolve()
    if project.exists() and any(project.iterdir()):
        print(f"Refusing to overwrite non-empty directory: {project}", file=sys.stderr)
        return 2

    template = Path(__file__).resolve().parents[1] / "assets" / "project-template"
    if not template.is_dir():
        print(f"Template not found: {template}", file=sys.stderr)
        return 2
    shutil.copytree(template, project, dirs_exist_ok=True)
    for directory in (
        "build",
        "code",
        "data",
        "figures",
        "generated",
        "reports",
        "results",
        "support",
    ):
        (project / directory).mkdir(parents=True, exist_ok=True)

    claims = [build_question_claim(question_id) for question_id in question_ids]
    write_json(
        project / "paper_contract.json",
        {
            "schema_version": "1.0",
            "created_at": now_iso(),
            "competition": "CUMCM",
            "rules_profile": "current-cumulative",
            "electronic_submission": True,
            "question_ids": question_ids,
            "title": "",
            "body_page_contract": {
                "target_min": 28,
                "target_max": 30,
                "hard_max": 30,
                "short_body_exception": {
                    "approved": False,
                    "reviewer": "",
                    "rationale": "",
                },
            },
            "layout_contract": {
                "max_body_tail_whitespace_ratio": 0.25,
                "figure_width_default": 0.90,
                "figure_width_min": 0.78,
                "figure_width_max": 0.96,
                "figure_scale_step": 0.04,
                "tall_figure_max_height_ratio": 0.60,
            },
            "naturalization": {
                "enabled": True,
                "tier": "medium",
                "max_rounds": 3,
                "no_detector_promise": True,
                "protected_snapshot": "reports/naturalization_guard.json",
                "verification_report": "reports/naturalization_report.json",
                "review_matrix": "reports/naturalization_matrix.csv",
            },
            "programs_used": True,
            "anonymity_terms": [],
            "ai_use": {
                "used": True,
                "reference_key": "ai-assistant",
                "detail_file": "support/AI工具使用详情.pdf",
            },
        },
    )
    write_json(
        project / "claim_registry.json",
        {
            "schema_version": "1.0",
            "generated_at": now_iso(),
            "evidence": [],
            "claims": claims,
        },
    )
    write_claim_matrix(project, claims)
    outline_lines = [
        "# 论文主线与提纲",
        "",
        "## 200 字内主线",
        "",
        "[填写各问如何由统一对象、变量或约束逐层递进。]",
        "",
        "## 章节提纲",
        "",
        "1. 问题重述与分析",
        "2. 模型假设与主要符号",
        "3. 数据处理与共用基础模型",
    ]
    for index, question_id in enumerate(question_ids, start=1):
        outline_lines.append(
            f"{index + 3}. {question_id}：目标、选择、表达、求解、结果、检验"
        )
    offset = len(question_ids) + 4
    outline_lines.extend(
        [
            f"{offset}. 综合检验、误差与敏感性",
            f"{offset + 1}. 模型评价与结论",
            f"{offset + 2}. 参考文献",
            f"{offset + 3}. 附录与支撑材料文件清单",
        ]
    )
    (project / "paper_outline.md").write_text(
        "\n".join(outline_lines) + "\n", encoding="utf-8", newline="\n"
    )

    common_pages = 11
    per_question = max(2.0, (args.target_pages - common_pages) / len(question_ids))
    write_json(
        project / "page_budget.json",
        {
            "target_body_pages": args.target_pages,
            "sections": {
                "problem_analysis": 2,
                "assumptions_symbols": 2,
                "shared_model_data": 4,
                "questions_total": round(per_question * len(question_ids), 1),
                "validation": 2,
                "evaluation_conclusion_references": 3,
            },
            "questions": [
                {
                    "question_id": question_id,
                    "complexity_weights": {
                        "new_model": 1,
                        "derivation": 1,
                        "constraints_cases": 1,
                        "figures_results": 1,
                        "validation": 1,
                        "shared_reuse": 1,
                    },
                    "allocated_pages": round(per_question, 1),
                }
                for question_id in question_ids
            ],
            "note": "Reallocate by evidence complexity; do not pad with background.",
        },
    )
    write_json(
        project / "support_manifest.json",
        {
            "schema_version": "1.0",
            "no_support_materials": False,
            "excluded_files": [],
            "files": [
                {
                    "path": "support/AI工具使用详情.pdf",
                    "role": "按现行规则披露人工智能工具使用情况",
                    "required": True,
                    "executable": False,
                    "run_command": [],
                    "expected_outputs": [],
                    "sha256": "",
                },
                {
                    "path": "support/ai-usage-detail.tex",
                    "role": "AI 工具使用详情的可复编源文件",
                    "required": True,
                    "executable": False,
                    "run_command": [],
                    "expected_outputs": ["support/AI工具使用详情.pdf"],
                    "sha256": "",
                },
            ],
        },
    )
    write_json(
        project / "figure_manifest.json",
        {
            "schema_version": "1.0",
            "paper_preset": {
                "inside_title": False,
                "preferred_data_master": "pdf",
                "preferred_diagram_master": "png",
                "direct_svg_in_latex": False,
                "minimum_raster_long_side_px": 1600,
                "minimum_raster_short_side_px": 900,
            },
            "assets": [],
        },
    )
    checks = {}
    for key in (
        "question_closure",
        "paragraph_cohesion",
        "model_structure",
        "formula_explanation",
        "figure_table_quality",
        "citation_integrity",
        "chapter_completeness",
        "conclusion_correspondence",
        "naturalization_semantics",
        "abstract_semantics",
        "symbols_units",
        "no_fabrication",
        "figure_readability",
        "visual_layout",
        "anonymity",
        "overclaim_causality",
        "citation_authenticity",
        "code_reproducibility",
    ):
        checks[key] = {
            "approved": False,
            "reviewer": "",
            "checked_at": "",
            "evidence": [],
        }
    write_json(project / "release_approvals.json", {"checks": checks})
    write_json(project / "quality_assessment.json", new_quality_assessment())
    write_json(
        project / "pattern_selection.json",
        {
            "abstract": {"selected": "", "rejected": [], "reason": ""},
            "method": {"selected": "", "rejected": [], "reason": ""},
            "results_validation": {"selected": "", "rejected": [], "reason": ""},
            "conclusion": {"selected": "", "rejected": [], "reason": ""},
        },
    )
    write_questions(project, question_ids)
    print(f"Initialized CUMCM project at {project}")
    print(f"Questions: {', '.join(question_ids)}; target body pages: {args.target_pages}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
