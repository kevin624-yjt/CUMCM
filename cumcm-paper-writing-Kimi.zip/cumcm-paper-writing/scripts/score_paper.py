from __future__ import annotations

import argparse
import sys
from math import isclose
from pathlib import Path
from typing import Any

from common import load_json, now_iso, write_json
from rubric import (
    CRITERIA,
    CRITERIA_BY_ID,
    DIMENSION_MAXIMA,
    RUBRIC_VERSION,
    SECTION_RUBRIC,
    readiness_floor,
)


# Compatibility alias for callers that imported the old constant.
MAXIMA = DIMENSION_MAXIMA


def has_quality_page_gate(gate_report: dict[str, Any]) -> bool:
    quality_gates = gate_report.get("quality_gates", [])
    return any(
        isinstance(item, dict)
        and item.get("id") == "Q-G01"
        and item.get("status") == "PASS"
        for item in quality_gates
    )


def validate_high_risk(assessment: dict[str, Any], errors: list[str]) -> list[Any]:
    high_risk = assessment.get("high_risk_open", [])
    if not isinstance(high_risk, list):
        errors.append("high_risk_open must be a list")
        return ["invalid high_risk_open field"]
    return high_risk


def valid_evidence(item: dict[str, Any]) -> bool:
    evidence = item.get("evidence", [])
    return (
        isinstance(evidence, list)
        and bool(evidence)
        and all(isinstance(value, str) and value.strip() for value in evidence)
    )


def score_atomic_rubric(assessment: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    high_risk = validate_high_risk(assessment, errors)
    criteria = assessment.get("criteria", [])
    if not isinstance(criteria, list):
        criteria = []
        errors.append("criteria must be a list")

    section_values = {section_id: 0.0 for section_id in SECTION_RUBRIC}
    dimension_values = {dimension_id: 0.0 for dimension_id in DIMENSION_MAXIMA}
    seen: set[str] = set()
    deductions: list[dict[str, Any]] = []

    for item in criteria:
        if not isinstance(item, dict):
            errors.append("criterion entries must be objects")
            continue
        criterion_id = str(item.get("id", ""))
        definition = CRITERIA_BY_ID.get(criterion_id)
        if definition is None:
            errors.append(f"unknown criterion: {criterion_id}")
            continue
        if criterion_id in seen:
            errors.append(f"duplicate criterion: {criterion_id}")
            continue
        seen.add(criterion_id)
        score = item.get("score")
        maximum = float(definition["maximum"])
        if not isinstance(score, (int, float)) or isinstance(score, bool):
            errors.append(f"{criterion_id}: score is missing")
            continue
        score = float(score)
        if not 0 <= score <= maximum:
            errors.append(f"{criterion_id}: score {score} outside 0..{maximum}")
            continue
        if not isclose(score * 4, round(score * 4), abs_tol=1e-9):
            errors.append(f"{criterion_id}: score must use 0.25-point increments")
            continue
        if not valid_evidence(item):
            errors.append(f"{criterion_id}: scoring evidence is required")
        finding = str(item.get("finding", "")).strip()
        action = str(item.get("action", "")).strip()
        if score < maximum and (not finding or not action):
            errors.append(
                f"{criterion_id}: deductions require both finding and action"
            )

        ratio = score / maximum
        section_values[definition["section"]] += score
        for dimension_id, allocated_maximum in definition["dimensions"].items():
            dimension_values[dimension_id] += allocated_maximum * ratio
        if score < maximum:
            deductions.append(
                {
                    "id": criterion_id,
                    "section": definition["section"],
                    "score": score,
                    "maximum": maximum,
                    "deduction": round(maximum - score, 2),
                    "evidence": item.get("evidence", []),
                    "finding": finding,
                    "action": action,
                }
            )

    for definition in CRITERIA:
        if definition["id"] not in seen:
            errors.append(f"missing criterion: {definition['id']}")

    if errors:
        return {
            "generated_at": now_iso(),
            "status": "INVALID_ASSESSMENT",
            "rubric_version": RUBRIC_VERSION,
            "scoring_mode": "section-atomic",
            "total": None,
            "errors": errors,
        }

    total = round(sum(section_values.values()), 2)
    dimension_total = round(sum(dimension_values.values()), 2)
    if not isclose(total, dimension_total, abs_tol=0.01):
        return {
            "generated_at": now_iso(),
            "status": "INVALID_ASSESSMENT",
            "rubric_version": RUBRIC_VERSION,
            "scoring_mode": "section-atomic",
            "total": None,
            "errors": [
                f"section/dimension aggregation mismatch: {total} vs {dimension_total}"
            ],
        }

    section_floor_failures = [
        section_id
        for section_id, score in section_values.items()
        if score < SECTION_RUBRIC[section_id]["readiness_floor"]
    ]
    dimension_floor_failures = [
        dimension_id
        for dimension_id, score in dimension_values.items()
        if score < readiness_floor(dimension_id)
    ]
    ready_95 = (
        total >= 95
        and not section_floor_failures
        and not dimension_floor_failures
        and not high_risk
    )
    return {
        "generated_at": now_iso(),
        "status": "READY_95" if ready_95 else "SCORED",
        "rubric_version": RUBRIC_VERSION,
        "scoring_mode": "section-atomic",
        "total": total,
        "sections": [
            {
                "id": section_id,
                "score": round(section_values[section_id], 2),
                "maximum": config["maximum"],
                "readiness_floor": config["readiness_floor"],
            }
            for section_id, config in SECTION_RUBRIC.items()
        ],
        "dimensions": [
            {
                "id": dimension_id,
                "score": round(dimension_values[dimension_id], 2),
                "maximum": maximum,
                "readiness_floor": readiness_floor(dimension_id),
            }
            for dimension_id, maximum in DIMENSION_MAXIMA.items()
        ],
        "section_floor_failures": section_floor_failures,
        "dimension_floor_failures": dimension_floor_failures,
        "criterion_deductions": deductions,
        "high_risk_open": high_risk,
        "quality_page_gate": "PASS",
    }


def score_legacy_dimensions(assessment: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    values: dict[str, float] = {}
    dimensions = assessment.get("dimensions", [])
    seen: set[str] = set()
    for item in dimensions if isinstance(dimensions, list) else []:
        dimension_id = str(item.get("id", ""))
        if dimension_id not in DIMENSION_MAXIMA:
            errors.append(f"unknown dimension: {dimension_id}")
            continue
        if dimension_id in seen:
            errors.append(f"duplicate dimension: {dimension_id}")
            continue
        seen.add(dimension_id)
        score = item.get("score")
        if not isinstance(score, (int, float)) or isinstance(score, bool):
            errors.append(f"{dimension_id}: score is missing")
            continue
        if not 0 <= score <= DIMENSION_MAXIMA[dimension_id]:
            errors.append(
                f"{dimension_id}: score {score} outside 0..{DIMENSION_MAXIMA[dimension_id]}"
            )
            continue
        if not valid_evidence(item):
            errors.append(f"{dimension_id}: scoring evidence is required")
        values[dimension_id] = float(score)
    for dimension_id in DIMENSION_MAXIMA:
        if dimension_id not in seen:
            errors.append(f"missing dimension: {dimension_id}")
    high_risk = validate_high_risk(assessment, errors)

    if errors:
        return {
            "generated_at": now_iso(),
            "status": "INVALID_ASSESSMENT",
            "scoring_mode": "legacy-dimensions",
            "total": None,
            "errors": errors,
        }

    total = round(sum(values.values()), 2)
    floor_failures = [
        dimension_id
        for dimension_id, score in values.items()
        if score < readiness_floor(dimension_id)
    ]
    ready_95 = total >= 95 and not floor_failures and not high_risk
    return {
        "generated_at": now_iso(),
        "status": "READY_95" if ready_95 else "SCORED",
        "rubric_version": "1.0-legacy",
        "scoring_mode": "legacy-dimensions",
        "section_profile_status": "NOT_AVAILABLE_LEGACY",
        "total": total,
        "dimensions": [
            {
                "id": dimension_id,
                "score": values[dimension_id],
                "maximum": maximum,
                "readiness_floor": readiness_floor(dimension_id),
            }
            for dimension_id, maximum in DIMENSION_MAXIMA.items()
        ],
        "dimension_floor_failures": floor_failures,
        "high_risk_open": high_risk,
        "quality_page_gate": "PASS",
    }


def evaluate_scores(
    gate_report: dict[str, Any], assessment: dict[str, Any]
) -> dict[str, Any]:
    if gate_report.get("status") != "GATE_PASS":
        return {
            "generated_at": now_iso(),
            "status": "INVALID_BLOCKED",
            "total": None,
            "reason": "blocking gates have not passed",
            "failed_gate_ids": gate_report.get("failed_gate_ids", []),
        }
    if not has_quality_page_gate(gate_report):
        return {
            "generated_at": now_iso(),
            "status": "INVALID_ASSESSMENT",
            "total": None,
            "errors": ["Q-G01 28--30 page quality contract has not passed"],
        }

    version = str(assessment.get("rubric_version", ""))
    if version.startswith("2") or "criteria" in assessment:
        return score_atomic_rubric(assessment)
    return score_legacy_dimensions(assessment)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate evidence-backed section scores for a gated CUMCM paper."
    )
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    project = args.project_dir.resolve()
    gate_path = project / "reports" / "release_gate_report.json"
    assessment_path = project / "quality_assessment.json"
    output_path = project / "reports" / "score_report.json"

    if not gate_path.is_file() or not assessment_path.is_file():
        print(
            "release gate report and quality_assessment.json are required",
            file=sys.stderr,
        )
        return 2
    report = evaluate_scores(load_json(gate_path), load_json(assessment_path))
    write_json(output_path, report)
    if report["status"] in {"INVALID_BLOCKED", "INVALID_ASSESSMENT"}:
        details = report.get("errors") or report.get("failed_gate_ids") or []
        print("Score invalid: " + "; ".join(str(value) for value in details))
        return 2
    print(
        f"score: {report['total']}/100; status={report['status']}; "
        f"mode={report['scoring_mode']}; report={output_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
