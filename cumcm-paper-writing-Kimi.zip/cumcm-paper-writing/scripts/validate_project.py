from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from common import (
    approval_ok,
    gate,
    load_json,
    now_iso,
    read_text_best_effort,
    resolve_inside,
    sha256_file,
    unique,
    write_json,
)
from naturalize_audit import build_protected_state, state_digest
from validate_figure_assets import validate_figure_manifest


PHASE_GATE_IDS = {
    "evidence": ["W-G01", "W-G02"],
    "manuscript": [
        "W-G01",
        "W-G02",
        "W-G03",
        "W-G04",
        "W-G05",
        "W-G06",
        "W-G07",
        "W-G08",
        "W-G10",
        "W-G11",
        "W-G12",
        "W-G13",
    ],
    "release": [
        "W-G01",
        "W-G02",
        "W-G03",
        "W-G04",
        "W-G05",
        "W-G06",
        "W-G07",
        "W-G08",
        "W-G09",
        "W-G10",
        "W-G11",
        "W-G12",
        "W-G13",
        "W-G14",
        "R-G01",
        "R-G02",
        "R-G03",
        "R-G04",
        "R-G05",
        "R-G06",
    ],
}


def required_text(obj: dict[str, Any], key: str) -> bool:
    return bool(str(obj.get(key, "")).strip())


def format_claim_value(claim: dict[str, Any]) -> str:
    result = claim.get("result", {})
    value = result.get("value")
    if value is None:
        return ""
    try:
        precision = int(result.get("precision", 3))
        return f"{Decimal(str(value)):.{precision}f}"
    except (InvalidOperation, TypeError, ValueError):
        return str(value)


def collect_tex(project: Path) -> tuple[list[Path], str]:
    paths: list[Path] = []
    main = project / "main.tex"
    if main.is_file():
        paths.append(main)
    sections = project / "sections"
    if sections.is_dir():
        paths.extend(sorted(sections.rglob("*.tex")))
    generated = project / "generated"
    if generated.is_dir():
        paths.extend(sorted(generated.rglob("*.tex")))
    texts = [read_text_best_effort(path) for path in paths]
    return paths, "\n".join(texts)


def strip_tex_comments(text: str) -> str:
    return "\n".join(
        re.split(r"(?<!\\)%", line, maxsplit=1)[0] for line in text.splitlines()
    )


def prose_character_count(text: str) -> int:
    without_math = re.sub(
        r"\\begin\{(?:equation|align|gather|multline)(?:\*)?\}.*?"
        r"\\end\{(?:equation|align|gather|multline)(?:\*)?\}|"
        r"\\\[.*?\\\]|\$\$.*?\$\$",
        " ",
        text,
        flags=re.DOTALL,
    )
    without_commands = re.sub(r"\\[A-Za-z@]+\*?(?:\[[^\]]*\])?", " ", without_math)
    without_commands = re.sub(r"[{}$&_^~\\]", " ", without_commands)
    return len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", without_commands))


def approval_category(
    approvals: dict[str, Any],
    key: str,
    category_id: str,
    hard_issues: list[str],
    metrics: dict[str, Any],
) -> dict[str, Any]:
    approved, detail = approval_ok(approvals, key)
    issues = list(hard_issues)
    if not approved:
        issues.append(detail)
    return {
        "id": category_id,
        "status": "PASS" if not issues else "FAIL",
        "hard_issues": hard_issues,
        "manual_approval": detail,
        "metrics": metrics,
        "issues": issues,
    }


def audit_manuscript_structure(
    project: Path,
    contract: dict[str, Any],
    registry: dict[str, Any],
    approvals: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    main = strip_tex_comments(read_text_best_effort(project / "main.tex"))
    sections_dir = project / "sections"
    question_dir = sections_dir / "question-parts"
    question_ids = [str(item) for item in contract.get("question_ids", [])]
    answer_claims = [
        claim
        for claim in registry.get("claims", [])
        if claim.get("approved") is True
        and claim.get("claim_type", "answer") == "answer"
    ]

    required_section_stems = [
        "abstract",
        "problem-analysis",
        "assumptions-symbols",
        "common-model",
        "questions",
        "validation",
        "evaluation",
        "conclusion",
        "references",
        "appendix",
    ]
    chapter_issues: list[str] = []
    section_sizes: dict[str, int] = {}
    for stem in required_section_stems:
        path = sections_dir / f"{stem}.tex"
        content = strip_tex_comments(read_text_best_effort(path))
        section_sizes[stem] = prose_character_count(content)
        if not path.is_file():
            chapter_issues.append(f"missing required chapter file: sections/{stem}.tex")
        elif not content.strip():
            chapter_issues.append(f"empty required chapter file: sections/{stem}.tex")

    main_order = [
        "sections/problem-analysis",
        "sections/assumptions-symbols",
        "sections/common-model",
        "sections/questions",
        "sections/validation",
        "sections/evaluation",
        "sections/conclusion",
        "sections/references",
    ]
    positions = [main.find(rf"\input{{{item}}}") for item in main_order]
    for item, position in zip(main_order, positions):
        if position < 0:
            chapter_issues.append(f"main.tex does not include {item}")
    present_positions = [position for position in positions if position >= 0]
    if present_positions != sorted(present_positions):
        chapter_issues.append("main chapters are not in the required logical order")

    question_files: dict[str, Path] = {}
    question_texts: dict[str, str] = {}
    for question_id in question_ids:
        filename = question_id.lower().replace("_", "-") + ".tex"
        path = question_dir / filename
        question_files[question_id] = path
        text = strip_tex_comments(read_text_best_effort(path))
        question_texts[question_id] = text
        if not path.is_file():
            chapter_issues.append(
                f"{question_id}: missing sections/question-parts/{filename}"
            )
        elif not re.search(r"\\section\{[^}]+\}", text):
            chapter_issues.append(f"{question_id}: question file has no section heading")

    model_issues: list[str] = []
    model_metrics: dict[str, Any] = {}
    for question_id, text in question_texts.items():
        expected_claims = [
            str(claim.get("claim_id"))
            for claim in answer_claims
            if str(claim.get("question_id")) == question_id
        ]
        missing_answers = [
            claim_id
            for claim_id in expected_claims
            if rf"\ClaimAnswer{{{claim_id}}}" not in text
        ]
        for claim_id in missing_answers:
            model_issues.append(
                f"{question_id}: no direct answer macro for {claim_id} in its question file"
            )
        subsection_count = len(re.findall(r"\\subsection\{", text))
        has_formula = bool(
            re.search(
                r"\\begin\{(?:equation|align|gather|multline)(?:\*)?\}|\\\[",
                text,
            )
        )
        reuses_formula = bool(re.search(r"\\eqref\{eq:[^}]+\}", text))
        cue_checks = {
            "choice": bool(re.search(r"模型|采用|选择|方法", text)),
            "solver": bool(re.search(r"求解|步骤|算法|回归|拟合|计算", text)),
            "result": bool(re.search(r"结果|回答|得到", text)),
            "validation": bool(
                re.search(r"检验|残差|敏感|误差|不确定|复核|验证|扰动", text)
            ),
        }
        if subsection_count < 2:
            model_issues.append(
                f"{question_id}: fewer than two subsections; model chain is not visible"
            )
        for cue, present in cue_checks.items():
            if not present:
                model_issues.append(f"{question_id}: missing {cue} stage in model narrative")
        model_metrics[question_id] = {
            "subsections": subsection_count,
            "has_display_formula": has_formula,
            "reuses_referenced_formula": reuses_formula,
            "stage_cues": cue_checks,
            "answer_claims": expected_claims,
        }

    manuscript_paths = sorted(sections_dir.rglob("*.tex"))
    manuscript_text = "\n".join(
        strip_tex_comments(read_text_best_effort(path)) for path in manuscript_paths
    )
    heading_pattern = re.compile(r"\\(?:section|subsection|subsubsection)\{[^}]+\}")
    paragraph_issues: list[str] = []
    transition_metrics: list[dict[str, Any]] = []
    for path in manuscript_paths:
        if path.name in {"abstract.tex", "references.tex", "appendix.tex"}:
            continue
        text = strip_tex_comments(read_text_best_effort(path))
        headings = list(heading_pattern.finditer(text))
        for index, heading in enumerate(headings):
            end = headings[index + 1].start() if index + 1 < len(headings) else len(text)
            body = text[heading.end() : end]
            first_display = re.search(
                r"\\begin\{(?:equation|align|gather|multline|figure|table)(?:\*)?\}|"
                r"\\\[",
                body,
            )
            lead = body[: first_display.start()] if first_display else body
            lead_count = prose_character_count(lead[:500])
            relative = path.relative_to(project).as_posix()
            heading_text = heading.group(0)
            transition_metrics.append(
                {
                    "source": relative,
                    "heading": heading_text,
                    "lead_prose_characters": lead_count,
                }
            )
            current_level_match = re.match(
                r"\\(section|subsection|subsubsection)\{", heading_text
            )
            next_level_match = (
                re.match(
                    r"\\(section|subsection|subsubsection)\{",
                    headings[index + 1].group(0),
                )
                if index + 1 < len(headings)
                else None
            )
            level_rank = {"section": 1, "subsection": 2, "subsubsection": 3}
            immediately_has_child_heading = bool(
                current_level_match
                and next_level_match
                and level_rank[next_level_match.group(1)]
                > level_rank[current_level_match.group(1)]
                and prose_character_count(body) == 0
            )
            if lead_count < 12 and not immediately_has_child_heading:
                paragraph_issues.append(
                    f"{relative}: heading {heading_text} starts without an orienting sentence"
                )

    all_paths, all_tex = collect_tex(project)
    clean_tex = strip_tex_comments(all_tex)
    refs_raw = re.findall(r"\\(?:ref|eqref|autoref|cref|Cref)\{([^}]+)\}", clean_tex)
    refs = {
        item.strip()
        for group in refs_raw
        for item in group.split(",")
        if item.strip()
    }
    formula_issues: list[str] = []
    formula_metrics: list[dict[str, Any]] = []
    display_pattern = re.compile(
        r"\\begin\{(?P<env>equation|align|gather|multline)(?:\*)?\}"
        r"(?P<body>.*?)"
        r"\\end\{(?P=env)(?:\*)?\}|"
        r"\\\[(?P<bracket>.*?)\\\]",
        flags=re.DOTALL,
    )
    formula_context_cues = re.compile(
        r"其中|式|表示|定义|这里|由此|可得|令|设|故|因此|分别|即|说明|约束|目标"
    )
    for path in all_paths:
        if "generated" in path.parts and path.name.endswith("table.tex"):
            continue
        text = strip_tex_comments(read_text_best_effort(path))
        relative = path.relative_to(project).as_posix()
        for match in display_pattern.finditer(text):
            block = match.group(0)
            labels = re.findall(r"\\label\{([^}]+)\}", block)
            numbered = match.group("env") is not None and not re.match(
                r"\\begin\{(?:equation|align|gather|multline)\*\}", block
            )
            if numbered and not labels:
                formula_issues.append(
                    f"{relative}: numbered {match.group('env')} environment has no label"
                )
            context = text[max(0, match.start() - 220) : match.end() + 220]
            before = text[max(0, match.start() - 220) : match.start()]
            after = text[match.end() : match.end() + 220]
            before_count = prose_character_count(before)
            after_count = prose_character_count(after)
            explained = (
                before_count + after_count >= 24
                and before_count >= 4
                and after_count >= 4
                and bool(formula_context_cues.search(context))
            )
            formula_metrics.append(
                {
                    "source": relative,
                    "labels": labels,
                    "numbered": numbered,
                    "has_explanatory_context": explained,
                }
            )

    figure_issues: list[str] = []
    figure_metrics: list[dict[str, Any]] = []
    float_pattern = re.compile(
        r"\\begin\{(?P<env>figure|table)(?:\*)?\}(?P<body>.*?)"
        r"\\end\{(?P=env)(?:\*)?\}",
        flags=re.DOTALL,
    )
    for path in all_paths:
        text = strip_tex_comments(read_text_best_effort(path))
        relative = path.relative_to(project).as_posix()
        for match in float_pattern.finditer(text):
            body = match.group("body")
            labels = re.findall(r"\\label\{([^}]+)\}", body)
            has_caption = bool(re.search(r"\\caption(?:\[[^\]]+\])?\{", body))
            if not labels:
                figure_issues.append(f"{relative}: {match.group('env')} has no label")
                continue
            for label in labels:
                ref_pattern = re.compile(
                    rf"\\(?:ref|autoref|cref|Cref)\{{[^}}]*\b{re.escape(label)}\b[^}}]*\}}"
                )
                references = list(ref_pattern.finditer(manuscript_text))
                explained = any(
                    prose_character_count(
                        manuscript_text[ref.end() : ref.end() + 180]
                    )
                    >= 18
                    for ref in references
                )
                if not has_caption:
                    figure_issues.append(f"{label}: figure/table has no caption")
                figure_metrics.append(
                    {
                        "source": relative,
                        "label": label,
                        "references": len(references),
                        "has_caption": has_caption,
                        "has_explanation_after_reference": explained,
                    }
                )

    citation_issues: list[str] = []
    label_counts = Counter(re.findall(r"\\label\{([^}]+)\}", clean_tex))
    for label, count in sorted(label_counts.items()):
        if count > 1:
            citation_issues.append(f"duplicate label: {label}")
    for ref in sorted(refs):
        if ref not in label_counts:
            citation_issues.append(f"missing cross-reference target: {ref}")
    for label in sorted(label_counts):
        if label.startswith(("eq:", "fig:", "tab:")) and label not in refs:
            citation_issues.append(f"unreferenced labeled artifact: {label}")

    cite_raw = re.findall(r"\\cite\w*\{([^}]+)\}", clean_tex)
    cites = {
        item.strip()
        for group in cite_raw
        for item in group.split(",")
        if item.strip()
    }
    bibitems = set(
        re.findall(r"\\bibitem(?:\[[^\]]+\])?\{([^}]+)\}", clean_tex)
    )
    bib_path = project / "references.bib"
    if bib_path.is_file():
        bibitems.update(
            re.findall(
                r"@\w+\s*\{\s*([^,\s]+)",
                read_text_best_effort(bib_path),
                flags=re.IGNORECASE,
            )
        )
    for citation in sorted(cites - bibitems):
        citation_issues.append(f"missing bibliography target: {citation}")

    conclusion = strip_tex_comments(
        read_text_best_effort(sections_dir / "conclusion.tex")
    )
    expected_conclusion_claims: list[str] = []
    for question_id in question_ids:
        expected_conclusion_claims.extend(
            str(claim.get("claim_id"))
            for claim in answer_claims
            if str(claim.get("question_id")) == question_id
        )
    actual_conclusion_claims = re.findall(r"\\ClaimAnswer\{([^}]+)\}", conclusion)
    conclusion_issues: list[str] = []
    if actual_conclusion_claims != expected_conclusion_claims:
        conclusion_issues.append(
            "conclusion answer order/content differs from question contract: "
            f"expected={expected_conclusion_claims}, actual={actual_conclusion_claims}"
        )
    if re.search(r"\\begin\{(?:equation|align|figure|table)", conclusion):
        conclusion_issues.append(
            "conclusion contains new formula/figure/table instead of summarizing answers"
        )

    categories = [
        approval_category(
            approvals,
            "paragraph_cohesion",
            "paragraph_cohesion",
            paragraph_issues,
            {
                "heading_blocks_checked": len(transition_metrics),
                "blocks": transition_metrics,
            },
        ),
        approval_category(
            approvals,
            "model_structure",
            "model_structure",
            model_issues,
            model_metrics,
        ),
        approval_category(
            approvals,
            "formula_explanation",
            "formula_explanation",
            formula_issues,
            {
                "display_formulas_checked": len(formula_metrics),
                "with_explanatory_context": sum(
                    item["has_explanatory_context"] for item in formula_metrics
                ),
                "formulas": formula_metrics,
            },
        ),
        approval_category(
            approvals,
            "figure_table_quality",
            "figure_table_quality",
            figure_issues,
            {
                "floats_checked": len(figure_metrics),
                "explained_after_reference": sum(
                    item["has_explanation_after_reference"] for item in figure_metrics
                ),
                "floats": figure_metrics,
            },
        ),
        approval_category(
            approvals,
            "citation_integrity",
            "citation_integrity",
            citation_issues,
            {
                "labels": len(label_counts),
                "cross_references": len(refs),
                "citation_keys": sorted(cites),
                "bibliography_targets": len(bibitems),
            },
        ),
        approval_category(
            approvals,
            "chapter_completeness",
            "chapter_completeness",
            chapter_issues,
            {
                "required_chapter_sizes": section_sizes,
                "question_files": {
                    key: value.relative_to(project).as_posix()
                    for key, value in question_files.items()
                },
            },
        ),
        approval_category(
            approvals,
            "conclusion_correspondence",
            "conclusion_correspondence",
            conclusion_issues,
            {
                "expected_answer_claims": expected_conclusion_claims,
                "actual_answer_claims": actual_conclusion_claims,
            },
        ),
    ]
    failed = [item["id"] for item in categories if item["status"] != "PASS"]
    report = {
        "schema_version": "1.0",
        "generated_at": now_iso(),
        "status": "PASS" if not failed else "BLOCKED",
        "failed_categories": failed,
        "categories": categories,
    }
    write_json(project / "reports" / "manuscript_structure_report.json", report)
    structure_gate = gate(
        "W-G13",
        "段落、模型、公式、图表、引用、章节与结论结构",
        not failed,
        (
            ["seven manuscript structure categories verified"]
            if not failed
            else [
                f"{item['id']}: {issue}"
                for item in categories
                if item["status"] != "PASS"
                for issue in item["issues"][:5]
            ]
        ),
    )
    return structure_gate, report


def validate_evidence(
    project: Path, contract: dict[str, Any], registry: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any], dict[str, dict[str, Any]]]:
    evidence_items = registry.get("evidence", [])
    claims = registry.get("claims", [])
    evidence_by_id: dict[str, dict[str, Any]] = {}
    source_errors: list[str] = []

    for item in evidence_items if isinstance(evidence_items, list) else []:
        evidence_id = str(item.get("evidence_id", "")).strip()
        if not evidence_id:
            source_errors.append("evidence item without evidence_id")
            continue
        if evidence_id in evidence_by_id:
            source_errors.append(f"duplicate evidence_id: {evidence_id}")
            continue
        evidence_by_id[evidence_id] = item
        relative = str(item.get("path", "")).strip()
        if not relative:
            source_errors.append(f"{evidence_id}: missing path")
            continue
        try:
            source_path = resolve_inside(project, relative)
        except ValueError as exc:
            source_errors.append(f"{evidence_id}: {exc}")
            continue
        if not source_path.is_file():
            source_errors.append(f"{evidence_id}: file not found: {relative}")
            continue
        expected_hash = str(item.get("sha256", "")).lower().strip()
        if item.get("approved") is True and not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            source_errors.append(f"{evidence_id}: approved evidence needs SHA-256")
        elif expected_hash and sha256_file(source_path) != expected_hash:
            source_errors.append(f"{evidence_id}: SHA-256 mismatch")
        if item.get("approved") is not True:
            source_errors.append(f"{evidence_id}: evidence is not approved")
        if not required_text(item, "kind") or not required_text(item, "locator"):
            source_errors.append(f"{evidence_id}: kind and locator are required")

    question_ids = contract.get("question_ids", [])
    closure_errors: list[str] = []
    approved_claims: list[dict[str, Any]] = []
    claim_ids: set[str] = set()
    for claim in claims if isinstance(claims, list) else []:
        claim_id = str(claim.get("claim_id", "")).strip()
        question_id = str(claim.get("question_id", "")).strip()
        if not claim_id:
            closure_errors.append("claim without claim_id")
            continue
        if claim_id in claim_ids:
            closure_errors.append(f"duplicate claim_id: {claim_id}")
            continue
        claim_ids.add(claim_id)
        if question_id not in question_ids:
            closure_errors.append(f"{claim_id}: unknown question_id {question_id}")
        if claim.get("approved") is not True:
            closure_errors.append(f"{claim_id}: claim is not approved")
            continue
        approved_claims.append(claim)

        for key in (
            "task",
            "model_name",
            "model_choice_reason",
            "answer_sentence",
            "scope",
        ):
            if not required_text(claim, key):
                closure_errors.append(f"{claim_id}: missing {key}")
        for key in ("variables", "assumptions", "core_relations"):
            value = claim.get(key)
            if not isinstance(value, list) or not value:
                closure_errors.append(f"{claim_id}: missing {key}")
        solver = claim.get("solver", {})
        for key in ("method", "parameters", "termination"):
            if not required_text(solver, key):
                closure_errors.append(f"{claim_id}: solver.{key} is required")
        result = claim.get("result", {})
        if result.get("value") is None:
            closure_errors.append(f"{claim_id}: result.value is missing")
        if not required_text(result, "unit"):
            closure_errors.append(
                f"{claim_id}: result.unit is required; use '1' for dimensionless"
            )
        try:
            if int(result.get("precision")) < 0:
                raise ValueError
        except (TypeError, ValueError):
            closure_errors.append(f"{claim_id}: result.precision must be nonnegative")

        source_ids = result.get("source_ids", [])
        if not isinstance(source_ids, list) or not source_ids:
            closure_errors.append(f"{claim_id}: result.source_ids is empty")
        for source_id in source_ids if isinstance(source_ids, list) else []:
            item = evidence_by_id.get(source_id)
            if item is None:
                closure_errors.append(f"{claim_id}: unknown source {source_id}")
            elif item.get("approved") is not True:
                closure_errors.append(f"{claim_id}: source {source_id} is unapproved")

        validation_ids = claim.get("validation_ids", [])
        if not isinstance(validation_ids, list) or not validation_ids:
            closure_errors.append(f"{claim_id}: validation_ids is empty")
        for validation_id in validation_ids if isinstance(validation_ids, list) else []:
            item = evidence_by_id.get(validation_id)
            if item is None:
                closure_errors.append(f"{claim_id}: unknown validation {validation_id}")
            elif item.get("kind") != "validation":
                closure_errors.append(
                    f"{claim_id}: {validation_id} must have kind='validation'"
                )
        if not claim.get("figure_table_ids"):
            closure_errors.append(f"{claim_id}: figure_table_ids is empty")

        allowed = claim.get("allowed_sections", [])
        required_sections = [question_id]
        if claim.get("claim_type", "answer") == "answer":
            required_sections.extend(["abstract", "conclusion"])
        for required_section in required_sections:
            if required_section not in allowed:
                closure_errors.append(
                    f"{claim_id}: allowed_sections misses {required_section}"
                )

        derivation = result.get("derivation")
        if derivation is not None:
            if not isinstance(derivation, dict):
                closure_errors.append(f"{claim_id}: derivation must be an object")
            else:
                for key in (
                    "input_claim_ids",
                    "formula",
                    "unit_conversion",
                    "recalculated_value",
                ):
                    if not derivation.get(key):
                        closure_errors.append(f"{claim_id}: derivation.{key} is required")

    for question_id in question_ids:
        if not any(
            claim.get("question_id") == question_id
            and claim.get("claim_type", "answer") == "answer"
            for claim in approved_claims
        ):
            closure_errors.append(f"{question_id}: no approved answer claim")

    g01 = gate(
        "W-G01",
        "输入证据",
        not source_errors and bool(evidence_by_id),
        source_errors or [f"{len(evidence_by_id)} approved evidence records verified"],
    )
    g02 = gate(
        "W-G02",
        "题目覆盖与逐问闭环",
        not closure_errors and bool(approved_claims),
        closure_errors or [f"{len(approved_claims)} complete approved claims verified"],
    )
    return g01, g02, evidence_by_id


def validate_manuscript(
    project: Path,
    contract: dict[str, Any],
    registry: dict[str, Any],
    approvals: dict[str, Any],
) -> list[dict[str, Any]]:
    paths, tex = collect_tex(project)
    tex_clean = strip_tex_comments(tex)
    authored_tex_clean = "\n".join(
        strip_tex_comments(read_text_best_effort(path))
        for path in paths
        if "generated" not in path.parts
    )
    claims = [
        claim
        for claim in registry.get("claims", [])
        if claim.get("approved") is True
    ]
    answer_claims = [
        claim for claim in claims if claim.get("claim_type", "answer") == "answer"
    ]
    question_ids = contract.get("question_ids", [])
    abstract = read_text_best_effort(project / "sections" / "abstract.tex")
    conclusion = read_text_best_effort(project / "sections" / "conclusion.tex")
    generated_claims = read_text_best_effort(project / "generated" / "claims.tex")
    section_tex = "\n".join(
        read_text_best_effort(path)
        for path in sorted((project / "sections").rglob("*.tex"))
    )
    effective_tex = strip_tex_comments(section_tex + "\n" + generated_claims)
    question_text = "\n".join(
        read_text_best_effort(path)
        for path in sorted((project / "sections" / "question-parts").glob("*.tex"))
    )

    consistency_errors: list[str] = []
    for question_id in question_ids:
        ids = [
            str(claim.get("claim_id"))
            for claim in answer_claims
            if claim.get("question_id") == question_id
        ]
        if ids and not any(
            re.search(rf"\\Claim(?:Value|Answer)\{{{re.escape(claim_id)}\}}", abstract)
            for claim_id in ids
        ):
            consistency_errors.append(f"{question_id}: no claim macro in abstract")
        if ids and not any(
            re.search(
                rf"\\Claim(?:Value|Answer|Unit)\{{{re.escape(claim_id)}\}}",
                question_text,
            )
            for claim_id in ids
        ):
            consistency_errors.append(f"{question_id}: no claim macro in question body")
        if ids and not any(
            re.search(rf"\\ClaimAnswer\{{{re.escape(claim_id)}\}}", conclusion)
            for claim_id in ids
        ):
            consistency_errors.append(f"{question_id}: no answer macro in conclusion")

    for claim in claims:
        literal = format_claim_value(claim)
        digits = re.sub(r"\D", "", literal)
        if len(digits) >= 2 and literal and literal in authored_tex_clean:
            consistency_errors.append(
                f"{claim.get('claim_id')}: protected literal '{literal}' appears in TeX; use a claim macro"
            )
    unresolved = re.findall(
        r"(?:\[UNAPPROVED:[^\]]+\]|\[MISSING[^\]]*\]|<<[^>]+>>|\bTODO\b)",
        effective_tex,
    )
    if unresolved:
        consistency_errors.append(
            "unresolved manuscript markers: " + ", ".join(unique(unresolved)[:10])
        )
    g03 = gate(
        "W-G03",
        "数字一致与统一来源",
        not consistency_errors,
        consistency_errors or ["claim macro coverage and protected literals verified"],
    )

    ok, detail = approval_ok(approvals, "no_fabrication")
    g04 = gate("W-G04", "禁止补造", ok, [detail])

    abstract_errors: list[str] = []
    if not abstract.strip():
        abstract_errors.append("sections/abstract.tex is empty or missing")
    if "关键词" not in abstract:
        abstract_errors.append("abstract does not contain keywords")
    for question_id in question_ids:
        if question_id not in abstract and f"问题{question_id[1:]}" not in abstract:
            claim_ids = [
                str(claim.get("claim_id"))
                for claim in answer_claims
                if claim.get("question_id") == question_id
            ]
            if not any(claim_id in abstract for claim_id in claim_ids):
                abstract_errors.append(f"abstract does not visibly cover {question_id}")
    abstract_ok, abstract_detail = approval_ok(approvals, "abstract_semantics")
    if not abstract_ok:
        abstract_errors.append(abstract_detail)
    g05 = gate(
        "W-G05",
        "摘要完整",
        not abstract_errors,
        abstract_errors or ["all questions, methods, answers and validation approved"],
    )

    symbols_ok, symbols_detail = approval_ok(approvals, "symbols_units")
    unit_errors = [
        f"{claim.get('claim_id')}: missing unit"
        for claim in claims
        if not required_text(claim.get("result", {}), "unit")
    ]
    g06 = gate(
        "W-G06",
        "符号与单位",
        symbols_ok and not unit_errors,
        unit_errors + [symbols_detail],
    )

    labels = re.findall(r"\\label\{([^}]+)\}", tex_clean)
    label_counts = Counter(labels)
    duplicate_labels = [label for label, count in label_counts.items() if count > 1]
    refs_raw = re.findall(
        r"\\(?:ref|eqref|autoref|cref|Cref)\{([^}]+)\}", tex_clean
    )
    refs = {
        item.strip()
        for group in refs_raw
        for item in group.split(",")
        if item.strip()
    }
    missing_refs = sorted(ref for ref in refs if ref not in label_counts)
    cite_raw = re.findall(r"\\cite\w*\{([^}]+)\}", tex_clean)
    cites = {
        item.strip()
        for group in cite_raw
        for item in group.split(",")
        if item.strip()
    }
    bibitems = set(
        re.findall(r"\\bibitem(?:\[[^\]]+\])?\{([^}]+)\}", tex_clean)
    )
    bib_path = project / "references.bib"
    if bib_path.is_file():
        bibitems.update(
            re.findall(
                r"@\w+\s*\{\s*([^,\s]+)",
                read_text_best_effort(bib_path),
                flags=re.IGNORECASE,
            )
        )
    missing_cites = sorted(cite for cite in cites if cite not in bibitems)
    artifact_ids = {
        artifact
        for claim in claims
        for artifact in claim.get("figure_table_ids", [])
    }
    missing_artifacts = sorted(item for item in artifact_ids if item not in label_counts)
    reference_errors = (
        [f"duplicate label: {item}" for item in duplicate_labels]
        + [f"missing label target: {item}" for item in missing_refs]
        + [f"missing bibliography target: {item}" for item in missing_cites]
        + [f"claim artifact has no LaTeX label: {item}" for item in missing_artifacts]
    )
    g07 = gate(
        "W-G07",
        "公式与引用",
        not reference_errors,
        reference_errors
        or [f"{len(labels)} labels and {len(cites)} citation keys resolved"],
    )

    figure_labels = {
        label for label in labels if label.startswith(("fig:", "tab:"))
    }
    image_labels = {label for label in figure_labels if label.startswith("fig:")}
    unreferenced = sorted(label for label in figure_labels if label not in refs)
    caption_count = len(re.findall(r"\\caption(?:\[[^\]]+\])?\{", tex_clean))
    visual_ok, visual_detail = approval_ok(approvals, "figure_readability")
    figure_errors = [f"unreferenced figure/table: {item}" for item in unreferenced]
    layout_contract = contract.get("layout_contract", {})
    try:
        minimum_figure_width = float(
            layout_contract.get("figure_width_min", 0.78)
        )
    except (TypeError, ValueError):
        minimum_figure_width = 0.78
    for path in paths:
        relative = path.relative_to(project).as_posix()
        for line_number, line in enumerate(
            read_text_best_effort(path).splitlines(), start=1
        ):
            source_line = re.split(r"(?<!\\)%", line, maxsplit=1)[0]
            forced_float = re.search(
                r"\\begin\{(figure|table)(?:\*)?\}\s*\[([^\]]*\bH\b[^\]]*)\]",
                source_line,
            )
            if forced_float:
                figure_errors.append(
                    f"{relative}:{line_number}: forced [{forced_float.group(2)}] "
                    "float placement is forbidden; use [!htbp] or [p]"
                )
            image_options = re.search(
                r"\\includegraphics\[([^\]]*)\]", source_line
            )
            if image_options:
                width_match = re.search(
                    r"width\s*=\s*(0?\.\d+)\\textwidth",
                    image_options.group(1),
                )
                if width_match and float(width_match.group(1)) < minimum_figure_width:
                    figure_errors.append(
                        f"{relative}:{line_number}: figure width "
                        f"{width_match.group(1)}\\textwidth is below the layout "
                        f"minimum {minimum_figure_width:.2f}\\textwidth; split the "
                        "figure or record a visual exception instead of shrinking it"
                    )
            if "sections" in path.parts and re.search(
                r"\\(?:clearpage|newpage|pagebreak)\b", source_line
            ):
                figure_errors.append(
                    f"{relative}:{line_number}: forced page break inside a section "
                    "is forbidden because it can create large whitespace"
                )
    if figure_labels and caption_count < len(figure_labels):
        figure_errors.append("one or more figure/table labels lack a caption")
    figure_asset_report = validate_figure_manifest(project, registry, image_labels)
    write_json(project / "reports" / "figure_asset_report.json", figure_asset_report)
    figure_errors.extend(figure_asset_report.get("errors", []))
    if not visual_ok:
        figure_errors.append(visual_detail)
    g08 = gate(
        "W-G08",
        "图表可读",
        not figure_errors,
        figure_errors
        or [
            f"{len(figure_labels)} figure/table labels and "
            f"{figure_asset_report.get('metrics', {}).get('approved_assets', 0)} "
            "figure-engine handoffs approved"
        ],
    )

    anonymity_ok, anonymity_detail = approval_ok(approvals, "anonymity")
    anonymity_errors: list[str] = []
    terms = [
        str(term).strip()
        for term in contract.get("anonymity_terms", [])
        if str(term).strip()
    ]
    terms.extend(["学校名称", "队伍名称", "参赛队号", "指导教师姓名"])
    for term in unique(terms):
        if term and term in tex_clean:
            anonymity_errors.append(f"sensitive term in manuscript: {term}")
    if not anonymity_ok:
        anonymity_errors.append(anonymity_detail)
    g10 = gate(
        "W-G10",
        "匿名与规则",
        not anonymity_errors,
        anonymity_errors or ["anonymity scan and manual review passed"],
    )

    overclaim_ok, overclaim_detail = approval_ok(approvals, "overclaim_causality")
    overclaim_errors: list[str] = []
    positive_optimality_text = re.sub(
        r"(?:不声称|并非|不是|不能保证|无法保证|未证明|没有证明)全局最优",
        "",
        tex_clean,
    )
    if "全局最优" in positive_optimality_text:
        global_claims = [
            claim
            for claim in claims
            if claim.get("solver", {}).get("optimality_certificate") == "global"
        ]
        if not global_claims:
            overclaim_errors.append(
                "manuscript says '全局最优' without a global optimality certificate"
            )
    if not overclaim_ok:
        overclaim_errors.append(overclaim_detail)
    g11 = gate(
        "W-G11",
        "结果措辞",
        not overclaim_errors,
        overclaim_errors or ["optimality and causality wording approved"],
    )

    citation_ok, citation_detail = approval_ok(approvals, "citation_authenticity")
    g12 = gate("W-G12", "引用真实性", citation_ok and not missing_cites, [citation_detail])

    g13, _ = audit_manuscript_structure(
        project, contract, registry, approvals
    )

    return [g03, g04, g05, g06, g07, g08, g10, g11, g12, g13]


def validate_release(
    project: Path,
    contract: dict[str, Any],
    approvals: dict[str, Any],
    manuscript_tex: str,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    inspection_path = project / "reports" / "pdf_inspection.json"
    support_path = project / "reports" / "support_build_report.json"
    inspection = load_json(inspection_path) if inspection_path.is_file() else {}
    support = load_json(support_path) if support_path.is_file() else {}

    layout_ok, layout_detail = approval_ok(approvals, "visual_layout")
    layout_errors: list[str] = []
    if inspection.get("compile_success") is not True:
        layout_errors.append("PDF compile/inspection report is missing or unsuccessful")
    if inspection.get("severe_log_issues"):
        layout_errors.extend(inspection.get("severe_log_issues", []))
    if not layout_ok:
        layout_errors.append(layout_detail)
    g09 = gate(
        "W-G09",
        "版式渲染",
        not layout_errors,
        layout_errors or ["compiled PDF and rendered pages approved"],
    )

    naturalization_errors: list[str] = []
    naturalization = contract.get("naturalization", {})
    naturalization_report: dict[str, Any] = {}
    if not isinstance(naturalization, dict):
        naturalization_errors.append(
            "paper_contract.json naturalization must be an object"
        )
        naturalization = {}
    if naturalization.get("enabled") is not True:
        naturalization_errors.append(
            "terminal naturalization is not enabled in paper_contract.json"
        )
    if naturalization.get("no_detector_promise") is not True:
        naturalization_errors.append(
            "naturalization.no_detector_promise must be true"
        )
    report_relative = str(
        naturalization.get(
            "verification_report", "reports/naturalization_report.json"
        )
    ).strip()
    guard_relative = str(
        naturalization.get(
            "protected_snapshot", "reports/naturalization_guard.json"
        )
    ).strip()
    try:
        report_path = resolve_inside(project, report_relative)
        guard_path = resolve_inside(project, guard_relative)
    except ValueError as exc:
        naturalization_errors.append(str(exc))
        report_path = project / "__invalid_naturalization_report__"
        guard_path = project / "__invalid_naturalization_guard__"
    if not report_path.is_file():
        naturalization_errors.append(
            f"naturalization verification report is missing: {report_relative}"
        )
    else:
        naturalization_report = load_json(report_path)
        if naturalization_report.get("status") != "PASS":
            naturalization_errors.append(
                "naturalization report status is not PASS"
            )
        if naturalization_report.get("mode") != "verify":
            naturalization_errors.append(
                "naturalization report must come from --verify, not snapshot/scan"
            )
        if naturalization_report.get("no_detector_promise") is not True:
            naturalization_errors.append(
                "naturalization report contains no detector disclaimer"
            )
        if naturalization_report.get("detector_percentage") is not None:
            naturalization_errors.append(
                "naturalization report must not contain a fabricated detector percentage"
            )
        protected = naturalization_report.get("protected_integrity", {})
        if protected.get("status") != "PASS":
            naturalization_errors.append(
                "protected manuscript content changed during naturalization"
            )
        style_scan = naturalization_report.get("style_scan", {})
        if style_scan.get("blocking_count", 0) != 0:
            naturalization_errors.append(
                "forbidden chat residue or detector claim remains in manuscript"
            )
        configured_tier = str(naturalization.get("tier", "medium"))
        if naturalization_report.get("tier") != configured_tier:
            naturalization_errors.append(
                "naturalization report tier differs from paper contract"
            )
        try:
            max_rounds = int(naturalization.get("max_rounds", 3))
            report_round = int(naturalization_report.get("round", -1))
            if report_round < 1 or report_round > max_rounds:
                naturalization_errors.append(
                    f"naturalization round={report_round} exceeds allowed 1..{max_rounds}"
                )
        except (TypeError, ValueError):
            naturalization_errors.append(
                "naturalization round/max_rounds is not a valid integer"
            )
        current_digest = state_digest(build_protected_state(project))
        verified_digest = str(protected.get("verified_state_digest", ""))
        if verified_digest != current_digest:
            naturalization_errors.append(
                "manuscript changed after the naturalization verification report"
            )
        if not guard_path.is_file():
            naturalization_errors.append(
                f"naturalization protected snapshot is missing: {guard_relative}"
            )
        else:
            guard_digest = str(protected.get("guard_digest", ""))
            if guard_digest != sha256_file(guard_path):
                naturalization_errors.append(
                    "naturalization guard changed after verification"
                )
    naturalization_ok, naturalization_detail = approval_ok(
        approvals, "naturalization_semantics"
    )
    if not naturalization_ok:
        naturalization_errors.append(naturalization_detail)
    g14 = gate(
        "W-G14",
        "终稿自然化与受保护内容完整性",
        not naturalization_errors,
        naturalization_errors
        or [
            "protected claims, numbers, units, formulas, labels, references "
            "and evidence hashes are unchanged",
            naturalization_detail,
        ],
    )

    body_pages = inspection.get("body_pages")
    hard_max = contract.get("body_page_contract", {}).get("hard_max", 30)
    body_ok = isinstance(body_pages, int) and 1 <= body_pages <= hard_max
    g_r01 = gate(
        "R-G01",
        "正文页数",
        body_ok,
        [f"body_pages={body_pages!r}, hard_max={hard_max}"],
    )

    paper_size = inspection.get("file_size_bytes")
    paper_size_ok = isinstance(paper_size, int) and paper_size <= 20 * 1024 * 1024
    g_r02 = gate(
        "R-G02",
        "电子论文大小",
        paper_size_ok,
        [f"paper_size_bytes={paper_size!r}, limit={20 * 1024 * 1024}"],
    )

    support_size = support.get("archive_size_bytes")
    support_ok = support.get("status") == "PASS"
    support_size_ok = (
        isinstance(support_size, int) and support_size <= 20 * 1024 * 1024
    )
    g_r03 = gate(
        "R-G03",
        "支撑材料大小",
        support_ok and support_size_ok,
        [
            f"support_status={support.get('status')!r}",
            f"archive_size_bytes={support_size!r}",
        ],
    )

    first_page = str(inspection.get("first_page_text", ""))
    first_page_normalized = re.sub(r"\s+", "", first_page)
    no_toc = r"\tableofcontents" not in manuscript_tex
    has_abstract_marker = (
        "摘要" in first_page or "CUMCM-ABSTRACT-PAGE" in first_page_normalized
    )
    first_page_ok = has_abstract_marker and not any(
        term in first_page for term in ("承诺书", "编号专用页")
    )
    g_r04 = gate(
        "R-G04",
        "电子版首屏与无目录",
        first_page_ok and no_toc,
        [
            f"first_page_has_abstract={has_abstract_marker}",
            f"no_table_of_contents={no_toc}",
        ],
    )

    code_ok, code_detail = approval_ok(approvals, "code_reproducibility")
    g_r05 = gate(
        "R-G05",
        "支撑材料一致与可运行",
        support_ok and code_ok,
        [f"support_status={support.get('status')!r}", code_detail],
    )

    ai = contract.get("ai_use", {})
    ai_used = ai.get("used") is True
    ai_errors: list[str] = []
    if ai_used:
        detail_file = str(ai.get("detail_file", "")).strip()
        if not detail_file:
            ai_errors.append("ai_use.detail_file is missing")
        else:
            try:
                if not resolve_inside(project, detail_file).is_file():
                    ai_errors.append(f"AI detail PDF not found: {detail_file}")
            except ValueError as exc:
                ai_errors.append(str(exc))
        reference_key = str(ai.get("reference_key", "")).strip()
        if not reference_key:
            ai_errors.append("ai_use.reference_key is missing")
        elif not re.search(
            rf"\\bibitem(?:\[[^\]]+\])?\{{{re.escape(reference_key)}\}}",
            manuscript_tex,
        ):
            ai_errors.append(f"AI reference key not found: {reference_key}")
        if "AI辅助" not in manuscript_tex and "人工智能辅助" not in manuscript_tex:
            ai_errors.append("no AI-assisted content marker found in manuscript")
    else:
        if "未使用人工智能" not in manuscript_tex:
            ai_errors.append("no explicit non-use-of-AI statement after references")
    g_r06 = gate(
        "R-G06",
        "AI 使用规则",
        not ai_errors,
        ai_errors or [f"AI disclosure consistent; ai_used={ai_used}"],
    )

    short = contract.get("body_page_contract", {}).get("short_body_exception", {})
    target_ok = isinstance(body_pages, int) and 28 <= body_pages <= 30
    exception_ok = (
        isinstance(body_pages, int)
        and 24 <= body_pages < 28
        and short.get("approved") is True
        and bool(str(short.get("reviewer", "")).strip())
        and bool(str(short.get("rationale", "")).strip())
    )
    quality_page_gate = gate(
        "Q-G01",
        "28--30 页质量合同",
        target_ok or exception_ok,
        [
            f"body_pages={body_pages!r}",
            f"target_ok={target_ok}",
            f"approved_short_exception={exception_ok}",
        ],
    )
    return [
        g09,
        g14,
        g_r01,
        g_r02,
        g_r03,
        g_r04,
        g_r05,
        g_r06,
    ], quality_page_gate


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a CUMCM paper project.")
    parser.add_argument("project_dir", type=Path)
    parser.add_argument(
        "--phase", choices=("evidence", "manuscript", "release"), default="release"
    )
    args = parser.parse_args()
    project = args.project_dir.resolve()

    required = [
        "paper_contract.json",
        "claim_registry.json",
        "release_approvals.json",
    ]
    missing = [name for name in required if not (project / name).is_file()]
    if missing:
        print("Missing required files: " + ", ".join(missing), file=sys.stderr)
        return 2

    contract = load_json(project / "paper_contract.json")
    registry = load_json(project / "claim_registry.json")
    approvals = load_json(project / "release_approvals.json")
    g01, g02, _ = validate_evidence(project, contract, registry)
    if args.phase in ("manuscript", "release"):
        closure_ok, closure_detail = approval_ok(approvals, "question_closure")
        if not closure_ok:
            g02["status"] = "FAIL"
            g02["evidence"].append(closure_detail)
    all_gates = [g01, g02]

    _, tex = collect_tex(project)
    if args.phase in ("manuscript", "release"):
        all_gates.extend(
            validate_manuscript(project, contract, registry, approvals)
        )

    quality_gates: list[dict[str, Any]] = []
    if args.phase == "release":
        release_gates, quality_page_gate = validate_release(
            project, contract, approvals, tex
        )
        all_gates.extend(release_gates)
        quality_gates.append(quality_page_gate)

    selected = set(PHASE_GATE_IDS[args.phase])
    selected_gates = [item for item in all_gates if item["id"] in selected]
    selected_by_id = {item["id"]: item for item in selected_gates}
    missing_gate_results = sorted(selected - set(selected_by_id))
    for gate_id in missing_gate_results:
        selected_gates.append(
            gate(gate_id, "internal validation coverage", False, ["gate not evaluated"])
        )
    failed = [item["id"] for item in selected_gates if item["status"] != "PASS"]
    status = "BLOCKED" if failed else "GATE_PASS"
    report = {
        "schema_version": "1.0",
        "generated_at": now_iso(),
        "phase": args.phase,
        "status": status,
        "failed_gate_ids": failed,
        "gates": selected_gates,
        "quality_gates": quality_gates,
    }
    report_path = project / "reports" / f"{args.phase}_gate_report.json"
    write_json(report_path, report)
    if args.phase in ("manuscript", "release"):
        consistency_ids = {
            "W-G02",
            "W-G03",
            "W-G06",
            "W-G07",
            "W-G08",
            "W-G12",
            "W-G13",
            "W-G14",
        }
        consistency_gates = [
            item for item in selected_gates if item["id"] in consistency_ids
        ]
        consistency_failed = [
            item["id"] for item in consistency_gates if item["status"] != "PASS"
        ]
        write_json(
            project / "reports" / "writing_consistency_report.json",
            {
                "schema_version": "1.0",
                "generated_at": now_iso(),
                "status": "PASS" if not consistency_failed else "BLOCKED",
                "failed_gate_ids": consistency_failed,
                "checks": consistency_gates,
            },
        )
    if args.phase == "release":
        write_json(project / "reports" / "release_gate_report.json", report)
    print(f"{args.phase}: {status}; report={report_path}")
    if failed:
        print("Failed gates: " + ", ".join(failed))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
