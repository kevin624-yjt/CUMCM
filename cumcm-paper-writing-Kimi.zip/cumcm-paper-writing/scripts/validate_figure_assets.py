from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path
from typing import Any

from common import load_json, now_iso, resolve_inside, sha256_file, write_json


DATA_KINDS = {"data_chart", "statistical_chart", "result_chart"}
DIAGRAM_KINDS = {
    "model_diagram",
    "process_diagram",
    "conceptual_diagram",
    "framework_diagram",
}
ALLOWED_ENGINES = {"cumcm-figure-skill", "cumcm-visual-skill", "native"}
PAPER_IMAGE_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg"}


def _approval_complete(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("approved") is True
        and bool(str(value.get("reviewer", "")).strip())
        and bool(str(value.get("approved_at", "")).strip())
        and bool(str(value.get("scope", "")).strip())
    )


def _exception_complete(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("approved") is True
        and bool(str(value.get("reviewer", "")).strip())
        and bool(str(value.get("approved_at", "")).strip())
        and bool(str(value.get("reason", "")).strip())
    )


def _verify_file_record(
    project: Path,
    value: Any,
    field: str,
    errors: list[str],
) -> Path | None:
    if not isinstance(value, dict):
        errors.append(f"{field}: expected object with path and sha256")
        return None
    relative = str(value.get("path", "")).strip()
    expected_hash = str(value.get("sha256", "")).strip().lower()
    if not relative:
        errors.append(f"{field}: path is required")
        return None
    try:
        path = resolve_inside(project, relative)
    except ValueError as exc:
        errors.append(f"{field}: {exc}")
        return None
    if not path.is_file():
        errors.append(f"{field}: missing file {relative}")
        return None
    if not expected_hash:
        errors.append(f"{field}: sha256 is required for {relative}")
    else:
        actual_hash = sha256_file(path)
        if actual_hash.lower() != expected_hash:
            errors.append(f"{field}: sha256 mismatch for {relative}")
    return path


def _png_dimensions(path: Path) -> tuple[int, int] | None:
    try:
        data = path.read_bytes()[:24]
    except OSError:
        return None
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")


def _qa_passes(path: Path) -> bool:
    if path.suffix.lower() != ".json":
        return False
    try:
        report = load_json(path)
    except (OSError, ValueError):
        return False
    if str(report.get("status", "")).upper() in {"PASS", "GATE_PASS"}:
        return True
    summary = report.get("summary", {})
    if not isinstance(summary, dict):
        return False
    return (
        summary.get("healthy") is True
        or summary.get("failures") == 0
        or (
            summary.get("false_negatives") == 0
            and summary.get("uncovered_functions") == []
        )
    )


def collect_latex_figure_labels(project: Path) -> set[str]:
    labels: set[str] = set()
    paths: list[Path] = []
    main = project / "main.tex"
    if main.is_file():
        paths.append(main)
    sections = project / "sections"
    if sections.is_dir():
        paths.extend(sections.rglob("*.tex"))
    for path in paths:
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        labels.update(
            label
            for label in re.findall(r"\\label\{([^}]+)\}", text)
            if label.startswith("fig:")
        )
    return labels


def validate_figure_manifest(
    project: Path,
    registry: dict[str, Any],
    latex_figure_labels: set[str] | None = None,
) -> dict[str, Any]:
    labels = (
        latex_figure_labels
        if latex_figure_labels is not None
        else collect_latex_figure_labels(project)
    )
    manifest_path = project / "figure_manifest.json"
    errors: list[str] = []
    warnings: list[str] = []
    metrics: dict[str, Any] = {
        "latex_figure_labels": len(labels),
        "manifest_assets": 0,
        "approved_assets": 0,
        "engines": {},
    }

    if not manifest_path.is_file():
        if labels:
            errors.append(
                "figure_manifest.json is required when the manuscript contains figures"
            )
        else:
            warnings.append(
                "figure_manifest.json is absent; no LaTeX figures were found"
            )
        return {
            "schema_version": "1.0",
            "generated_at": now_iso(),
            "status": "BLOCKED" if errors else "PASS",
            "errors": errors,
            "warnings": warnings,
            "metrics": metrics,
            "assets": [],
        }

    try:
        manifest = load_json(manifest_path)
    except (OSError, ValueError) as exc:
        errors.append(f"figure_manifest.json cannot be read: {exc}")
        manifest = {}

    assets = manifest.get("assets", [])
    if not isinstance(assets, list):
        errors.append("figure_manifest.json assets must be a list")
        assets = []
    metrics["manifest_assets"] = len(assets)
    preset = manifest.get("paper_preset", {})
    try:
        minimum_long_side = int(preset.get("minimum_raster_long_side_px", 1600))
        minimum_short_side = int(preset.get("minimum_raster_short_side_px", 900))
    except (AttributeError, TypeError, ValueError):
        errors.append("paper_preset raster dimension limits must be integers")
        minimum_long_side, minimum_short_side = 1600, 900
    metrics["minimum_raster"] = {
        "long_side_px": minimum_long_side,
        "short_side_px": minimum_short_side,
    }

    claims = {
        str(item.get("claim_id")): item
        for item in registry.get("claims", [])
        if item.get("approved") is True and item.get("claim_id")
    }
    evidence = {
        str(item.get("evidence_id")): item
        for item in registry.get("evidence", [])
        if item.get("approved") is True and item.get("evidence_id")
    }
    seen: set[str] = set()
    approved_ids: set[str] = set()
    asset_reports: list[dict[str, Any]] = []

    for index, asset in enumerate(assets):
        prefix = f"assets[{index}]"
        item_errors: list[str] = []
        if not isinstance(asset, dict):
            errors.append(f"{prefix}: expected object")
            continue
        figure_id = str(asset.get("figure_id", "")).strip()
        question_id = str(asset.get("question_id", "")).strip()
        kind = str(asset.get("kind", "")).strip()
        engine = str(asset.get("engine", "")).strip()
        status = str(asset.get("status", "")).strip().lower()
        if not figure_id.startswith("fig:"):
            item_errors.append("figure_id must start with 'fig:'")
        elif figure_id in seen:
            item_errors.append(f"duplicate figure_id {figure_id}")
        seen.add(figure_id)
        if engine not in ALLOWED_ENGINES:
            item_errors.append(f"unsupported engine {engine!r}")
        if not kind:
            item_errors.append("kind is required")
        if not question_id:
            item_errors.append("question_id is required")
        if status != "approved":
            item_errors.append("status must be 'approved' before manuscript use")
        else:
            approved_ids.add(figure_id)
            metrics["approved_assets"] += 1
        engine_key = engine or "<missing>"
        metrics["engines"][engine_key] = metrics["engines"].get(engine_key, 0) + 1

        if not str(asset.get("purpose", "")).strip():
            item_errors.append("purpose is required")
        if not str(asset.get("caption", "")).strip():
            item_errors.append("caption is required")
        if not str(asset.get("body_takeaway", "")).strip():
            item_errors.append("body_takeaway is required")
        if not _approval_complete(asset.get("plan_approval")):
            item_errors.append(
                "plan_approval requires approved/reviewer/approved_at/scope"
            )
        if not _approval_complete(asset.get("asset_approval")):
            item_errors.append(
                "asset_approval requires approved/reviewer/approved_at/scope"
            )

        claim_ids = asset.get("claim_ids", [])
        if not isinstance(claim_ids, list) or not claim_ids:
            item_errors.append("claim_ids must be a non-empty list")
            claim_ids = []
        for claim_id in claim_ids:
            claim = claims.get(str(claim_id))
            if claim is None:
                item_errors.append(f"unknown or unapproved claim_id {claim_id}")
            elif str(claim.get("question_id", "")).strip() != question_id:
                item_errors.append(
                    f"{claim_id} belongs to {claim.get('question_id')}, not {question_id}"
                )
            elif figure_id not in claim.get("figure_table_ids", []):
                item_errors.append(
                    f"{claim_id} does not bind {figure_id} in figure_table_ids"
                )

        source_ids = asset.get("source_ids", [])
        if not isinstance(source_ids, list) or not source_ids:
            item_errors.append("source_ids must be a non-empty list")
            source_ids = []
        for source_id in source_ids:
            if str(source_id) not in evidence:
                item_errors.append(f"unknown or unapproved source_id {source_id}")

        source_files = asset.get("source_files", [])
        if not isinstance(source_files, list) or not source_files:
            item_errors.append("source_files must be a non-empty list")
            source_files = []
        for file_index, record in enumerate(source_files):
            _verify_file_record(
                project,
                record,
                f"{prefix}.source_files[{file_index}]",
                item_errors,
            )

        generation_files = asset.get("generation_files", [])
        if not isinstance(generation_files, list) or not generation_files:
            item_errors.append("generation_files must be a non-empty list")
            generation_files = []
        generation_paths: list[Path] = []
        for file_index, record in enumerate(generation_files):
            path = _verify_file_record(
                project,
                record,
                f"{prefix}.generation_files[{file_index}]",
                item_errors,
            )
            if path is not None:
                generation_paths.append(path)

        paper_asset = _verify_file_record(
            project, asset.get("paper_asset"), f"{prefix}.paper_asset", item_errors
        )
        preview_asset = _verify_file_record(
            project,
            asset.get("preview_asset"),
            f"{prefix}.preview_asset",
            item_errors,
        )
        qa_report = _verify_file_record(
            project, asset.get("qa_report"), f"{prefix}.qa_report", item_errors
        )
        if (
            paper_asset is not None
            and paper_asset.suffix.lower() not in PAPER_IMAGE_SUFFIXES
        ):
            item_errors.append(
                "paper_asset must be PDF/PNG/JPG; do not insert SVG directly "
                "into the current XeLaTeX template"
            )
        if preview_asset is not None and preview_asset.suffix.lower() != ".png":
            item_errors.append(
                "preview_asset must be PNG for deterministic visual inspection"
            )
        if qa_report is not None and not _qa_passes(qa_report):
            item_errors.append("qa_report must be JSON with a passing status")

        suffixes = {path.suffix.lower() for path in generation_paths}
        if engine == "cumcm-figure-skill":
            if not suffixes.intersection({".py", ".r"}):
                item_errors.append(
                    "cumcm-figure-skill handoff requires reproducible Python or R code"
                )
            if (
                paper_asset is not None
                and paper_asset.suffix.lower() != ".pdf"
                and not _exception_complete(asset.get("format_exception"))
            ):
                item_errors.append(
                    "cumcm-figure-skill should use a vector PDF master; approve "
                    "format_exception for raster-only figures"
                )
        if engine == "cumcm-visual-skill":
            if ".svg" not in suffixes or ".json" not in suffixes:
                item_errors.append(
                    "cumcm-visual-skill handoff requires SVG plus visual/chart/model "
                    "plan JSON"
                )
        if (
            kind in DATA_KINDS
            and engine != "cumcm-figure-skill"
            and not _exception_complete(asset.get("routing_exception"))
        ):
            item_errors.append(
                "data charts route to cumcm-figure-skill by default; approve "
                "routing_exception to use another engine"
            )
        if (
            kind in DIAGRAM_KINDS
            and engine != "cumcm-visual-skill"
            and not _exception_complete(asset.get("routing_exception"))
        ):
            item_errors.append(
                "model/process diagrams route to cumcm-visual-skill by default; "
                "approve routing_exception to use another engine"
            )

        if paper_asset is not None and paper_asset.suffix.lower() == ".png":
            dimensions = _png_dimensions(paper_asset)
            if dimensions is None:
                item_errors.append("paper_asset has an invalid PNG signature")
            elif (
                min(dimensions) < minimum_short_side
                or max(dimensions) < minimum_long_side
            ):
                item_errors.append(
                    "paper_asset PNG is too small for normal A4 insertion: "
                    f"{dimensions[0]}x{dimensions[1]}"
                )

        if figure_id and labels and figure_id not in labels and status == "approved":
            item_errors.append("approved asset has no matching LaTeX figure label")
        errors.extend(f"{figure_id or prefix}: {message}" for message in item_errors)
        asset_reports.append(
            {
                "figure_id": figure_id,
                "kind": kind,
                "engine": engine,
                "status": "PASS" if not item_errors else "FAIL",
                "errors": item_errors,
            }
        )

    for label in sorted(labels - approved_ids):
        errors.append(f"{label}: LaTeX figure has no approved figure_manifest entry")

    return {
        "schema_version": "1.0",
        "generated_at": now_iso(),
        "status": "BLOCKED" if errors else "PASS",
        "errors": errors,
        "warnings": warnings,
        "metrics": metrics,
        "assets": asset_reports,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate CUMCM figure-engine handoffs."
    )
    parser.add_argument("project_dir", type=Path)
    args = parser.parse_args()
    project = args.project_dir.resolve()
    registry_path = project / "claim_registry.json"
    if not registry_path.is_file():
        print("claim_registry.json is required", file=sys.stderr)
        return 2
    report = validate_figure_manifest(project, load_json(registry_path))
    report_path = project / "reports" / "figure_asset_report.json"
    write_json(report_path, report)
    print(f"figures: {report['status']}; report={report_path}")
    if report["errors"]:
        for error in report["errors"]:
            print(f"- {error}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
