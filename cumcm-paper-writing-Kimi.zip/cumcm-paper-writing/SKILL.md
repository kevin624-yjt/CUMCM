---
name: cumcm-paper-writing
description: 面向全国大学生数学建模竞赛（CUMCM/国赛）的证据约束型论文工程技能。用于从题目、代码与结果生成或重写摘要、方法、求解结果与检验、结论、LaTeX 论文和支撑材料，也用于审查现有国赛论文、修复篇幅与格式、执行终稿自然化、现行规则门禁及 100 分评分。用户提到国赛论文、数学建模论文、摘要、逐问写作、30 页正文、支撑材料、降低模板化或 AI 腔、AI 使用详情、LaTeX 编译、论文验收或优秀论文仿写时使用。
---

# CUMCM Paper Writing

## 目标

把“写得像优秀论文”变成可追溯、可编译、可复核的论文发布流程。优秀论文只提供叙事模式，任何数字、文献、算法过程和规则判断都必须来自当前项目的证据或现行官方规则。

## 模块总览

当前技能由写作模式路由、规则与合同、项目模板、证据注册、叙事与篇幅、分段正文、检验与结论、首屏摘要、四轮编辑、图表版式、终稿自然化、LaTeX 编译、支撑材料、门禁评分共 14 个核心模块组成。各模块的输入、输出、脚本和报告见 [整体模块清单](references/module-overview.md)；每个模块借鉴了哪些上游 skills、迁移了什么以及哪些内容没有迁移，见 [模块来源与迁移映射](references/migration-map.md)。

## 先选模式

| 模式 | 适用输入 | 必须交付 |
|---|---|---|
| `CREATE` | 题目、数据、代码、结果 | 完整项目、论文 PDF、支撑材料、门禁与评分报告 |
| `SECTION` | 某一问或某一章节 | 章节包、使用的 claim ID、缺失证据清单 |
| `AUDIT` | 现有 TeX/PDF/Word | 问题优先级清单、门禁报告、修订后的文件 |
| `RELEASE` | 基本完成的项目 | 编译 PDF、支撑材料压缩包、最终门禁和评分 |

若用户未指定，完整写作选择 `CREATE`，只评价或修改现有稿件选择 `AUDIT`。

## 规则优先级

1. 当前竞赛官方规则栈；
2. 当前项目的 `paper_contract.json`；
3. 已批准的结果与来源证据；
4. 2020--2025 优秀论文中的结构模式；
5. 通用学术写作经验。

冲突时始终采用更高层。历史优秀论文不得覆盖现行 30 页、匿名、AI 披露或支撑材料规则。执行前阅读 [现行规则栈](references/current-rules.md)。

## 不可破坏的原则

1. **逐问闭环**：目标 → 选择理由 → 变量/假设/关系 → 求解 → 结果 → 检验 → 直接回答。
2. **证据先于文字**：定量结论只能读取批准的 claim/evidence；缺证据就输出 `BLOCKED`。
3. **单一数字源**：摘要、正文、图表和结论用 `\ClaimValue{}`、`\ClaimUnit{}`、`\ClaimAnswer{}` 调用同一注册表。
4. **先正文后摘要**：先完成逐问证据链，最后从已批准 claim 生成标题、摘要和关键词。
5. **不夸大**：启发式结果不写成全局最优，相关性不写成因果，数值稳定不等于现实有效。
6. **不为页数灌水**：用模型理由、关键推导、结果解释和检验证据提高信息密度，不复述题干或堆背景。
7. **浮动体不截断正文流**：正文图表默认用 `[!htbp]`，高图用 `[p]`；禁止 `[H]` 和章节文件中的强制换页。不得让一段短文字占据页首、整张图被推到下一页而留下大面积空白。

## 快速开始

```bash
python scripts/init_project.py <project-dir> --questions Q1,Q2,Q3,Q4
```

初始化后先填写：

- `paper_contract.json`
- `claim_registry.json`
- `paper_claim_matrix.csv`
- `page_budget.json`
- `figure_manifest.json`
- `support_manifest.json`
- `release_approvals.json`

模板位于 `assets/project-template/`。字段和门禁见 [证据注册表与门禁](references/evidence-and-gates.md)。

## W0：锁定写作合同

从题目逐项提取所有小问，不按自然段猜题。合同至少记录：

- 题目与小问 ID；
- 输入、指定输出、单位和边界条件；
- 允许的求解器与随机性；
- 当前 AI 使用状态；
- 正文页数合同；
- 匿名敏感词；
- 必须进入支撑材料的文件。

默认电子版：第一页为标题、摘要、关键词；不含承诺书和编号页；无目录；正文与参考文献合计不超过 30 页；附录随后开始。

## W1：建立证据注册表

先登记 evidence，再登记 claim，最后生成写作矩阵。

每个主要 claim 必须包含：

- `claim_id` 与 `question_id`；
- 任务、模型名称和选择理由；
- 变量/假设/核心关系；
- 求解方法、关键参数和终止条件；
- 结果值、单位、精度与 `source_ids`；
- 检验 `validation_ids`；
- 图表锚点；
- 有边界条件的直接回答句；
- `approved` 状态与允许出现的章节。

运行：

```bash
python scripts/validate_project.py <project-dir> --phase evidence
python scripts/render_claims.py <project-dir>
```

任何小问不完整、来源不存在、哈希不符、结果未批准或派生量无公式时，停止终稿写作并返回缺失项。

## W2：叙事主线与篇幅合同

先写不超过 200 字的主线，再按复杂度分配页面。默认 95 分质量合同为正文 28--30 页，法规硬上限为 30 页；24--27 页必须有经批准的完整性说明，低于 24 页不能标记 `READY_95`。

不要平均分配各问。根据模型新颖度、推导长度、结果数量、图表和检验强度分配。具体规则见 [篇幅工程](references/page-budget.md)。

## W3：按模块写正文

按 `问题分析 → 假设与符号 → 共用模型 → 各问 → 综合检验 → 评价与结论 → 参考文献` 写作。每次只生成一个可验收章节包：

```text
SECTION_PACKET
section:
question_ids:
claims_used:
evidence_used:
draft:
figures_tables:
unresolved:
gate_status:
```

各问采用六段式：

1. 本问目标：输入、输出、难点、与前问关系；
2. 建模选择：为什么选它，为什么不选明显替代方案；
3. 数学表达：变量、目标、约束、核心关系；
4. 求解方法：真实步骤、参数、终止条件、输出；
5. 结果与解释：先证据，后数量级、趋势、余量和实际含义；
6. 本问回答与检验：直接回答，紧接误差、敏感性或独立复核。

插图放在首次解释后的自然位置。正文继续流过尚未排下的浮动体，不用 `[H]`、`\clearpage`、`\newpage` 把图锁到当前位置。高度超过约 `0.45\textheight` 的多面板图优先用 `[p]`、拆分面板或受控缩放；不得通过整页强制换页制造留白。

图形生成采用双引擎路由：定量、统计和结果图优先调用 `cumcm-figure-skill`；模型结构、求解流程、研究框架和因果/层次图优先调用 `cumcm-visual-skill`。论文技能仍负责先从 claim registry 确定“为什么画、支持哪条结论、数据来自哪里”，并在 `figure_manifest.json` 记录计划批准、输入/代码/产物哈希、QA、图题和正文解读。Visual 的 SVG 只作编辑源，当前 LaTeX 正文插入经真实导出和验收的 PNG/PDF。完整路由与交接字段见 [图形双引擎路由](references/figure-engine-routing.md)。

受控缩放必须调用 `scripts/tune_figure_scale.py`，按标签一次缩小 `0.04\textwidth`，并重新编译检查。默认宽度范围为 `0.78`--`0.96\textwidth`，同时限制高度不超过 `0.60\textheight` 并保持纵横比。达到 `0.78\textwidth` 后仍不能满足版面门禁时，必须拆图或改用 `[p]`，不得继续缩小。

模块优化细节见 [分段写作路由](references/section-routing.md)。

## W4：检验、评价与结论

检验按证据类型合并组织：残差/收敛、边界/极限、敏感性、独立复核、样本外或扰动测试。每项写明对象、范围、指标、结果和支持的 claim。

优缺点必须指向具体假设、结构或算法。结论按问题编号重述直接答案，不增加新数字或新论断。

## W5：最后生成首屏

从已批准 claim 自动生成长摘要，再做压缩。摘要顺序：

1. 对象、难点和统一主线；
2. 每问的模型、求解与核心答案；
3. 最重要的检验；
4. 有边界的总结。

首屏必须让评阅者在 30 秒内识别每问方法、答案、检验与主要特点。国赛摘要不套用顶会固定四句模板。所有关键数值必须使用 claim 宏。

## W6：四轮编辑

依次执行，不混在同一轮：

1. 技术：定义、公式、单位、适用条件、最优性措辞；
2. 结构：重点检查段落衔接、模型结构、公式解释、图表、引用、章节完整性和结论对应关系；
3. 压缩：删背景、题干改写、套话、无证据形容词和数字复读；
4. 一致性：数字、符号、术语、编号、引用、文件名。

第二轮必须逐项留下证据：

- **段落衔接**：每个标题后先有定向句；段首说明与上一段、上一问或共用模型的关系；
- **模型结构**：每问可定位目标、选择理由、变量/关系、求解、结果、检验和直接回答；
- **公式解释**：公式前说明用途，公式后解释符号、条件和它如何参与求解，编号公式有标签且被引用；
- **图表**：每张图表有标题、标签和可读单位，正文解释趋势、数量级、约束余量或决策含义；
- **引用**：公式、章节、图表的交叉引用目标存在且不重复，文献引用真实、可解析并与上下文用途一致；
- **章节完整性**：主文件按合同包含分析、假设、共用模型、逐问、检验、评价、结论和参考文献；
- **结论对应**：结论按题目顺序调用全部 answer claim，不漏问、不换序、不新增公式、图表或数字。

随后运行：

```bash
python scripts/validate_project.py <project-dir> --phase manuscript
python scripts/validate_figure_assets.py <project-dir>
```

检查结果写入 `reports/manuscript_structure_report.json`。七类中任一类失败即触发 `W-G13`，不得进入发布。

## W6.5：终稿自然化

只在 `manuscript` 门禁通过、正文技术内容定稿后执行。目标是降低模板化、聊天式和宣传式表达，使中文技术叙述更接近真实竞赛论文；它不是检测器规避服务，不生成“AI 率”，也不承诺通过知网、维普或其他平台。

先建立不可覆盖的受保护快照：

```bash
python scripts/naturalize_audit.py <project-dir> --snapshot
```

快照锁定 claim 宏、全部数字与单位、公式块、章节命令、图表标签、交叉引用、文献键、claim registry、证据文件和关键源文件哈希。自然化只允许修改不承载新事实的叙述层：

- 删除泛背景、聊天残留、宣传性形容词和无信息的提示壳；
- 阻断工具/临时引用标记、知识截止声明、讨好式对话、Markdown 和 emoji 等发布残留；
- 减少机械的“首先—其次—最后”、重复句首和等长句段；
- 让承接关系由研究对象、条件、证据和结论承担；
- 保留国赛正式语体，不注入第一人称感想、幽默、故意混乱或口语化“个性”；
- 不能用优秀论文或常识补数字、误差、文献、比较基线和算法过程。

按 `reports/naturalization_matrix.csv` 修订，每轮只处理已定位条目，最多三轮。每轮后运行：

```bash
python scripts/naturalize_audit.py <project-dir> --verify --round 1
python scripts/validate_project.py <project-dir> --phase manuscript
```

需要继续时把 `--round` 改为 2 或 3。D1--D5 只表示本地句长节奏、段落结构、信息密度、连接词和术语语境诊断，不是 AI 概率。风格提示可由人工说明保留理由；受保护内容差异、聊天残留或检测器承诺则直接阻断。最终在 `release_approvals.json` 的 `naturalization_semantics` 中记录复核者、时间、处理范围和保留项理由。发布时 `W-G14` 会重新计算当前状态，防止报告生成后再改数字、公式或引用。完整协议见 [终稿自然化](references/naturalization.md)，Humanizer 模式的自动阻断、人工复核、纯语义检查和排除项见 [国赛自然化规则取舍表](references/naturalization-patterns.md)。

## W7：发布验收

```bash
python scripts/compile_project.py <project-dir> --run-support-checks
python scripts/validate_project.py <project-dir> --phase release
python scripts/score_paper.py <project-dir>
```

评分前按 `quality_assessment.json` 填写 43 个有证据的原子指标。脚本把它们聚合为十个论文部分和原九个能力维度；同一分值只计算一次。扣分项必须同时记录问题和修复动作，完整协议见 [评分协议](references/scoring.md)。

`compile_project.py` 先编译 AI 使用详情，随后校验并打包支撑材料、生成附录文件清单，再复编最终论文。仅需查看草稿且支撑材料尚未齐备时可用 `--skip-support-build`，但该模式不能通过发布门禁。

发布前必须人工检查逐页渲染图，并在 `release_approvals.json` 记录检查者、时间和证据。完整要求见 [LaTeX 与支撑材料发布](references/support-and-release.md)。

`compile_project.py` 会对正文页做像素级页底留白检测。默认允许的连续页底空白上限为正文区高度的 `25%`；超过阈值时 W-G09 直接失败并报告页码，不能用人工“已检查”覆盖该阻断。修复顺序为：解除强制定位、调整浮动参数、按 `0.04\textwidth` 步进受控缩放、拆图或改用浮动页。

状态机：

```text
BLOCKED --全部阻断门禁通过--> GATE_PASS
GATE_PASS --分部原子评分与九维聚合完成--> SCORED
SCORED --总分>=95且无分部或维度失守--> READY_95
```

门禁失败时不得输出“完整论文”“验收通过”或有效总分。分数不是门禁的替代品。

## 审查输出

`AUDIT` 模式先给问题，不先给表扬。按以下顺序：

1. 阻断问题：规则、造数、漏问、结果冲突、匿名、引用、支撑材料；
2. 高影响失分：摘要不可判读、模型理由不足、结果无解释、检验空泛；
3. 结构问题：段落跳跃、模型链断裂、公式无解释、图表未解读、章节缺失、结论错配；
4. 版式与语言问题；
5. 可保留的写作模式；
6. 修订结果、门禁状态和剩余风险。

## 资源索引

- [现行规则栈](references/current-rules.md)
- [整体模块清单](references/module-overview.md)
- [模块来源与迁移映射](references/migration-map.md)
- [证据注册表与门禁](references/evidence-and-gates.md)
- [分段写作路由](references/section-routing.md)
- [篇幅工程](references/page-budget.md)
- [优秀论文模式库](references/excellent-paper-patterns.md)
- [终稿自然化](references/naturalization.md)
- [国赛自然化规则取舍表](references/naturalization-patterns.md)
- [LaTeX 与支撑材料发布](references/support-and-release.md)
- [图形双引擎路由](references/figure-engine-routing.md)
- [评分协议](references/scoring.md)
- [来源与许可](references/provenance.md)
