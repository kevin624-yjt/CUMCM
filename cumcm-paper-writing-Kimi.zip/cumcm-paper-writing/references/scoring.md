# 评分协议

## 前置条件

只有全部阻断门禁和 `Q-G01` 通过后才能评分。每个评分项必须提供可定位证据；未得满分时还必须填写具体问题和修复动作。

## 2.0 分部原子评分

新项目的 `quality_assessment.json` 使用 `2.0-section-atomic` 协议。评分者填写 43 个原子指标，`score_paper.py` 同时聚合出十个论文部分和原九个能力维度，总分只计算一次。

| 分部 ID | 分值 | `READY_95` 下限 |
|---|---:|---:|
| `title_abstract_keywords` | 15 | 14 |
| `problem_analysis` | 6 | 5 |
| `foundations` | 10 | 9 |
| `per_question_modeling` | 17 | 15 |
| `results_interpretation` | 15 | 14 |
| `validation_evaluation_conclusion` | 10 | 9 |
| `figures_tables` | 10 | 9 |
| `language_coherence` | 9 | 8 |
| `citations_consistency` | 3 | 2.5 |
| `latex_compliance_support` | 5 | 4 |

每个原子分使用 0.25 分增量。`evidence` 必须非空；若 `score` 小于该项满分，`finding` 和 `action` 必须同时非空。指标定义、分部权重和九维映射由 `scripts/rubric.py` 作为单一机器源维护，初始化项目时自动写入评分模板。

## 九维汇总

| 维度 ID | 分值 | 评分重点 |
|---|---:|---|
| `front_screen` | 15 | 标题准确、首屏可判读、逐问覆盖、数字明确 |
| `question_closure` | 15 | 章节合理、各问闭环、公共模型与分问衔接 |
| `model_expression` | 15 | 选择理由、符号定义、推导和条件 |
| `results` | 15 | 关键结果、单位精度、解释和实际含义 |
| `validation_conclusion` | 10 | 具体检验、针对性评价、直接结论 |
| `figures_tables` | 10 | 自解释、可读、编号引用、服务论证 |
| `language` | 10 | 简洁准确、段落聚焦、术语统一 |
| `consistency_citations` | 5 | 数字、符号、单位、文献和交叉引用 |
| `latex_compliance` | 5 | 编译、版式、匿名、规则和支撑材料 |

## 95 分就绪

必须同时满足：

- 总分至少 95；
- 十个论文部分均达到各自下限；
- 四个 15 分能力维度均至少 13；
- 三个 10 分能力维度均至少 9；
- 两个 5 分能力维度均至少 4；
- 无未关闭的高风险问题；
- 评分证据对应同一版 PDF、TeX、claim 和结果文件。

高总分不能掩盖摘要、逐问建模、结果解释或检验中的明显短板。

## 旧版兼容

没有 `rubric_version` 和 `criteria` 的旧项目仍可按九维 `dimensions` 读取，报告标记为 `legacy-dimensions`，但不生成分部质量画像。新建项目必须使用 2.0 协议。

## 评分流程

1. 独立评审只读标题、摘要和关键词；
2. 技术评审按问题检查分析、模型、求解、结果与检验；
3. 视觉评审查看逐页渲染图；
4. 一致性评审读取自动报告和证据注册表；
5. 填写 `quality_assessment.json` 的原子指标；
6. 运行 `score_paper.py`，读取分部画像、九维画像和扣分清单；
7. 修订后重新跑门禁与评分，不手工修改总分。
