# 证据注册表与门禁

## 单一事实源

`claim_registry.json` 是关键数字和结论的唯一事实源，`paper_claim_matrix.csv` 是便于人工审查的投影视图。不要分别维护两套数字。

Evidence 记录原始证据：

```json
{
  "evidence_id": "RES-Q1-001",
  "kind": "result",
  "path": "results/q1_summary.csv",
  "sha256": "<64 hex>",
  "locator": "row=best, column=distance_m",
  "approved": true
}
```

Claim 记录可进入论文的主张：

```json
{
  "claim_id": "Q1-MAIN",
  "claim_type": "answer",
  "question_id": "Q1",
  "task": "求出……",
  "model_name": "……模型",
  "model_choice_reason": "因为……，相较……更适合……",
  "variables": ["x: ……"],
  "assumptions": ["A1"],
  "core_relations": ["EQ-Q1-01"],
  "solver": {
    "method": "……",
    "parameters": "……",
    "termination": "……"
  },
  "result": {
    "value": 12.3456,
    "unit": "m",
    "precision": 2,
    "source_ids": ["RES-Q1-001"],
    "derivation": null
  },
  "validation_ids": ["VAL-Q1-001"],
  "figure_table_ids": ["TAB-Q1-01"],
  "answer_sentence": "在题设条件和本文假设下，……为 12.35 m。",
  "scope": "仅对给定参数范围成立",
  "allowed_sections": ["abstract", "Q1", "conclusion"],
  "approved": true
}
```

`claim_type="answer"` 表示该 claim 直接回答小问，必须进入对应小问、摘要和结论；`claim_type="supporting"` 表示中间量或辅助证据，只需出现在允许的正文位置。每个小问至少有一个批准的 answer claim。

派生量必须给出：

- 输入 claim ID；
- 明确公式；
- 单位换算；
- 舍入规则；
- 复算结果。

写作层只允许按批准精度舍入、记录单位换算、计算已批准的明确派生量。

## 写作宏

运行 `render_claims.py` 后使用：

```latex
\ClaimValue{Q1-MAIN}
\ClaimUnit{Q1-MAIN}
\ClaimAnswer{Q1-MAIN}
\ClaimScope{Q1-MAIN}
```

不要在摘要、正文、图表和结论手工重复受保护的结果数字。需要不同精度时新增经过批准的派生 claim，不要在文字中随意改位数。

## 阻断性门禁

| ID | 通过标准 |
|---|---|
| `W-G01` | 所有摘要级 claim 均有批准 evidence ID、存在的文件和匹配哈希 |
| `W-G02` | 每个小问有方法、结果、检验和直接回答句 |
| `W-G03` | 摘要、正文、图表、结论通过同一 claim 宏读取关键指标 |
| `W-G04` | 无写作层补造的数字、误差、搜索过程或未执行步骤 |
| `W-G05` | 摘要覆盖全部问题，含主要方法、答案和至少一种检验 |
| `W-G06` | 关键符号已定义，单位完整且无明显量纲冲突 |
| `W-G07` | 公式、图表、章节和文献引用无悬空或重复目标 |
| `W-G08` | 图表在 A4 100% 下可读，正文逐一引用并解释；正式图片在 `figure_manifest.json` 中完成 claim/evidence 双向绑定、生成文件与产物哈希、QA 和批准记录 |
| `W-G09` | PDF 无重叠、越界、乱码、异常空白页、正文页底大面积连续留白或严重孤行 |
| `W-G10` | 全部提交物匿名且符合当届规则 |
| `W-G11` | 未把启发式写成全局最优，未把相关写成因果 |
| `W-G12` | 文献和参数来源真实存在，引用内容与来源相符 |
| `W-G13` | 段落衔接、模型结构、公式解释、图表、引用、章节完整性、结论对应关系全部通过 |
| `W-G14` | 终稿自然化经受保护快照复核：claim、数字、单位、公式、标签、引用和证据哈希未变，无聊天残留、虚构 AI 百分比或检测器通过承诺 |

发布扩展门禁：

| ID | 通过标准 |
|---|---|
| `R-G01` | 正文区不超过 30 页 |
| `R-G02` | 电子论文不超过 20 MB |
| `R-G03` | 支撑材料 ZIP/RAR 不超过 20 MB |
| `R-G04` | 电子论文第一页为摘要，无承诺书、编号页和目录 |
| `R-G05` | 附录清单、manifest、压缩包文件与哈希一致，代码可运行或有明确无代码说明 |
| `R-G06` | AI 使用状态、正文标注、参考文献和详情 PDF 相互一致 |

## 自动与人工检查

自动检查负责可确定事实：字段、覆盖、文件、哈希、宏、引用目标、页数、大小、支撑 manifest 和图形 manifest。图形交接另生成 `reports/figure_asset_report.json`；SVG 直接入稿、错误引擎路由、缺失计划/产物批准、QA 失败或低分辨率 PNG 会并入 `W-G08`。

人工或独立 AI 检查负责语义事实：段落是否自然承接、模型链是否合理、公式解释是否准确、图表解读是否支持主张、交叉引用和文献用途是否准确、结论是否忠实对应各问。自动检查会生成 `reports/manuscript_structure_report.json`，人工检查必须在 `release_approvals.json` 的七个结构字段中分别留下对象、检查者、时间和证据，不能只填 `true`。

终稿自然化另生成 `reports/naturalization_guard.json`、`reports/naturalization_report.json` 和 `reports/naturalization_matrix.csv`。自动检查锁定可确定内容，人工审批 `naturalization_semantics` 负责确认改写未改变模型含义、结论强度、段落衔接和国赛正式语体。自然化报告不输出 AI 率，也不替代 AI 使用披露。

## 状态

- 任一阻断项失败：`BLOCKED`，不得给有效总分。
- 全部阻断项通过：`GATE_PASS`。
- 九维评分完成：`SCORED`。
- 总分至少 95，且每个 15 分维度至少 13、10 分维度至少 9、5 分维度至少 4：`READY_95`。
