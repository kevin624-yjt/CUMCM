# 来源与许可

本文件记录仓库级来源和许可证边界；十四个模块及脚本的逐项来源见 [模块来源与迁移映射](migration-map.md)。

## 基座

- `voidful/academic-skills`：借鉴 Motivation-First、粗到细写作、30 秒可读性、一段一意、自解释图表和分轮审查。仓库采用 MIT License；许可证副本位于 `LICENSES/academic-skills-MIT.txt`。
- `Lupynow/math-modeling-skills` 的 `math-modeling-paper`：借鉴国赛章节路由、逐问结果表达、检验和支撑材料清单。该技能采用 MIT License；许可证副本位于 `LICENSES/math-modeling-paper-MIT.txt`。
- `akillness/oh-my-skills` 当前重定向到 `akillness/jeo-skills`：借鉴 claim/evidence packet 与 paper contract 的思想。调研时未在下载快照中确认仓库级许可证，因此本技能只做独立实现，不复制其文字或代码。
- `lingzhi227/agent-research-skills/paper-compilation`：借鉴“编译—诊断—修复—复编”工作流。调研时未确认许可证，因此编译脚本为独立实现。
- `bahayonghang/academic-writing-skills`：终稿自然化借鉴 LaTeX 命令、公式、标签、引用保护和零补造原则。仓库当前声明 `Academic Use Only — Not for commercial use`，因此本技能不复制其代码或长段文字，只按公开思想独立实现。
- `WUBING2023/PaperSpine`：终稿自然化借鉴“不承诺检测器通过、不伪造 AI 百分比”、D1--D5 本地诊断、修订矩阵和最多三轮复核。仓库采用 MIT License；许可证副本位于 `LICENSES/PaperSpine-MIT.txt`。
- `op7418/Humanizer-zh`：借鉴删除填充语、模板句、宣传词、模糊归因、重复连接词和聊天残留。仓库采用 MIT License；许可证副本位于 `LICENSES/Humanizer-zh-MIT.txt`。国赛模块未采用其注入第一人称、幽默、感受或故意混乱等非技术论文建议。
- 用户提供的 `Kimi_Agent_技能输出验证.zip`：离线复核其中的 `humanizer`、`humanizer-zh`、`humanizer-zh-by-guizang` 及两份 anti-ai 规则。`humanizer-zh` 与既有 Humanizer-zh 许可证 SHA-256 一致，因此无需新增许可证副本；本次仅据其模式分类补强独立审计实现，没有复制压缩包中的扫描脚本。面向博客/创作的钩子、个性注入、固定段长、固定删减比例和检测信号评分均未采用。
- 用户提供的 `cumcm-figure-skill-v3`：以 Apache-2.0 许可发布。本技能借鉴其图形目标契约、可复现 Python/R、PDF/PNG 双交付和 QA 流程，通过独立 `figure_manifest.json` 适配，不复制其图形资产或执行代码。
- 用户提供的 `cumcm-visual-skill`：以 MIT 许可发布。本技能借鉴其结构化模型/流程图、可编辑 HTML/SVG 和真实 Chrome PNG 工作流，通过独立路由和交接校验接入，不复制其生成器代码。

## 国赛资料

规则事实来自 CUMCM 官方现行文件。优秀论文只用于汇总抽象写作模式；本技能不附带、不复制其正文、图表、数据或结论。

## 关键改良

- 把通用论文 claim/evidence 提升为可校验的唯一结果注册表；
- 把顶会 Experiments 改为国赛逐问的求解、结果、解释与检验；
- 把固定页数建议替换为“现行 30 页硬上限 + 28--30 页质量合同”；
- 加入 AI 使用、匿名、支撑包、20 MB、可运行代码和 PDF 视觉门禁；
- 加入受保护快照、终稿自然化矩阵和 `W-G14`，使语言润色不能改写证据、数字、公式或引用；
- 评分只在全部阻断门禁通过后生效。
