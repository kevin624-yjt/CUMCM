# cumcm-paper-writing 整体模块清单

## 一、技能定位

`cumcm-paper-writing` 是面向全国大学生数学建模竞赛的论文工程技能。它把题目、模型代码、计算结果和检验证据组织为可追溯的 LaTeX 论文、支撑材料、门禁报告与评分报告。

它不是脱离证据直接生成结果的通用建模求解器。模型、参数、数值、误差和算法过程必须来自当前项目已执行并批准的证据；证据不足时返回 `BLOCKED`。

各模块对应的上游 skill、迁移内容、国赛化改写和未迁移边界见 [模块来源与迁移映射](migration-map.md)。

## 二、四种工作模式

| 模式 | 用途 | 主要交付 |
|---|---|---|
| `CREATE` | 从题目、数据、代码和结果构建完整论文 | 项目目录、LaTeX、PDF、支撑包、门禁与评分 |
| `SECTION` | 只撰写或修订某一问、某一章节 | 章节包、claim/evidence 清单、未解决项 |
| `AUDIT` | 审查现有 TeX、PDF 或 Word 论文 | 按严重度排序的问题、修订文件、门禁报告 |
| `RELEASE` | 对基本完成的论文执行最终发布 | 最终 PDF、支撑材料 ZIP、发布门禁、评分 |

## 三、十四个核心模块

### M01 现行规则与写作合同

- 读取当前 CUMCM 规则栈，处理不同年份文件的累积关系；
- 锁定小问 ID、输入输出、单位、边界、求解器、随机性、匿名和 AI 使用状态；
- 建立 30 页硬上限与 28--30 页质量合同；
- 主要文件：`paper_contract.json`、`references/current-rules.md`。

### M02 项目初始化与 LaTeX 模板

- 一键生成标准项目目录；
- 建立摘要、问题分析、假设符号、共用模型、逐问、检验、评价、结论、参考文献和附录文件；
- 默认使用 `ctexart`、A4、无目录、匿名首屏；
- 脚本：`scripts/init_project.py`；模板：`assets/project-template/`。

### M03 证据注册与单一数字源

- 用 evidence 记录结果文件、定位信息、SHA-256 和批准状态；
- 用 claim 记录模型、变量、关系、求解、结果、单位、精度、检验和直接回答；
- 生成 `\ClaimValue{}`、`\ClaimUnit{}`、`\ClaimAnswer{}`、`\ClaimScope{}`；
- 防止摘要、正文、图表和结论分别手填同一数字；
- 文件：`claim_registry.json`、`paper_claim_matrix.csv`；脚本：`render_claims.py`。

### M04 叙事主线与篇幅工程

- 先生成不超过 200 字的统一主线；
- 按模型复杂度、推导、约束、图表和检验强度分配页面；
- 禁止平均分问和用背景套话灌页；
- 文件：`paper_outline.md`、`page_budget.json`；参考：`page-budget.md`。

### M05 分段选择与正文写作

- 按“问题分析 → 假设符号 → 共用模型 → 各问”构建正文；
- 每问使用目标、选择、数学表达、求解、结果解释、回答检验六段式闭环；
- 每次输出可独立验收的 `SECTION_PACKET`；
- 参考：`section-routing.md`、`excellent-paper-patterns.md`。

### M06 模型、公式与求解表达

- 先说明模型选择理由和未采用替代方案，再给公式；
- 统一定义变量、目标、约束、参数和适用条件；
- 记录真实算法步骤、关键参数、终止条件和输出；
- 检查编号公式的标签、引用及公式前后解释。

### M07 结果呈现、检验、评价与结论

- 结果先给数字或图表，再解释数量级、趋势、余量和实际含义；
- 检验覆盖残差/收敛、边界/极限、敏感性、独立复核和扰动测试；
- 优缺点绑定具体假设、结构或算法；
- 结论按题目顺序调用 answer claim，不新增数字或论断。

### M08 标题、摘要与关键词

- 正文完成后，从批准 claim 生成标题和摘要；
- 摘要覆盖每问的方法、答案、单位和至少一种检验；
- 执行 30 秒首屏可读性检查；
- 禁止把 Python、MATLAB、Excel 当作模型创新。

### M09 四轮编辑与七项结构审查

- 技术轮：符号、公式、单位、条件和最优性措辞；
- 结构轮：段落衔接、模型结构、公式解释、图表、引用、章节、结论；
- 压缩轮：删除背景、题干改写、套话和无证据形容词；
- 一致性轮：数字、符号、术语、编号、引用和文件名；
- 输出：`manuscript_structure_report.json`、`writing_consistency_report.json`；门禁：`W-G13`。

### M10 图表、浮动体与页面留白控制

- 用 `figure_manifest.json` 把图形目的、claim、来源、生成代码、主图、预览、QA 和批准记录绑定为单一交接链；
- 定量/统计/结果图优先路由到 `cumcm-figure-skill`，模型/流程/框架图优先路由到 `cumcm-visual-skill`；
- 外部引擎只生成资产，本技能继续负责图题、正文解读、LaTeX 引用、支撑材料和终稿门禁；
- 正文图表默认 `[!htbp]`，高图使用 `[p]` 或拆图；
- 禁止 `[H]` 和章节中的强制换页；
- 按 `0.04\textwidth` 步进缩放，宽度不低于 `0.78\textwidth`，高度不超过 `0.60\textheight`；
- 像素级检查正文页底连续留白，默认阻断阈值为 25%；
- 脚本：`validate_figure_assets.py`、`tune_figure_scale.py`、`compile_project.py`；门禁：`W-G08`、`W-G09`。

### M11 终稿自然化

- 在正文技术门禁通过后降低模板化、聊天式、宣传式和空泛表达；
- D1--D5 检查句长、段落、信息密度、连接词和术语语境；
- `cumcm-humanizer-2.0` 分层检查工具/引用残留、系统免责声明、Markdown、emoji、套壳展望、过度限定、破折号、粗体和内联标题列表；
- 快照锁定 claim、数字、单位、公式、标签、引用和证据哈希；
- 最多三轮，不输出“AI 率”，不承诺检测器通过；
- 脚本：`naturalize_audit.py`；输出：guard、report、matrix；门禁：`W-G14`。

### M12 LaTeX 编译与 PDF 视觉验收

- 支持 Tectonic、XeLaTeX/latexmk；
- 自动检查 undefined reference/citation、duplicate label、overfull box；
- 提取 PDF 文本并渲染逐页图片；
- 检查首屏、页码、字体、公式断行、图表位置、重叠、越界、乱码和孤页；
- 脚本：`compile_project.py`；输出：`pdf_inspection.json`。

### M13 支撑材料与 AI 使用披露

- 用 manifest 管理代码、数据、结果、图表和说明文件；
- 校验文件存在性、SHA-256、可运行命令、预期输出、匿名和 20 MB 上限；
- 生成支撑材料 ZIP 与附录文件清单；
- 编译 `AI工具使用详情.pdf`，核对正文标注、参考文献和合同状态；
- 脚本：`build_support_package.py`；门禁：`R-G03`、`R-G05`、`R-G06`。

### M14 门禁、状态机与 100 分评分

- 写作阻断门禁：`W-G01`--`W-G14`；
- 发布门禁：`R-G01`--`R-G06`；
- 页数质量门禁：`Q-G01`；
- 状态机：`BLOCKED → GATE_PASS → SCORED → READY_95`；
- 43 个原子指标先聚合为十个论文部分，再交叉汇总为原九个能力维度，总分只计算一次；
- 脚本：`validate_project.py`、`rubric.py`、`score_paper.py`。

## 四、自动化脚本

| 脚本 | 作用 |
|---|---|
| `init_project.py` | 初始化合同、注册表、矩阵、预算、模板和审批文件 |
| `render_claims.py` | 把批准 claim 确定性渲染为 LaTeX 宏和写作矩阵 |
| `validate_project.py` | 执行 evidence、manuscript、release 三阶段门禁 |
| `validate_figure_assets.py` | 校验 Figure/Visual 路由、claim 双向绑定、文件哈希、QA、格式与批准记录 |
| `tune_figure_scale.py` | 按标签受控缩放图片并执行最小宽度保护 |
| `naturalize_audit.py` | 建立自然化快照、风格诊断和修改后完整性验证 |
| `compile_project.py` | 编译 AI 详情、论文 PDF，渲染页面并检查版式 |
| `build_support_package.py` | 校验 manifest、运行复现命令并生成支撑包 |
| `rubric.py` | 维护 43 个原子指标、十个分部权重和九维映射 |
| `score_paper.py` | 门禁通过后验证评分证据并生成分部、九维与扣分画像 |
| `common.py` | 提供哈希、路径、JSON、审批和门禁公共函数 |

## 五、规则与知识参考

| 文件 | 内容 |
|---|---|
| `current-rules.md` | 现行规则栈与冲突优先级 |
| `module-overview.md` | 当前技能整体模块清单 |
| `migration-map.md` | 十四个模块的上游来源、迁移内容与独立实现边界 |
| `evidence-and-gates.md` | evidence/claim 结构和全部门禁 |
| `section-routing.md` | 摘要、方法、结果、检验、结论的分段路由 |
| `page-budget.md` | 28--30 页质量合同与篇幅分配 |
| `excellent-paper-patterns.md` | 2020--2025 优秀论文的抽象写作模式 |
| `naturalization.md` | 终稿自然化、保护边界和三轮流程 |
| `naturalization-patterns.md` | Humanizer 规则的自动阻断、人工提示、语义检查和排除边界 |
| `support-and-release.md` | LaTeX、视觉验收、支撑包和 AI 披露 |
| `figure-engine-routing.md` | Figure/Visual 双引擎路由、论文预设和交接契约 |
| `scoring.md` | 100 分评分与 95 分就绪条件 |
| `provenance.md` | 基座、借鉴来源和许可证边界 |

## 六、项目数据与报告

核心输入和中间文件：

```text
paper_contract.json
claim_registry.json
paper_claim_matrix.csv
paper_outline.md
page_budget.json
figure_manifest.json
support_manifest.json
release_approvals.json
quality_assessment.json
pattern_selection.json
```

最终发布产物：

```text
paper.pdf
support-materials.zip
evidence_gate_report.json
manuscript_gate_report.json
manuscript_structure_report.json
writing_consistency_report.json
figure_asset_report.json
naturalization_guard.json
naturalization_report.json
naturalization_matrix.csv
pdf_inspection.json
support_build_report.json
release_gate_report.json
score_report.json
```

## 七、能力边界

- 能做：根据真实题目、代码、结果和检验证据组织、撰写、审查、编译并发布国赛论文；
- 不能做：在没有运行结果时补造数字、误差、文献、搜索过程或所谓最优解；
- 能借鉴：优秀论文的章节组织、论证方式和图表表达；
- 不能照搬：优秀论文的数字、图表、结论或题外材料；
- 能自然化：删除模板化表达并调整句段节奏；
- 不能承诺：任何平台的 AI 检测比例或通过结果。
