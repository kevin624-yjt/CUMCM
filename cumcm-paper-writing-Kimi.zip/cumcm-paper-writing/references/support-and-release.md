# LaTeX 与支撑材料发布

## LaTeX

模板默认使用 `ctexart`、A4 和 2.5 cm 页边距，兼容 XeLaTeX 与 Tectonic。不得添加目录。关键结果由 `generated/claims.tex` 提供。

正式图形先登记到 `figure_manifest.json`。定量图默认由 `cumcm-figure-skill` 生成 PDF/PNG 与可复现代码；模型和流程图默认由 `cumcm-visual-skill` 生成计划 JSON、SVG 编辑源和真实 Chrome PNG。当前模板不直接插入 SVG，外部引擎也不得替代 claim 绑定、图题、正文解释和 A4 视觉门禁。详见 [图形双引擎路由](figure-engine-routing.md)。

图表采用真正的 LaTeX 浮动机制：

- 默认使用 `\begin{figure}[!htbp]` 和 `\begin{table}[!htbp]`；
- 高度超过约 `0.45\textheight` 的多面板图使用 `[p]`、拆成两图，或按下述规则受控缩放；
- 禁止 `[H]`，因为当前页放不下时会把整图推到下一页并在前页留下大块空白；
- 禁止在 `sections/*.tex` 中使用 `\clearpage`、`\newpage` 或 `\pagebreak`；
- 只有摘要结束与附录开始可在主文件中强制换页；
- 图表若暂时排不下，允许后续正文先填满当前页，图表在下一页页首出现；

图片缩放不是第一选择。只有解除 `[H]` 和强制换页后仍超过 `25%` 页底留白门禁，才调用：

```powershell
python scripts/tune_figure_scale.py <project> --label fig:example
python scripts/tune_figure_scale.py <project> --label fig:example --apply
```

脚本默认每次将宽度缩小 `0.04\textwidth`，加入 `height=0.60\textheight,keepaspectratio`，并把宽度限制在 `0.78`--`0.96\textwidth`。每次缩放后必须重新编译；达到 `0.78\textwidth` 仍不通过时，改为拆图或 `[p]` 浮动页，不得继续缩小。多图片组合图不自动修改，须人工拆分以保留字号。
- 图表首次引用与实际位置原则上不跨越一个完整小节。

编译顺序：

1. 生成 claim 宏；
2. 运行 `validate_figure_assets.py`，校验图形交接和哈希；
3. 编译直到交叉引用稳定；
4. 检查 undefined reference/citation、duplicate label、overfull box；
5. 提取 PDF 文本；
6. 定位摘要、正文、参考文献和附录页；
7. 渲染逐页图片；
8. 检查 `suspicious_blank_body_pages` 和每页 `tail_whitespace_ratio`；
9. 在 A4 100% 与缩略图视图人工检查；
10. 复编一次确认可重复。

允许使用系统 XeLaTeX/latexmk 或项目指定的 Tectonic。不要假定所有电脑都已安装 TeX Live。

## PDF 视觉检查

必须检查：

- 第一页标题、摘要、关键词完整；
- 中文字体和公式可读；
- 页码连续；
- 图表未跨边距、无过度缩小；
- 公式断行不改变含义；
- 浮动体靠近首次引用；
- 无文字重叠、乱码、异常空白页；
- 不出现“页首只有短段文字、后半页大面积空白、图片整体落到下一页”的断裂；
- 正文页底连续空白比例不得超过 `paper_contract.json` 中的 `max_body_tail_whitespace_ratio`，默认值为 `0.25`；若命中，按“解除强制定位、受控缩放、拆图或浮动页”的顺序修复，不得批准放行；
- 最后一页无少量孤行；
- 关键中文和数字可从 PDF 提取。

脚本会把正文页底连续大面积空白作为版式阻断，并给出页码和比例。人工视觉批准仍须检查图表语义位置、字号、跨页上下文和缩略图节奏，不能覆盖脚本阻断。

## 支撑材料 manifest

每项记录：

```json
{
  "path": "code/q1_solver.py",
  "role": "复现问题一结果",
  "required": true,
  "executable": true,
  "run_command": "python code/q1_solver.py",
  "expected_outputs": ["results/q1_summary.csv"],
  "sha256": "<由构建脚本写入>"
}
```

赛题直接提供、按规则不必重复提交的原始数据可放在 `excluded_files`，但每项必须给出相对路径和具体理由。`code/`、`data/`、`figures/`、`results/`、`support/` 下其他未登记文件会阻断打包。

构建器应：

- 拒绝 manifest 外的临时文件；
- 校验 required 文件；
- 写入 SHA-256；
- 生成附录文件清单；
- 扫描合同中的匿名敏感词；
- 测试声明的运行命令，或记录经批准的未测试原因；
- 若使用 AI，校验 `AI工具使用详情.pdf`；
- 生成 ZIP 并检查 20 MB 上限。

## AI 详情

使用 AI 时，详情文件至少含：

- 工具名称、版本、机构、日期；
- 使用阶段与目的；
- 关键提示词和关键回复；
- 哪些内容被采用；
- 团队的复核、修改与责任说明。

正文 AI 标注、参考文献 AI 条目、合同状态和详情 PDF 必须一致。未使用 AI 时，在参考文献后放置未使用声明。

## 发布产物

```text
paper.pdf
support-materials.zip
release_gate_report.json
writing_consistency_report.json
manuscript_structure_report.json
naturalization_guard.json
naturalization_report.json
naturalization_matrix.csv
pdf_inspection.json
support_build_report.json
score_report.json
```

只有 `release_gate_report.json` 为 `GATE_PASS` 后，`score_report.json` 才有效。
