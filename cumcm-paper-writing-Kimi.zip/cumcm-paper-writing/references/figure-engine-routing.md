# 图形双引擎路由与交接契约

## 1. 职责边界

`cumcm-paper-writing` 继续拥有图形的证据来源、claim 绑定、正文引用与解释、LaTeX 插入、浮动位置、受控缩放、逐页视觉验收和支撑材料打包。外部技能只负责生成图形资产：

| 图形任务 | 默认引擎 | 原因 |
|---|---|---|
| 折线、散点、柱状、误差棒、箱线、热力、PCA、敏感性、收敛、多面板结果图 | `cumcm-figure-skill` | 具备 Python/R 可复现代码、矢量 PDF、300 dpi PNG 和绘图 QA |
| 模型结构、求解流程、研究框架、因果/反馈、层次关系图 | `cumcm-visual-skill` | 具备结构化 JSON、可编辑 HTML/SVG、真实 Chrome PNG 和布局校验 |
| 需要 HTML/PPTX 原生编辑的数据图 | `cumcm-visual-skill` 的 `paper-chart` | 仅作有理由的例外；记录 `routing_exception` |
| 地图、仿真快照、领域专用图 | 项目原生代码或合适引擎 | 记录 `routing_exception`，仍执行统一交接门禁 |

不得让两个引擎同时从论文全文自行决定“该画哪些图”。图形清单由 claim registry 与页面预算先确定，再逐图路由，避免重复图、装饰图和证据漂移。

## 2. 论文版预设

外部引擎的示例只作风格与代码参考，不直接复制示例数据或硬编码脚本。进入论文前统一执行：

- 图内不重复放置论文图题；正式标题由 LaTeX `\caption{}` 提供；
- 删除演示稿式大标题、装饰条和过宽外边距；背景使用白色或透明色；
- 以约 15 cm 版心缩放后复核字号，内容过密时拆图；
- 定量图优先交付矢量 PDF 主文件和 PNG 预览；结构图交付 SVG 编辑源与 2 倍 PNG，必要时转换为经过验收的 PDF；
- 当前模板不得直接 `\includegraphics{*.svg}`；正文只插入 PDF、PNG 或 JPEG；
- 保留颜色之外的线型、点型、纹理或直接标注，检查灰度打印；
- 图内所有变量、单位、图例和统计量必须来自当前项目证据，不从示例图补齐。

Visual 默认 16:9 或 1600×1000 画布可作为编辑工作区，但不是论文排版承诺。最终 PNG/PDF 仍须通过 A4 100% 与缩略图检查。

## 3. 确认与批处理

`cumcm-figure-skill` 要求先确认绘图方案。论文技能只能在以下条件下复用一次批量确认：

1. `figure_manifest.json` 已列出每张图的目的、数据源、claim、图型、输出和风险；
2. `plan_approval.approved=true`，并记录 reviewer、时间和 `scope=batch`；
3. 批处理没有改变数据映射、统计口径或图型。

任一项发生变化，重新确认对应单图；不得把“生成整篇论文”视作对未知图形方案的默认授权。

## 4. `figure_manifest.json`

初始化项目会生成清单。每张正式图使用一个条目：

```json
{
  "figure_id": "fig:q1-convergence",
  "question_id": "Q1",
  "claim_ids": ["Q1-MAIN"],
  "kind": "data_chart",
  "engine": "cumcm-figure-skill",
  "purpose": "展示目标函数收敛及停止位置",
  "source_ids": ["EV-Q1-TRACE"],
  "source_files": [
    {"path": "results/q1_trace.csv", "sha256": "<hash>"}
  ],
  "generation_files": [
    {"path": "code/plot_q1_convergence.py", "sha256": "<hash>"}
  ],
  "paper_asset": {"path": "figures/q1-convergence.pdf", "sha256": "<hash>"},
  "preview_asset": {"path": "figures/q1-convergence.png", "sha256": "<hash>"},
  "qa_report": {"path": "figures/q1-convergence.qa.json", "sha256": "<hash>"},
  "caption": "问题一目标函数的收敛过程",
  "body_takeaway": "第 84 次迭代后变化低于批准阈值，随后进入稳定区间。",
  "plan_approval": {
    "approved": true,
    "reviewer": "人工复核者",
    "approved_at": "2026-08-01T12:00:00+08:00",
    "scope": "single"
  },
  "asset_approval": {
    "approved": true,
    "reviewer": "人工复核者",
    "approved_at": "2026-08-01T12:30:00+08:00",
    "scope": "A4 100% 与灰度检查"
  },
  "status": "approved"
}
```

`source_ids` 必须指向批准 evidence；`claim_ids` 必须反向在 claim 的 `figure_table_ids` 中绑定同一 `figure_id`。所有路径均位于项目内并记录 SHA-256。

## 5. 引擎交付要求

### Figure

- Python 或 R 可复现代码；
- 输入数据副本或批准 evidence 定位；
- 默认矢量 PDF 主图和 PNG 预览；
- QA JSON 为 `PASS`；
- 样例脚本若只有 PNG、硬编码示例数据或不符合当前字号/尺寸，必须改写并重新执行，不能直接入稿。

### Visual

- `visual-plan.json`、`chart-plan.json` 或 `model-spec.json`；
- SVG 编辑源、自包含 HTML 和真实 Chrome 导出的 PNG；
- `export-report.json` 为 `PASS`；
- 去除演示稿式图内标题和大外边距；
- 正文插入 PNG 或转换后 PDF，SVG 仅作编辑源与支撑材料。

## 6. 验收命令

```bash
python scripts/validate_figure_assets.py <project-dir>
python scripts/validate_project.py <project-dir> --phase manuscript
python scripts/compile_project.py <project-dir> --run-support-checks
python scripts/validate_project.py <project-dir> --phase release
```

`validate_figure_assets.py` 检查引擎路由、双向 claim 绑定、来源与产物哈希、QA 状态、PNG 下限和审批记录。它不能代替最终的 A4 目视检查；后者继续由 `W-G08/W-G09` 和发布审批负责。
